if not IsDuplicityVersion() then return end

IS4.Items = {}

-- ============================================================================
-- IS4.Items.All — Tüm Item Tanımları
-- ============================================================================
IS4.Items.All = {

    -- ═══════════════════════════════════════════
    -- YİYECEK & İÇECEK
    -- ═══════════════════════════════════════════
    ["bread"] = {
        label = "Ekmek",
        type = "food",
        weight = 0.3,
        stack = 20,
        usable = true,
        illegal = false,
        hunger = 15,
        description = "Taze fırından çıkmış ekmek."
    },

    ["sandwich"] = {
        label = "Sandviç",
        type = "food",
        weight = 0.4,
        stack = 10,
        usable = true,
        illegal = false,
        hunger = 30,
        description = "Lezzetli tavuk sandviç."
    },

    ["burger"] = {
        label = "Hamburger",
        type = "food",
        weight = 0.5,
        stack = 10,
        usable = true,
        illegal = false,
        hunger = 40,
        description = "Büyük boy burger."
    },

    ["donut"] = {
        label = "Donut",
        type = "food",
        weight = 0.2,
        stack = 15,
        usable = true,
        illegal = false,
        hunger = 20,
        description = "Çilekli donut."
    },

    ["apple"] = {
        label = "Elma",
        type = "food",
        weight = 0.2,
        stack = 20,
        usable = true,
        illegal = false,
        hunger = 10,
        description = "Taze yeşil elma."
    },

    ["water"] = {
        label = "Su Şişesi",
        type = "drink",
        weight = 0.5,
        stack = 15,
        usable = true,
        illegal = false,
        thirst = 35,
        description = "500ml su şişesi."
    },

    ["cola"] = {
        label = "E-Cola",
        type = "drink",
        weight = 0.4,
        stack = 15,
        usable = true,
        illegal = false,
        thirst = 25,
        description = "Buzlu kola."
    },

    ["coffee"] = {
        label = "Kahve",
        type = "drink",
        weight = 0.3,
        stack = 10,
        usable = true,
        illegal = false,
        thirst = 20,
        stress = -5,
        description = "Sıcak filtre kahve."
    },

    ["energydrink"] = {
        label = "Enerji İçeceği",
        type = "drink",
        weight = 0.3,
        stack = 10,
        usable = true,
        illegal = false,
        thirst = 15,
        stamina = 30,
        description = "Sprunk enerji içeceği."
    },

    -- ═══════════════════════════════════════════
    -- TIBBİ MALZEME
    -- ═══════════════════════════════════════════
    ["bandage"] = {
        label = "Bandaj",
        type = "medical",
        weight = 0.2,
        stack = 10,
        usable = true,
        illegal = false,
        heal = 25,
        description = "Basit ilk yardım bandajı."
    },

    ["firstaid"] = {
        label = "İlk Yardım Çantası",
        type = "medical",
        weight = 1.0,
        stack = 3,
        usable = true,
        illegal = false,
        heal = 75,
        description = "Tam donanımlı ilk yardım seti."
    },

    ["painkillers"] = {
        label = "Ağrı Kesici",
        type = "medical",
        weight = 0.1,
        stack = 20,
        usable = true,
        illegal = false,
        heal = 15,
        stress = -10,
        description = "Reçeteli ağrı kesici."
    },

    ["adrenaline"] = {
        label = "Adrenalin Şırınga",
        type = "medical",
        weight = 0.3,
        stack = 5,
        usable = true,
        illegal = false,
        heal = 50,
        revive = true,
        description = "Acil canlandırma iğnesi."
    },

    -- ═══════════════════════════════════════════
    -- ARAÇLAR & ALETLER
    -- ═══════════════════════════════════════════
    ["kelepce"] = {
        label = "Çelik Kelepçe",
        type = "tool",
        weight = 1.5,
        stack = 1,
        usable = true,
        illegal = false,
        description = "Polis tipi çelik kelepçe."
    },

    ["lockpick"] = {
        label = "Maymuncuk",
        type = "tool",
        weight = 0.3,
        stack = 5,
        usable = true,
        illegal = true,
        breakChance = 0.35,
        description = "Kapı ve araç kilidi açma aleti."
    },

    ["repairkit"] = {
        label = "Tamir Kiti",
        type = "tool",
        weight = 5.0,
        stack = 1,
        usable = true,
        illegal = false,
        description = "Araç tamir seti — motor, gövde, lastik."
    },

    ["advancedrepairkit"] = {
        label = "Gelişmiş Tamir Kiti",
        type = "tool",
        weight = 8.0,
        stack = 1,
        usable = true,
        illegal = false,
        description = "Profesyönel mekanik tamir kiti."
    },

    ["screwdriver"] = {
        label = "Tornavida",
        type = "tool",
        weight = 0.5,
        stack = 3,
        usable = true,
        illegal = false,
        description = "Çapraz tornavida."
    },

    ["binoculars"] = {
        label = "Dürbün",
        type = "tool",
        weight = 1.0,
        stack = 1,
        usable = true,
        illegal = false,
        description = "10x zoom dürbün."
    },

    ["camera"] = {
        label = "Kamera",
        type = "tool",
        weight = 1.5,
        stack = 1,
        usable = true,
        illegal = false,
        description = "Profesyönel fotoğraf makinesi."
    },

    ["rope"] = {
        label = "Halat",
        type = "tool",
        weight = 2.0,
        stack = 3,
        usable = true,
        illegal = false,
        description = "10 metre naylon halat."
    },

    ["fishingrod"] = {
        label = "Olta",
        type = "tool",
        weight = 3.0,
        stack = 1,
        usable = true,
        illegal = false,
        description = "Karbon fiber olta."
    },

    ["pickaxe"] = {
        label = "Kazma",
        type = "tool",
        weight = 4.0,
        stack = 1,
        usable = true,
        illegal = false,
        description = "Maden kazması."
    },

    -- ═══════════════════════════════════════════
    -- HAMMADDELER & MALZEME
    -- ═══════════════════════════════════════════
    ["iron"] = {
        label = "Demir Cevheri",
        type = "material",
        weight = 1.5,
        stack = 50,
        usable = false,
        illegal = false,
        description = "Ham demir cevheri."
    },

    ["steel"] = {
        label = "Çelik",
        type = "material",
        weight = 2.0,
        stack = 30,
        usable = false,
        illegal = false,
        description = "İşlenmiş çelik."
    },

    ["copper"] = {
        label = "Bakır",
        type = "material",
        weight = 1.0,
        stack = 50,
        usable = false,
        illegal = false,
        description = "Ham bakır."
    },

    ["gold"] = {
        label = "Altın Külçe",
        type = "material",
        weight = 5.0,
        stack = 10,
        usable = false,
        illegal = false,
        description = "Saf altın külçe."
    },

    ["diamond"] = {
        label = "Pırlanta",
        type = "material",
        weight = 0.1,
        stack = 20,
        usable = false,
        illegal = false,
        description = "Kesilmiş pırlanta."
    },

    ["wood"] = {
        label = "Odun",
        type = "material",
        weight = 2.0,
        stack = 40,
        usable = false,
        illegal = false,
        description = "Ham kereste parçası."
    },

    ["plastic"] = {
        label = "Plastik",
        type = "material",
        weight = 0.5,
        stack = 50,
        usable = false,
        illegal = false,
        description = "Geri dönüşüm plastiği."
    },

    ["rubber"] = {
        label = "Kauçuk",
        type = "material",
        weight = 0.8,
        stack = 30,
        usable = false,
        illegal = false,
        description = "Ham kauçuk."
    },

    ["glass"] = {
        label = "Cam",
        type = "material",
        weight = 0.6,
        stack = 30,
        usable = false,
        illegal = false,
        description = "Cam parçası."
    },

    ["electronics"] = {
        label = "Elektronik Devre",
        type = "material",
        weight = 0.3,
        stack = 30,
        usable = false,
        illegal = false,
        description = "Elektronik devre kartı."
    },

    -- ═══════════════════════════════════════════
    -- YASADIŞI MADDELER
    -- ═══════════════════════════════════════════
    ["weed_raw"] = {
        label = "Ham Ot",
        type = "drug",
        weight = 0.3,
        stack = 50,
        usable = false,
        illegal = true,
        description = "İşlenmemiş ot yaprağı."
    },

    ["weed_packed"] = {
        label = "Paketlenmiş Ot",
        type = "drug",
        weight = 0.2,
        stack = 30,
        usable = true,
        illegal = true,
        stress = -20,
        description = "Satışa hazır paket ot."
    },

    ["meth"] = {
        label = "Kristal Met",
        type = "drug",
        weight = 0.1,
        stack = 30,
        usable = true,
        illegal = true,
        stamina = 50,
        description = "Saf kristal met."
    },

    ["coke"] = {
        label = "Kokain",
        type = "drug",
        weight = 0.1,
        stack = 30,
        usable = true,
        illegal = true,
        stamina = 60,
        description = "İşlenmiş kokain."
    },

    -- ═══════════════════════════════════════════
    -- KİMLİK & EVRAK
    -- ═══════════════════════════════════════════
    ["id_card"] = {
        label = "Kimlik Kartı",
        type = "document",
        weight = 0.0,
        stack = 1,
        usable = true,
        illegal = false,
        description = "TC Kimlik kartı."
    },

    ["driver_license"] = {
        label = "Ehliyet",
        type = "document",
        weight = 0.0,
        stack = 1,
        usable = true,
        illegal = false,
        description = "B sınıfı sürücü belgesi."
    },

    ["weapon_license"] = {
        label = "Silah Ruhsatı",
        type = "document",
        weight = 0.0,
        stack = 1,
        usable = true,
        illegal = false,
        description = "Silah taşıma ruhsatı."
    },

    ["phone"] = {
        label = "Telefon",
        type = "electronics",
        weight = 0.2,
        stack = 1,
        usable = true,
        illegal = false,
        description = "iFruit akıllı telefon."
    },

    ["radio"] = {
        label = "Telsiz",
        type = "electronics",
        weight = 0.5,
        stack = 1,
        usable = true,
        illegal = false,
        description = "Taşınabilir telsiz cihazı."
    },

    -- ═══════════════════════════════════════════
    -- BALIK & AV
    -- ═══════════════════════════════════════════
    ["fish_bass"] = {
        label = "Levrek",
        type = "fish",
        weight = 1.2,
        stack = 10,
        usable = false,
        illegal = false,
        sellPrice = 50,
        description = "Taze levrek balığı."
    },

    ["fish_salmon"] = {
        label = "Somon",
        type = "fish",
        weight = 2.0,
        stack = 8,
        usable = false,
        illegal = false,
        sellPrice = 80,
        description = "Atlantik somonu."
    },

    ["animal_skin"] = {
        label = "Hayvan Derisi",
        type = "material",
        weight = 3.0,
        stack = 10,
        usable = false,
        illegal = false,
        sellPrice = 120,
        description = "İşlenmemiş hayvan derisi."
    },

    ["animal_meat"] = {
        label = "Çiğ Et",
        type = "food_raw",
        weight = 1.5,
        stack = 15,
        usable = false,
        illegal = false,
        sellPrice = 40,
        description = "Çiğ av eti — pişirilmeli."
    },

    -- ═══════════════════════════════════════════
    -- ANAHTAR & EV
    -- ═══════════════════════════════════════════
    ["carkey"] = {
        label = "Araç Anahtarı",
        type = "key",
        weight = 0.1,
        stack = 5,
        usable = true,
        illegal = false,
        description = "Araç kontak anahtarı."
    },

    ["housekey"] = {
        label = "Ev Anahtarı",
        type = "key",
        weight = 0.1,
        stack = 3,
        usable = true,
        illegal = false,
        description = "Ev kapısı anahtarı."
    },

    -- ═══════════════════════════════════════════
    -- SİLAH EKLERİ
    -- ═══════════════════════════════════════════
    ["pistol_ammo"] = {
        label = "Tabanca Mermisi",
        type = "ammo",
        weight = 0.05,
        stack = 250,
        usable = false,
        illegal = false,
        description = "9mm tabanca mermisi."
    },

    ["rifle_ammo"] = {
        label = "Tüfek Mermisi",
        type = "ammo",
        weight = 0.08,
        stack = 250,
        usable = false,
        illegal = true,
        description = "5.56mm tüfek mermisi."
    },

    ["shotgun_ammo"] = {
        label = "Pompalı Mermisi",
        type = "ammo",
        weight = 0.1,
        stack = 100,
        usable = false,
        illegal = true,
        description = "12 gauge pompalı fişeği."
    },

    ["smg_ammo"] = {
        label = "SMG Mermisi",
        type = "ammo",
        weight = 0.05,
        stack = 500,
        usable = false,
        illegal = true,
        description = ".45 ACP SMG mermisi."
    },

    -- ═══════════════════════════════════════════
    -- ARMOR & GİYİM
    -- ═══════════════════════════════════════════
    ["armor"] = {
        label = "Çelik Yelek",
        type = "armor",
        weight = 5.0,
        stack = 1,
        usable = true,
        illegal = false,
        armorValue = 100,
        description = "Seviye III balistik yelek."
    },

    ["helmet"] = {
        label = "Kask",
        type = "armor",
        weight = 1.5,
        stack = 1,
        usable = true,
        illegal = false,
        description = "Taktik kask."
    },
}

-- ============================================================================
-- Item API Fonksiyonları
-- ============================================================================

--- Yeni item oluştur
function CreateItem(itemName, options)
    IS4.Items.All[itemName] = {
        name = itemName,
        label = options.label or itemName,
        type = options.type or "item",
        weight = options.weight or 0,
        stack = options.stack or 1,
        usable = options.usable or false,
        illegal = options.illegal or false,
        description = options.description or "",
    }
    -- Ekstra alanları da kopyala (hunger, thirst, heal, vb.)
    for k, v in pairs(options) do
        if IS4.Items.All[itemName][k] == nil then
            IS4.Items.All[itemName][k] = v
        end
    end
    IS4.Logger.Info(("[Items] Item kaydedildi: %s"):format(itemName))
end
exports("CreateItem", CreateItem)

--- Item verisini getir
function GetItemData(itemName)
    return IS4.Items.All[itemName]
end
exports("GetItemData", GetItemData)

--- Tüm itemleri getir
function GetAllItems()
    return IS4.Items.All
end
exports("GetAllItems", GetAllItems)

--- Item tipine göre filtrele
function GetItemsByType(itemType)
    local result = {}
    for name, data in pairs(IS4.Items.All) do
        if data.type == itemType then
            result[name] = data
        end
    end
    return result
end
exports("GetItemsByType", GetItemsByType)

--- Oyuncuya item ver
function GiveItem(source, itemName, amount)
    local player = exports['is4-core']:GetPlayer(source)
    local itemData = IS4.Items.All[itemName]

    if not player then
        IS4.Logger.Warning(("[Items] Oyuncu bulunamadı: %s"):format(source))
        return false
    end

    if not itemData then
        IS4.Logger.Warning(("[Items] Tanımsız item: %s"):format(itemName))
        return false
    end

    -- Stack limiti kontrolü
    local currentAmount = player.inventory and player.inventory[itemName] or 0
    local maxStack = itemData.stack or 999
    if currentAmount + amount > maxStack then
        IS4.Logger.Warning(("[Items] Stack limiti aşıldı: %s (%d + %d > %d)"):format(itemName, currentAmount, amount, maxStack))
        return false
    end

    player.giveItem(itemName, amount)
    IS4.Logger.Info(("[Items] %sx %s → %s verildi"):format(amount, itemName, source))
    return true
end
exports("GiveItem", GiveItem)

--- Oyuncudan item al
function RemoveItem(source, itemName, amount)
    local player = exports['is4-core']:GetPlayer(source)
    if player then
        return player.removeItem(itemName, amount)
    end
    return false
end
exports("RemoveItem", RemoveItem)

--- Item kullanılabilir mi kontrol et
function CanUseItem(itemName)
    local data = IS4.Items.All[itemName]
    return data and data.usable == true
end
exports("CanUseItem", CanUseItem)

--- Item yasadışı mı kontrol et
function IsItemIllegal(itemName)
    local data = IS4.Items.All[itemName]
    return data and data.illegal == true
end
exports("IsItemIllegal", IsItemIllegal)
