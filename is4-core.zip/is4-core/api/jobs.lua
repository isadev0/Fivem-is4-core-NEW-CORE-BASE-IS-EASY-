if not IsDuplicityVersion() then return end

IS4.Jobs = {}

-- ============================================================================
-- IS4.Jobs.All — Tüm İş Tanımları
-- ============================================================================
IS4.Jobs.All = {

    -- ═══════════════════════════════════════════
    -- POLIS
    -- ═══════════════════════════════════════════
    ["police"] = {
        label = "Polis Departmanı",
        bossMenu = vector3(440.1, -981.2, 30.6),
        dutyPoint = vector3(441.8, -982.0, 30.6),
        armory = vector3(452.6, -980.0, 30.6),
        defaultGrade = 1,

        grades = {
            [1] = { label = "Kadro Polis",       salary = 1500 },
            [2] = { label = "Kıdemli Polis",     salary = 2000 },
            [3] = { label = "Dedektif",          salary = 2800 },
            [4] = { label = "Çavuş",             salary = 3500 },
            [5] = { label = "Komiser Yardımcısı", salary = 4500 },
            [6] = { label = "Komiser",           salary = 5500 },
            [7] = { label = "Müdür",             salary = 7000 },
        },

        permissions = {
            canUseArmory = true,
            canUseVehicles = true,
            canHire = false,
            canFire = false,
            canAccessMDT = true,
            canSetWaypoint = true,
        }
    },

    -- ═══════════════════════════════════════════
    -- AMBULANS / SAĞLIK
    -- ═══════════════════════════════════════════
    ["ambulance"] = {
        label = "Sağlık Bakanlığı",
        bossMenu = vector3(311.6, -592.8, 43.2),
        dutyPoint = vector3(309.4, -594.0, 43.2),
        armory = nil,
        defaultGrade = 1,

        grades = {
            [1] = { label = "Stajyer Paramedik",  salary = 1200 },
            [2] = { label = "Paramedik",           salary = 1800 },
            [3] = { label = "Kıdemli Paramedik",   salary = 2500 },
            [4] = { label = "Doktor",              salary = 3500 },
            [5] = { label = "Uzman Doktor",        salary = 4500 },
            [6] = { label = "Başhekim",            salary = 6000 },
        },

        permissions = {
            canUseArmory = false,
            canUseVehicles = true,
            canHire = false,
            canFire = false,
            canRevive = true,
            canHeal = true,
        }
    },

    -- ═══════════════════════════════════════════
    -- MEKANİK
    -- ═══════════════════════════════════════════
    ["mechanic"] = {
        label = "LS Customs Mekanik",
        bossMenu = vector3(-337.2, -134.8, 39.0),
        dutyPoint = vector3(-339.0, -136.0, 39.0),
        armory = nil,
        defaultGrade = 1,

        grades = {
            [1] = { label = "Çırak",        salary = 800  },
            [2] = { label = "Mekanik",       salary = 1500 },
            [3] = { label = "Usta Mekanik",  salary = 2500 },
            [4] = { label = "Şef Mekanik",   salary = 3500 },
            [5] = { label = "Patron",        salary = 5000 },
        },

        permissions = {
            canUseArmory = false,
            canUseVehicles = true,
            canHire = false,
            canFire = false,
            canRepair = true,
            canTuning = true,
        }
    },

    -- ═══════════════════════════════════════════
    -- TAKSİCİ
    -- ═══════════════════════════════════════════
    ["taxi"] = {
        label = "Downtown Cab Co.",
        bossMenu = vector3(903.3, -170.3, 74.0),
        dutyPoint = vector3(905.0, -172.0, 74.0),
        armory = nil,
        defaultGrade = 1,

        grades = {
            [1] = { label = "Yeni Şoför",      salary = 600  },
            [2] = { label = "Şoför",            salary = 1000 },
            [3] = { label = "Kıdemli Şoför",    salary = 1800 },
            [4] = { label = "Koordinatör",       salary = 2500 },
        },

        permissions = {
            canUseArmory = false,
            canUseVehicles = true,
            canHire = false,
            canFire = false,
        }
    },

    -- ═══════════════════════════════════════════
    -- AVCI / KARKAS İŞLEME
    -- ═══════════════════════════════════════════
    ["hunter"] = {
        label = "Avcılık & Doğa",
        bossMenu = vector3(-680.2, 5838.0, 17.3),
        dutyPoint = vector3(-678.0, 5836.0, 17.3),
        armory = vector3(-682.0, 5839.0, 17.3),
        defaultGrade = 1,

        grades = {
            [1] = { label = "Amatör Avcı",    salary = 500  },
            [2] = { label = "Avcı",            salary = 900  },
            [3] = { label = "Uzman Avcı",      salary = 1500 },
            [4] = { label = "Baş Avcı",        salary = 2200 },
        },

        permissions = {
            canUseArmory = true,
            canUseVehicles = false,
            canHire = false,
            canFire = false,
        }
    },

    -- ═══════════════════════════════════════════
    -- EMLAKÇI
    -- ═══════════════════════════════════════════
    ["realtor"] = {
        label = "Dynasty 8 Emlak",
        bossMenu = vector3(-706.5, 263.1, 83.1),
        dutyPoint = vector3(-708.0, 265.0, 83.1),
        armory = nil,
        defaultGrade = 1,

        grades = {
            [1] = { label = "Stajyer",        salary = 700  },
            [2] = { label = "Emlak Danışmanı", salary = 1500 },
            [3] = { label = "Kıdemli Danışman",salary = 2500 },
            [4] = { label = "Bölge Müdürü",    salary = 4000 },
        },

        permissions = {
            canUseArmory = false,
            canUseVehicles = false,
            canHire = false,
            canFire = false,
            canSellProperty = true,
        }
    },

    -- ═══════════════════════════════════════════
    -- GAZETECİ / MEDYA
    -- ═══════════════════════════════════════════
    ["reporter"] = {
        label = "Weazel News",
        bossMenu = vector3(-598.9, -929.7, 23.8),
        dutyPoint = vector3(-600.0, -931.0, 23.8),
        armory = nil,
        defaultGrade = 1,

        grades = {
            [1] = { label = "Stajyer Muhabir", salary = 600  },
            [2] = { label = "Muhabir",          salary = 1200 },
            [3] = { label = "Kıdemli Muhabir",  salary = 2000 },
            [4] = { label = "Editör",            salary = 3000 },
            [5] = { label = "Yayın Yönetmeni",  salary = 4000 },
        },

        permissions = {
            canUseArmory = false,
            canUseVehicles = true,
            canHire = false,
            canFire = false,
            canBroadcast = true,
        }
    },

    -- ═══════════════════════════════════════════
    -- ÇETECİ (GANG) JOB
    -- ═══════════════════════════════════════════
    ["gangmember"] = {
        label = "Sokak Çetesi",
        bossMenu = vector3(87.3, -1959.0, 21.1),
        dutyPoint = nil,
        armory = vector3(89.0, -1961.0, 21.1),
        defaultGrade = 1,

        grades = {
            [1] = { label = "Acemi",         salary = 0    },
            [2] = { label = "Asker",         salary = 0    },
            [3] = { label = "Tetikçi",       salary = 0    },
            [4] = { label = "Sağ Kol",       salary = 0    },
            [5] = { label = "Lider",         salary = 0    },
        },

        permissions = {
            canUseArmory = true,
            canUseVehicles = false,
            canHire = false,
            canFire = false,
        }
    },

    -- ═══════════════════════════════════════════
    -- İŞSİZ (varsayılan)
    -- ═══════════════════════════════════════════
    ["unemployed"] = {
        label = "İşsiz",
        bossMenu = nil,
        dutyPoint = nil,
        armory = nil,
        defaultGrade = 1,

        grades = {
            [1] = { label = "Vatandaş", salary = 200 },
        },

        permissions = {
            canUseArmory = false,
            canUseVehicles = false,
            canHire = false,
            canFire = false,
        }
    },

    -- ═══════════════════════════════════════════
    -- GÖREVLER İÇİN ÖRNEK JOB
    -- ═══════════════════════════════════════════
    ["trucker"] = {
        label = "TIR Şoförü",
        bossMenu = vector3(153.0, -3210.0, 5.9),
        dutyPoint = vector3(155.0, -3212.0, 5.9),
        armory = nil,
        defaultGrade = 1,

        grades = {
            [1] = { label = "Taşıyıcı",         salary = 700  },
            [2] = { label = "Kıdemli Taşıyıcı",  salary = 1200 },
            [3] = { label = "Filo Sorumlusu",     salary = 2000 },
            [4] = { label = "Lojistik Müdürü",    salary = 3000 },
        },

        permissions = {
            canUseArmory = false,
            canUseVehicles = true,
            canHire = false,
            canFire = false,
        }
    },

    -- ═══════════════════════════════════════════
    -- BALIKÇI
    -- ═══════════════════════════════════════════
    ["fisher"] = {
        label = "Balıkçılık",
        bossMenu = vector3(-1835.0, -1199.0, 14.3),
        dutyPoint = vector3(-1837.0, -1201.0, 14.3),
        armory = nil,
        defaultGrade = 1,

        grades = {
            [1] = { label = "Çırak Balıkçı",    salary = 400  },
            [2] = { label = "Balıkçı",           salary = 800  },
            [3] = { label = "Usta Balıkçı",      salary = 1400 },
            [4] = { label = "Kaptan",             salary = 2200 },
        },

        permissions = {
            canUseArmory = false,
            canUseVehicles = true,
            canHire = false,
            canFire = false,
        }
    },

    -- ═══════════════════════════════════════════
    -- MADENCI
    -- ═══════════════════════════════════════════
    ["miner"] = {
        label = "Maden İşçisi",
        bossMenu = vector3(2953.0, 2759.0, 43.6),
        dutyPoint = vector3(2955.0, 2761.0, 43.6),
        armory = nil,
        defaultGrade = 1,

        grades = {
            [1] = { label = "İşçi",           salary = 600  },
            [2] = { label = "Kıdemli İşçi",   salary = 1000 },
            [3] = { label = "Usta",            salary = 1700 },
            [4] = { label = "Maden Müdürü",    salary = 2800 },
        },

        permissions = {
            canUseArmory = false,
            canUseVehicles = false,
            canHire = false,
            canFire = false,
        }
    },
}

-- ============================================================================
-- Job API Fonksiyonları
-- ============================================================================

--- Yeni iş oluştur veya mevcut üzerine yaz
function CreateJob(jobName, options)
    IS4.Jobs.All[jobName] = options
    IS4.Logger.Info(("[Jobs] İş oluşturuldu: %s"):format(jobName))
end
exports("CreateJob", CreateJob)

--- İş verisini getir
function GetJob(jobName)
    return IS4.Jobs.All[jobName]
end
exports("GetJob", GetJob)

--- İşe başlat (oyuncuyu)
function StartJob(source, jobName, grade)
    local player = exports['is4-core']:GetPlayer(source)
    local jobData = IS4.Jobs.All[jobName]

    if not player then
        IS4.Logger.Warning(("[Jobs] Oyuncu bulunamadı: %s"):format(source))
        return false
    end

    if not jobData then
        IS4.Logger.Warning(("[Jobs] Tanımsız iş: %s"):format(jobName))
        return false
    end

    local assignedGrade = grade or jobData.defaultGrade or 1
    local gradeData = jobData.grades[assignedGrade]

    player.set("job", {
        name = jobName,
        label = jobData.label,
        grade = assignedGrade,
        gradeLabel = gradeData and gradeData.label or "Bilinmeyen",
        salary = gradeData and gradeData.salary or 0,
        permissions = jobData.permissions or {}
    })

    -- Trigger module event if exists
    if IS4.Modules and IS4.Modules[jobName] and IS4.Modules[jobName].events and IS4.Modules[jobName].events.onPlayerStart then
        IS4.Modules[jobName].events.onPlayerStart(source)
    end

    IS4.Logger.Info(("[Jobs] %s → %s (%s) olarak atandı"):format(source, jobName, gradeData and gradeData.label or "?"))
    return true
end
exports("StartJob", StartJob)

--- İş derecesini yükselt
function SetJobGrade(source, grade)
    local player = exports['is4-core']:GetPlayer(source)
    if not player or not player.job then return false end

    local jobName = type(player.job) == "table" and player.job.name or player.job
    local jobData = IS4.Jobs.All[jobName]
    if not jobData or not jobData.grades[grade] then return false end

    local gradeData = jobData.grades[grade]
    player.set("job", {
        name = jobName,
        label = jobData.label,
        grade = grade,
        gradeLabel = gradeData.label,
        salary = gradeData.salary,
        permissions = jobData.permissions or {}
    })

    IS4.Logger.Info(("[Jobs] %s → %s derecesi %d olarak güncellendi"):format(source, jobName, grade))
    return true
end
exports("SetJobGrade", SetJobGrade)

--- Tüm işleri listele
function GetAllJobs()
    return IS4.Jobs.All
end
exports("GetAllJobs", GetAllJobs)

--- İşten çıkar (unemployed'a ata)
function FirePlayer(source)
    return StartJob(source, "unemployed", 1)
end
exports("FirePlayer", FirePlayer)
