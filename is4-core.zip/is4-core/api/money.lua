if not IsDuplicityVersion() then return end

IS4.Economy = {}

-- ============================================================================
-- IS4.Economy.All — Para Sistemi Tanımları
-- ============================================================================
IS4.Economy.All = {

    -- ═══════════════════════════════════════════
    -- NAKİT PARA
    -- ═══════════════════════════════════════════
    cash = {
        label = "Nakit Para",
        maxCarry = 100000,
        starting = 500
    },

    -- ═══════════════════════════════════════════
    -- BANKA HESABI
    -- ═══════════════════════════════════════════
    bank = {
        label = "Banka Hesabı",
        maxCarry = 10000000,
        starting = 5000,
        interest = 0.01
    },

    -- ═══════════════════════════════════════════
    -- KARA PARA
    -- ═══════════════════════════════════════════
    blackmoney = {
        label = "Kara Para",
        maxCarry = 500000,
        starting = 0,
        illegal = true
    },
}

-- ============================================================================
-- ATM KONUMLARI
-- ============================================================================
IS4.Economy.ATMLocations = {
    vector3(149.4, -1040.2, 29.3),
    vector3(228.0, 337.8, 105.5),
    vector3(-386.7, 6046.0, 31.5),
    vector3(-284.0, 6224.3, 31.1),
    vector3(-135.1, 6365.8, 31.1),
    vector3(-711.1, -818.4, 23.7),
    vector3(-256.6, -715.8, 33.4),
    vector3(5.6, -919.9, 29.5),
    vector3(296.1, -895.0, 29.2),
    vector3(-537.8, -854.4, 29.2),
    vector3(-1315.7, -834.8, 16.9),
    vector3(-1570.7, -546.6, 34.9),
    vector3(-2072.4, -317.2, 13.3),
    vector3(1137.8, -468.8, 66.7),
    vector3(1167.0, -456.0, 66.7),
    vector3(289.4, -1282.3, 29.6),
}

-- ============================================================================
-- BANKA KONUMLARI
-- ============================================================================
IS4.Economy.BankLocations = {
    { coords = vector3(149.5, -1042.1, 29.3),  label = "Pacific Standard" },
    { coords = vector3(313.8, -280.5, 54.1),    label = "Fleeca Hawick" },
    { coords = vector3(-351.5, -51.1, 49.0),    label = "Fleeca Burton" },
    { coords = vector3(-1213.0, -331.4, 37.7),  label = "Fleeca Del Perro" },
    { coords = vector3(-2961.5, 482.6, 15.7),   label = "Fleeca Highway" },
    { coords = vector3(1175.0, 2706.8, 38.0),   label = "Fleeca Sandy" },
    { coords = vector3(-112.2, 6469.1, 31.6),   label = "Fleeca Paleto" },
}

-- ============================================================================
-- Economy API Fonksiyonları
-- ============================================================================

--- Oyuncunun parasını getir (tip bazlı)
function GetMoney(source, moneyType)
    local player = exports['is4-core']:GetPlayer(source)
    if not player then return 0 end

    moneyType = moneyType or "cash"
    if type(player.money) == "table" then
        return player.money[moneyType] or 0
    end
    return player.money or 0
end
exports("GetMoney", GetMoney)

--- Oyuncunun tüm para bilgilerini getir
function GetAllMoney(source)
    local player = exports['is4-core']:GetPlayer(source)
    if not player then return {} end

    if type(player.money) == "table" then
        return player.money
    end
    return { cash = player.money or 0, bank = 0 }
end
exports("GetAllMoney", GetAllMoney)

--- Para ekle (tipe göre)
function AddMoney(source, moneyType, amount)
    local player = exports['is4-core']:GetPlayer(source)
    if not player then return false end

    moneyType = moneyType or "cash"
    local typeData = IS4.Economy.All[moneyType]

    if not typeData then
        IS4.Logger.Warning(("[Economy] Geçersiz para tipi: %s"):format(moneyType))
        return false
    end

    if amount <= 0 then
        IS4.Logger.Warning(("[Economy] Geçersiz miktar: %s"):format(amount))
        return false
    end

    -- maxCarry kontrolü
    local currentMoney = type(player.money) == "table" and (player.money[moneyType] or 0) or 0
    if currentMoney + amount > typeData.maxCarry then
        IS4.Logger.Warning(("[Economy] maxCarry aşıldı: %s (%d + %d > %d)"):format(moneyType, currentMoney, amount, typeData.maxCarry))
        return false
    end

    player.addMoney(moneyType, amount)
    IS4.Logger.Info(("[Economy] +$%s %s → %s"):format(amount, typeData.label, source))
    return true
end
exports("AddMoney", AddMoney)

--- Para çıkar (tipe göre)
function RemoveMoney(source, moneyType, amount)
    local player = exports['is4-core']:GetPlayer(source)
    if not player then return false end

    moneyType = moneyType or "cash"
    local typeData = IS4.Economy.All[moneyType]

    if not typeData then
        IS4.Logger.Warning(("[Economy] Geçersiz para tipi: %s"):format(moneyType))
        return false
    end

    if amount <= 0 then return false end

    local success = player.removeMoney(moneyType, amount)
    if success then
        IS4.Logger.Info(("[Economy] -$%s %s → %s"):format(amount, typeData.label, source))
    end
    return success
end
exports("RemoveMoney", RemoveMoney)

--- Para transferi (oyuncudan oyuncuya)
function TransferMoney(source, targetSource, moneyType, amount)
    local srcPlayer = exports['is4-core']:GetPlayer(source)
    local tgtPlayer = exports['is4-core']:GetPlayer(targetSource)

    if not srcPlayer or not tgtPlayer then
        IS4.Logger.Warning("[Economy] Transfer: Oyuncu bulunamadı")
        return false
    end

    moneyType = moneyType or "cash"
    local typeData = IS4.Economy.All[moneyType]

    if not typeData then
        IS4.Logger.Warning(("[Economy] Geçersiz para tipi: %s"):format(moneyType))
        return false
    end

    -- Kara para transfer edilemez
    if typeData.illegal then
        IS4.Logger.Warning(("[Economy] Yasadışı para tipi transfer edilemez: %s"):format(moneyType))
        return false
    end

    local currentMoney = type(srcPlayer.money) == "table" and srcPlayer.money[moneyType] or 0
    if currentMoney < amount then
        IS4.Logger.Warning("[Economy] Yetersiz bakiye")
        return false
    end

    srcPlayer.removeMoney(moneyType, amount)
    tgtPlayer.addMoney(moneyType, amount)

    IS4.Logger.Info(("[Economy] Transfer: %s → %s | $%s %s"):format(source, targetSource, amount, typeData.label))
    return true
end
exports("TransferMoney", TransferMoney)

--- Para ayarla (direkt set)
function SetMoney(source, moneyType, amount)
    local player = exports['is4-core']:GetPlayer(source)
    if not player then return false end

    moneyType = moneyType or "cash"
    if type(player.money) ~= "table" then
        player.money = { cash = 0, bank = 0, blackmoney = 0 }
    end
    player.money[moneyType] = amount
    player.isDirty = true

    IS4.Logger.Info(("[Economy] Set $%s %s → %s"):format(amount, moneyType, source))
    return true
end
exports("SetMoney", SetMoney)

--- Bakiye kontrol
function HasMoney(source, moneyType, amount)
    local currentMoney = GetMoney(source, moneyType)
    return currentMoney >= amount
end
exports("HasMoney", HasMoney)

--- Para tipi bilgisi getir
function GetMoneyTypeData(moneyType)
    return IS4.Economy.All[moneyType]
end
exports("GetMoneyTypeData", GetMoneyTypeData)
