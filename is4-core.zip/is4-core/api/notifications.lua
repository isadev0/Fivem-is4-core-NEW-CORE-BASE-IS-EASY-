-- Notifications API Wrapper (Server & Client side routing)

if IsDuplicityVersion() then
    -- Server side sends to client
    function SendNotification(source, text)
        TriggerClientEvent('is4-core:client:SendNotification', source, text)
    end
    exports("SendNotification", SendNotification)
else
    -- Client side receives and displays
    RegisterNetEvent('is4-core:client:SendNotification', function(text)
        SetTextComponentFormat("STRING")
        AddTextComponentString(text)
        DisplayHelpTextFromStringLabel(0, 0, 1, -1)
        print(("^3[Notification]^7 %s"):format(text))
    end)

    function SendNotification(text)
        TriggerEvent('is4-core:client:SendNotification', text)
    end
    exports("SendNotification", SendNotification)
end
