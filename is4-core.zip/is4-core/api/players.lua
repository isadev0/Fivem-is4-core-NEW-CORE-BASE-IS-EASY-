-- api/players.lua
if not IsDuplicityVersion() then return end

IS4.Players = {}

-- ============================================================================
-- IS4.Players.All — Oyuncu Sistemi Tanımları
-- ============================================================================
IS4.Players.All = {

    -- ═══════════════════════════════════════════
    -- KARAKTER OLUŞTURMA ŞABLONU
    -- ═══════════════════════════════════════════
    CharacterTemplate = {
        identity = {
            firstname = "",
            lastname = "",
            dob = "01/01/2000",
            gender = 0,              -- 0 = Erkek, 1 = Kadın
            nationality = "TC",
            phone = "555-0000",
            bloodtype = "A+",
            fingerprint = "",
        },

        status = {
            hunger = 100,
            thirst = 100,
            stress = 0,
            stamina = 100,
            armor = 0,
            isDead = false,
            isHandcuffed = false,
            isUnconscious = false,
        },

        appearance = {
            model = "mp_m_freemode_01",
            skin = {},
            clothing = {},
        },

        position = {
            coords = vector3(-1036.96, -2740.06, 13.78),
            heading = 330.0,
            lastUpdated = 0,
        },

        licenses = {
            driver = false,
            weapon = false,
            hunting = false,
            fishing = false,
            pilot = false,
            boat = false,
        },
    },

    -- ═══════════════════════════════════════════
    -- İHTİYAÇ SİSTEMİ AYARLARI
    -- ═══════════════════════════════════════════
    NeedsSystem = {
        HungerDecayRate = 0.5,      -- Her dakika düşen açlık
        ThirstDecayRate = 0.7,      -- Her dakika düşen susuzluk
        StressDecayRate = 0.2,      -- Her dakika düşen stres (doğal)
        StaminaRegenRate = 1.0,     -- Her dakika artan dayanıklılık (dinlenirken)
        DecayInterval = 60,         -- Saniye (ihtiyaç güncelleme aralığı)
        DamageThreshold = 10,       -- Bu değerin altında hasar almaya başlar
        FaintThreshold = 0,         -- Bu değere ulaşınca bayılır
    },

    -- ═══════════════════════════════════════════
    -- SPAWN AYARLARI
    -- ═══════════════════════════════════════════
    SpawnSettings = {
        DefaultSpawn = vector4(-1036.96, -2740.06, 13.78, 330.0),    -- LSIA
        HospitalSpawn = vector4(311.6, -592.8, 43.2, 70.0),         -- Pillbox Hospital
        JailSpawn = vector4(1680.0, 2513.0, 45.5, 0.0),             -- Bolingbroke
        MaxCharacters = 4,
        SpawnInvincibilityTimer = 5000,     -- ms
        AutoSaveInterval = 300,             -- saniye (5 dakika)
    },

    -- ═══════════════════════════════════════════
    -- KAN GRUPLARI
    -- ═══════════════════════════════════════════
    BloodTypes = { "A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-" },

    -- ═══════════════════════════════════════════
    -- ROLLER
    -- ═══════════════════════════════════════════
    Roles = {
        ["user"]       = { level = 0, label = "Oyuncu",        color = "^7" },
        ["vip"]        = { level = 1, label = "VIP",           color = "^5" },
        ["mod"]        = { level = 2, label = "Moderatör",     color = "^3" },
        ["admin"]      = { level = 3, label = "Admin",         color = "^1" },
        ["superadmin"] = { level = 4, label = "Süper Admin",   color = "^6" },
        ["owner"]      = { level = 5, label = "Sunucu Sahibi", color = "^2" },
    },
}

-- ============================================================================
-- Players API Fonksiyonları
-- ============================================================================

--- Oyuncu verisini getir
function GetPlayerData(source)
    local player = exports['is4-core']:GetPlayer(source)
    if not player then return nil end

    return {
        source = source,
        identifier = player.identifier,
        money = player.money,
        job = player.job,
        inventory = player.inventory,
        metadata = player.metadata or {},
        isDirty = player.isDirty,
    }
end
exports("GetPlayerData", GetPlayerData)

--- Oyuncu tam profilini getir
function GetFullProfile(source)
    local player = exports['is4-core']:GetPlayer(source)
    if not player then return nil end

    local meta = player.metadata or {}
    return {
        source = source,
        identifier = player.identifier,
        identity = {
            firstname = meta.firstname or "Bilinmeyen",
            lastname = meta.lastname or "Bilinmeyen",
            dob = meta.dob or "01/01/2000",
            gender = meta.gender or 0,
            nationality = meta.nationality or "TC",
            phone = meta.phone or "555-0000",
            bloodtype = meta.bloodtype or "O+",
            fingerprint = meta.fingerprint or "",
        },
        money = player.money,
        job = player.job,
        inventory = player.inventory,
        licenses = meta.licenses or IS4.Players.All.CharacterTemplate.licenses,
        status = meta.status or IS4.Players.All.CharacterTemplate.status,
    }
end
exports("GetFullProfile", GetFullProfile)

--- Metadata ayarla
function SetPlayerMetadata(source, key, value)
    local player = exports['is4-core']:GetPlayer(source)
    if not player then return false end

    if not player.metadata then player.metadata = {} end
    player.metadata[key] = value
    player.isDirty = true

    IS4.Logger.Info(("[Players] Metadata güncellendi: %s → %s = %s"):format(source, key, tostring(value)))
    return true
end
exports("SetPlayerMetadata", SetPlayerMetadata)

--- Metadata getir
function GetPlayerMetadata(source, key)
    local player = exports['is4-core']:GetPlayer(source)
    if not player or not player.metadata then return nil end
    return player.metadata[key]
end
exports("GetPlayerMetadata", GetPlayerMetadata)

--- Oyuncunun işini ayarla
function SetPlayerJob(source, jobName, grade)
    -- Jobs API'ye yönlendir
    return exports['is4-core']:StartJob(source, jobName, grade)
end
exports("SetPlayerJob", SetPlayerJob)

--- Oyuncunun kimlik bilgilerini getir
function GetIdentity(source)
    local player = exports['is4-core']:GetPlayer(source)
    if not player or not player.metadata then return nil end

    return {
        firstname = player.metadata.firstname or "Bilinmeyen",
        lastname = player.metadata.lastname or "Bilinmeyen",
        dob = player.metadata.dob or "?",
        gender = player.metadata.gender or 0,
        phone = player.metadata.phone or "?",
        bloodtype = player.metadata.bloodtype or "?",
    }
end
exports("GetIdentity", GetIdentity)

--- Lisans ver
function GiveLicense(source, licenseType)
    local player = exports['is4-core']:GetPlayer(source)
    if not player then return false end

    if not player.metadata then player.metadata = {} end
    if not player.metadata.licenses then
        player.metadata.licenses = IS4.Players.All.CharacterTemplate.licenses
    end

    player.metadata.licenses[licenseType] = true
    player.isDirty = true
    IS4.Logger.Info(("[Players] Lisans verildi: %s → %s"):format(source, licenseType))
    return true
end
exports("GiveLicense", GiveLicense)

--- Lisans kontrol
function HasLicense(source, licenseType)
    local player = exports['is4-core']:GetPlayer(source)
    if not player or not player.metadata or not player.metadata.licenses then return false end
    return player.metadata.licenses[licenseType] == true
end
exports("HasLicense", HasLicense)

--- Lisans kaldır
function RevokeLicense(source, licenseType)
    local player = exports['is4-core']:GetPlayer(source)
    if not player or not player.metadata or not player.metadata.licenses then return false end

    player.metadata.licenses[licenseType] = false
    player.isDirty = true
    IS4.Logger.Info(("[Players] Lisans kaldırıldı: %s → %s"):format(source, licenseType))
    return true
end
exports("RevokeLicense", RevokeLicense)

--- Oyuncu rolünü getir
function GetPlayerRole(source)
    local player = exports['is4-core']:GetPlayer(source)
    if not player or not player.metadata then return IS4.Players.All.Roles["user"] end
    local roleName = player.metadata.role or "user"
    return IS4.Players.All.Roles[roleName] or IS4.Players.All.Roles["user"]
end
exports("GetPlayerRole", GetPlayerRole)

--- Tüm online oyuncuları getir
function GetAllPlayers()
    local pm = exports['is4-core']:GetPlayerManager()
    if pm then
        return pm.GetPlayers()
    end
    return {}
end
exports("GetAllPlayers", GetAllPlayers)

--- Online oyuncu sayısı
function GetPlayerCount()
    local players = GetAllPlayers()
    local count = 0
    for _ in pairs(players) do count = count + 1 end
    return count
end
exports("GetPlayerCount", GetPlayerCount)
