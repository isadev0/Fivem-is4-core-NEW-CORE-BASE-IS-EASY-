if not IsDuplicityVersion() then return end

IS4.Vehicles = {}

-- ============================================================================
-- IS4.Vehicles.All — Tüm Araç Tanımları
-- ============================================================================
IS4.Vehicles.All = {

    -- ═══════════════════════════════════════════
    -- KOMPAKT
    -- ═══════════════════════════════════════════
    ["blista"] = {
        label = "Blista",
        price = 15000,
        category = "compacts",
        seats = 4,
        maxSpeed = 150,
        shopCategory = "economy",
        fuel = 100,
        trunkSlots = 15,
        description = "Ekonomik şehir aracı."
    },

    ["issi2"] = {
        label = "Issi",
        price = 18000,
        category = "compacts",
        seats = 2,
        maxSpeed = 140,
        shopCategory = "economy",
        fuel = 100,
        trunkSlots = 10,
        description = "Minik İtalyan aracı."
    },

    -- ═══════════════════════════════════════════
    -- SEDAN
    -- ═══════════════════════════════════════════
    ["sultan"] = {
        label = "Sultan",
        price = 25000,
        category = "sedans",
        seats = 4,
        maxSpeed = 170,
        shopCategory = "standard",
        fuel = 100,
        trunkSlots = 25,
        description = "Güvenilir aile sedanı."
    },

    ["stanier"] = {
        label = "Stanier",
        price = 20000,
        category = "sedans",
        seats = 4,
        maxSpeed = 155,
        shopCategory = "standard",
        fuel = 100,
        trunkSlots = 30,
        description = "Geniş Amerikan sedanı."
    },

    ["schafter2"] = {
        label = "Schafter V12",
        price = 65000,
        category = "sedans",
        seats = 4,
        maxSpeed = 200,
        shopCategory = "luxury",
        fuel = 100,
        trunkSlots = 20,
        description = "Lüks Alman sedanı."
    },

    -- ═══════════════════════════════════════════
    -- SPOR
    -- ═══════════════════════════════════════════
    ["elegy2"] = {
        label = "Elegy RH8",
        price = 95000,
        category = "sports",
        seats = 2,
        maxSpeed = 220,
        shopCategory = "sports",
        fuel = 100,
        trunkSlots = 10,
        description = "Japon spor klasiği."
    },

    ["jester"] = {
        label = "Jester",
        price = 120000,
        category = "sports",
        seats = 2,
        maxSpeed = 230,
        shopCategory = "sports",
        fuel = 100,
        trunkSlots = 8,
        description = "Agresif spor otomobil."
    },

    ["comet2"] = {
        label = "Comet",
        price = 150000,
        category = "sports",
        seats = 2,
        maxSpeed = 240,
        shopCategory = "sports",
        fuel = 100,
        trunkSlots = 5,
        description = "Alman mühendisliği spor araba."
    },

    -- ═══════════════════════════════════════════
    -- SÜPER
    -- ═══════════════════════════════════════════
    ["adder"] = {
        label = "Adder",
        price = 1000000,
        category = "super",
        seats = 2,
        maxSpeed = 300,
        shopCategory = "super",
        fuel = 100,
        trunkSlots = 3,
        description = "Dünyanın en hızlı araçlarından biri."
    },

    ["zentorno"] = {
        label = "Zentorno",
        price = 750000,
        category = "super",
        seats = 2,
        maxSpeed = 290,
        shopCategory = "super",
        fuel = 100,
        trunkSlots = 3,
        description = "İtalyan süper spor."
    },

    ["t20"] = {
        label = "T20",
        price = 2200000,
        category = "super",
        seats = 2,
        maxSpeed = 310,
        shopCategory = "super",
        fuel = 100,
        trunkSlots = 2,
        description = "Hibrit süper araba."
    },

    -- ═══════════════════════════════════════════
    -- MUSCLE
    -- ═══════════════════════════════════════════
    ["gauntlet"] = {
        label = "Gauntlet",
        price = 55000,
        category = "muscle",
        seats = 2,
        maxSpeed = 200,
        shopCategory = "muscle",
        fuel = 100,
        trunkSlots = 15,
        description = "Klasik Amerikan kas arabası."
    },

    ["dominator"] = {
        label = "Dominator",
        price = 65000,
        category = "muscle",
        seats = 2,
        maxSpeed = 210,
        shopCategory = "muscle",
        fuel = 100,
        trunkSlots = 12,
        description = "V8 motorlu kas arabası."
    },

    -- ═══════════════════════════════════════════
    -- SUV
    -- ═══════════════════════════════════════════
    ["baller"] = {
        label = "Baller",
        price = 90000,
        category = "suvs",
        seats = 4,
        maxSpeed = 180,
        shopCategory = "luxury",
        fuel = 100,
        trunkSlots = 40,
        description = "Lüks büyük SUV."
    },

    ["granger"] = {
        label = "Granger",
        price = 60000,
        category = "suvs",
        seats = 8,
        maxSpeed = 160,
        shopCategory = "standard",
        fuel = 100,
        trunkSlots = 50,
        description = "8 kişilik geniş SUV."
    },

    -- ═══════════════════════════════════════════
    -- MOTOSİKLET
    -- ═══════════════════════════════════════════
    ["bati"] = {
        label = "Bati 801",
        price = 45000,
        category = "motorcycles",
        seats = 2,
        maxSpeed = 230,
        shopCategory = "motorcycles",
        fuel = 100,
        trunkSlots = 3,
        description = "Yüksek performanslı spor motor."
    },

    ["sanchez"] = {
        label = "Sanchez",
        price = 15000,
        category = "motorcycles",
        seats = 2,
        maxSpeed = 160,
        shopCategory = "motorcycles",
        fuel = 100,
        trunkSlots = 2,
        description = "Arazi motosikleti."
    },

    ["hexer"] = {
        label = "Hexer",
        price = 35000,
        category = "motorcycles",
        seats = 2,
        maxSpeed = 180,
        shopCategory = "motorcycles",
        fuel = 100,
        trunkSlots = 5,
        description = "Chopper tarzı motosiklet."
    },

    -- ═══════════════════════════════════════════
    -- VAN & TİCARİ
    -- ═══════════════════════════════════════════
    ["speedo"] = {
        label = "Speedo",
        price = 30000,
        category = "vans",
        seats = 2,
        maxSpeed = 130,
        shopCategory = "commercial",
        fuel = 100,
        trunkSlots = 80,
        description = "Ticari kargo vanı."
    },

    ["youga"] = {
        label = "Youga",
        price = 22000,
        category = "vans",
        seats = 4,
        maxSpeed = 120,
        shopCategory = "commercial",
        fuel = 100,
        trunkSlots = 60,
        description = "Retro minivan."
    },

    -- ═══════════════════════════════════════════
    -- ACİL DURUM (SADECE JOB ARAÇLARI)
    -- ═══════════════════════════════════════════
    ["police"] = {
        label = "Polis Aracı",
        price = 0,
        category = "emergency",
        seats = 4,
        maxSpeed = 240,
        shopCategory = nil,
        fuel = 100,
        trunkSlots = 20,
        jobLocked = "police",
        description = "LSPD devriye aracı."
    },

    ["police2"] = {
        label = "Polis SUV",
        price = 0,
        category = "emergency",
        seats = 4,
        maxSpeed = 220,
        shopCategory = nil,
        fuel = 100,
        trunkSlots = 35,
        jobLocked = "police",
        description = "LSPD taktik SUV."
    },

    ["ambulance"] = {
        label = "Ambulans",
        price = 0,
        category = "emergency",
        seats = 4,
        maxSpeed = 180,
        shopCategory = nil,
        fuel = 100,
        trunkSlots = 30,
        jobLocked = "ambulance",
        description = "Acil sağlık aracı."
    },

    ["firetruk"] = {
        label = "İtfaiye",
        price = 0,
        category = "emergency",
        seats = 4,
        maxSpeed = 140,
        shopCategory = nil,
        fuel = 100,
        trunkSlots = 40,
        jobLocked = "fire",
        description = "İtfaiye aracı."
    },

    ["flatbed"] = {
        label = "Çekici",
        price = 0,
        category = "emergency",
        seats = 2,
        maxSpeed = 120,
        shopCategory = nil,
        fuel = 100,
        trunkSlots = 10,
        jobLocked = "mechanic",
        description = "Mekanik çekici aracı."
    },
}

-- ============================================================================
-- Vehicle API Fonksiyonları
-- ============================================================================

--- Araç kaydı oluştur
function CreateVehicle(modelName, options)
    IS4.Vehicles.All[modelName] = {
        model = modelName,
        label = options.label or modelName,
        price = options.price or 0,
        category = options.category or "compacts",
        seats = options.seats or 2,
        maxSpeed = options.maxSpeed or 150,
        shopCategory = options.shopCategory or "economy",
        fuel = options.fuel or 100,
        trunkSlots = options.trunkSlots or 10,
        jobLocked = options.jobLocked or nil,
        description = options.description or "",
    }
    IS4.Logger.Info(("[Vehicles] Araç kaydedildi: %s"):format(modelName))
end
exports("CreateVehicle", CreateVehicle)

--- Araç verisi getir
function GetVehicleData(modelName)
    return IS4.Vehicles.All[modelName]
end
exports("GetVehicleData", GetVehicleData)

--- Tüm araçları getir
function GetAllVehicles()
    return IS4.Vehicles.All
end
exports("GetAllVehicles", GetAllVehicles)

--- Kategoriye göre araçları getir
function GetVehiclesByCategory(category)
    local result = {}
    for model, data in pairs(IS4.Vehicles.All) do
        if data.category == category then
            result[model] = data
        end
    end
    return result
end
exports("GetVehiclesByCategory", GetVehiclesByCategory)

--- Mağaza kategorisine göre araçları getir
function GetShopVehicles(shopCategory)
    local result = {}
    for model, data in pairs(IS4.Vehicles.All) do
        if data.shopCategory == shopCategory and not data.jobLocked then
            result[model] = data
        end
    end
    return result
end
exports("GetShopVehicles", GetShopVehicles)

--- Araç spawn et
function SpawnVehicle(source, model, coords, heading)
    local vehData = IS4.Vehicles.All[model]
    if not vehData then
        IS4.Logger.Warning(("[Vehicles] Tanımsız araç modeli: %s"):format(model))
        return false
    end

    -- Job kilidi kontrolü
    if vehData.jobLocked then
        local player = exports['is4-core']:GetPlayer(source)
        if player then
            local playerJob = type(player.job) == "table" and player.job.name or player.job
            if playerJob ~= vehData.jobLocked then
                IS4.Logger.Warning(("[Vehicles] İş kilidi: %s → %s gerekli"):format(model, vehData.jobLocked))
                return false
            end
        end
    end

    IS4.Events.emit("is4-core:vehicleSpawned", { source = source, model = model, coords = coords })
    IS4.Logger.Info(("[Vehicles] %s aracı spawn edildi → %s"):format(model, source))
    return true
end
exports("SpawnVehicle", SpawnVehicle)

--- Araç sil
function DeleteVehicle(source)
    IS4.Events.emit("is4-core:vehicleDeleted", { source = source })
    IS4.Logger.Info(("[Vehicles] Araç silindi → %s"):format(source))
end
exports("DeleteVehicle", DeleteVehicle)

--- Araç fiyatını getir
function GetVehiclePrice(model)
    local data = IS4.Vehicles.All[model]
    return data and data.price or 0
end
exports("GetVehiclePrice", GetVehiclePrice)
