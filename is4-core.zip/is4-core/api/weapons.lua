if not IsDuplicityVersion() then return end

IS4.Weapons = {}

-- ============================================================================
-- IS4.Weapons.All — Tüm Silah Tanımları
-- ============================================================================
IS4.Weapons.All = {

    -- ═══════════════════════════════════════════
    -- TABANCALAR
    -- ═══════════════════════════════════════════
    ["WEAPON_PISTOL"] = {
        label = "Tabanca",
        hash = `WEAPON_PISTOL`,
        damageType = "bullet",
        ammoType = "pistol_ammo",
        maxAmmo = 250,
        price = 5000,
        isIllegal = false,
        licenseRequired = true,
        durability = 100,
        degradationRate = 0.5,
        category = "pistols",
        description = "Standart 9mm tabanca."
    },

    ["WEAPON_COMBATPISTOL"] = {
        label = "Muharebe Tabancası",
        hash = `WEAPON_COMBATPISTOL`,
        damageType = "bullet",
        ammoType = "pistol_ammo",
        maxAmmo = 250,
        price = 8500,
        isIllegal = false,
        licenseRequired = true,
        durability = 100,
        degradationRate = 0.4,
        category = "pistols",
        description = "Kompakt taktik tabanca."
    },

    ["WEAPON_APPISTOL"] = {
        label = "AP Tabanca",
        hash = `WEAPON_APPISTOL`,
        damageType = "bullet",
        ammoType = "pistol_ammo",
        maxAmmo = 250,
        price = 12000,
        isIllegal = true,
        licenseRequired = true,
        durability = 100,
        degradationRate = 0.6,
        category = "pistols",
        description = "Zırh delici otomatik tabanca."
    },

    ["WEAPON_PISTOL50"] = {
        label = ".50 Tabanca",
        hash = `WEAPON_PISTOL50`,
        damageType = "bullet",
        ammoType = "pistol_ammo",
        maxAmmo = 200,
        price = 15000,
        isIllegal = true,
        licenseRequired = true,
        durability = 100,
        degradationRate = 0.8,
        category = "pistols",
        description = "Ağır kalibre el silahı."
    },

    ["WEAPON_SNSPISTOL"] = {
        label = "SNS Tabanca",
        hash = `WEAPON_SNSPISTOL`,
        damageType = "bullet",
        ammoType = "pistol_ammo",
        maxAmmo = 150,
        price = 3000,
        isIllegal = false,
        licenseRequired = true,
        durability = 100,
        degradationRate = 0.7,
        category = "pistols",
        description = "Küçük cep tabancası."
    },

    -- ═══════════════════════════════════════════
    -- HAFİF MAKİNELİ SİLAHLAR (SMG)
    -- ═══════════════════════════════════════════
    ["WEAPON_MICROSMG"] = {
        label = "Mikro SMG",
        hash = `WEAPON_MICROSMG`,
        damageType = "bullet",
        ammoType = "smg_ammo",
        maxAmmo = 500,
        price = 18000,
        isIllegal = true,
        licenseRequired = true,
        durability = 100,
        degradationRate = 0.8,
        category = "smgs",
        description = "Kompakt makineli tabanca."
    },

    ["WEAPON_SMG"] = {
        label = "SMG",
        hash = `WEAPON_SMG`,
        damageType = "bullet",
        ammoType = "smg_ammo",
        maxAmmo = 500,
        price = 22000,
        isIllegal = true,
        licenseRequired = true,
        durability = 100,
        degradationRate = 0.6,
        category = "smgs",
        description = "Standart hafif makineli."
    },

    ["WEAPON_COMBATPDW"] = {
        label = "Savaş PDW",
        hash = `WEAPON_COMBATPDW`,
        damageType = "bullet",
        ammoType = "smg_ammo",
        maxAmmo = 500,
        price = 28000,
        isIllegal = true,
        licenseRequired = true,
        durability = 100,
        degradationRate = 0.5,
        category = "smgs",
        description = "Kişisel savunma silahı."
    },

    -- ═══════════════════════════════════════════
    -- TÜFEKLER
    -- ═══════════════════════════════════════════
    ["WEAPON_CARBINERIFLE"] = {
        label = "Karbin Tüfek",
        hash = `WEAPON_CARBINERIFLE`,
        damageType = "bullet",
        ammoType = "rifle_ammo",
        maxAmmo = 500,
        price = 45000,
        isIllegal = true,
        licenseRequired = true,
        durability = 100,
        degradationRate = 0.3,
        category = "rifles",
        policeOnly = true,
        description = "Standart polis piyade tüfeği."
    },

    ["WEAPON_ASSAULTRIFLE"] = {
        label = "Saldırı Tüfeği",
        hash = `WEAPON_ASSAULTRIFLE`,
        damageType = "bullet",
        ammoType = "rifle_ammo",
        maxAmmo = 500,
        price = 50000,
        isIllegal = true,
        licenseRequired = true,
        durability = 100,
        degradationRate = 0.4,
        category = "rifles",
        description = "Tam otomatik saldırı tüfeği."
    },

    ["WEAPON_ADVANCEDRIFLE"] = {
        label = "Gelişmiş Tüfek",
        hash = `WEAPON_ADVANCEDRIFLE`,
        damageType = "bullet",
        ammoType = "rifle_ammo",
        maxAmmo = 500,
        price = 65000,
        isIllegal = true,
        licenseRequired = true,
        durability = 100,
        degradationRate = 0.3,
        category = "rifles",
        description = "Bullpup konfigürasyon tüfek."
    },

    -- ═══════════════════════════════════════════
    -- POMPALILER
    -- ═══════════════════════════════════════════
    ["WEAPON_PUMPSHOTGUN"] = {
        label = "Pompalı Tüfek",
        hash = `WEAPON_PUMPSHOTGUN`,
        damageType = "bullet",
        ammoType = "shotgun_ammo",
        maxAmmo = 100,
        price = 20000,
        isIllegal = false,
        licenseRequired = true,
        durability = 100,
        degradationRate = 0.4,
        category = "shotguns",
        description = "Klasik pompalı av tüfeği."
    },

    ["WEAPON_SAWNOFFSHOTGUN"] = {
        label = "Kısa Pompalı",
        hash = `WEAPON_SAWNOFFSHOTGUN`,
        damageType = "bullet",
        ammoType = "shotgun_ammo",
        maxAmmo = 100,
        price = 15000,
        isIllegal = true,
        licenseRequired = true,
        durability = 100,
        degradationRate = 0.6,
        category = "shotguns",
        description = "Namlunun kesildiği pompalı."
    },

    -- ═══════════════════════════════════════════
    -- KESİCİ / YAKIN MESAFE
    -- ═══════════════════════════════════════════
    ["WEAPON_KNIFE"] = {
        label = "Bıçak",
        hash = `WEAPON_KNIFE`,
        damageType = "melee",
        ammoType = nil,
        maxAmmo = 0,
        price = 500,
        isIllegal = false,
        licenseRequired = false,
        durability = 200,
        degradationRate = 0.2,
        category = "melee",
        description = "Mutfak bıçağı."
    },

    ["WEAPON_BAT"] = {
        label = "Beyzbol Sopası",
        hash = `WEAPON_BAT`,
        damageType = "melee",
        ammoType = nil,
        maxAmmo = 0,
        price = 300,
        isIllegal = false,
        licenseRequired = false,
        durability = 300,
        degradationRate = 0.1,
        category = "melee",
        description = "Ahşap beyzbol sopası."
    },

    ["WEAPON_MACHETE"] = {
        label = "Pala",
        hash = `WEAPON_MACHETE`,
        damageType = "melee",
        ammoType = nil,
        maxAmmo = 0,
        price = 800,
        isIllegal = true,
        licenseRequired = false,
        durability = 250,
        degradationRate = 0.15,
        category = "melee",
        description = "Uzun kesici alet."
    },

    -- ═══════════════════════════════════════════
    -- ATICI / ÖZEL
    -- ═══════════════════════════════════════════
    ["WEAPON_STUNGUN"] = {
        label = "Şok Tabancası",
        hash = `WEAPON_STUNGUN`,
        damageType = "electric",
        ammoType = nil,
        maxAmmo = 0,
        price = 0,
        isIllegal = false,
        licenseRequired = false,
        durability = 500,
        degradationRate = 0.05,
        category = "special",
        policeOnly = true,
        description = "Polis tipi şok tabancası (Taser)."
    },

    ["WEAPON_FLASHLIGHT"] = {
        label = "El Feneri",
        hash = `WEAPON_FLASHLIGHT`,
        damageType = "melee",
        ammoType = nil,
        maxAmmo = 0,
        price = 200,
        isIllegal = false,
        licenseRequired = false,
        durability = 500,
        degradationRate = 0.05,
        category = "special",
        description = "Ağır metal el feneri."
    },

    ["WEAPON_PETROLCAN"] = {
        label = "Benzin Bidonu",
        hash = `WEAPON_PETROLCAN`,
        damageType = "fire",
        ammoType = nil,
        maxAmmo = 0,
        price = 100,
        isIllegal = false,
        licenseRequired = false,
        durability = 999,
        degradationRate = 0,
        category = "special",
        description = "Araç yakıt bidonu."
    },
}

-- ============================================================================
-- Weapon Ammo Tanımları
-- ============================================================================
IS4.Weapons.AmmoTypes = {
    ["pistol_ammo"] = {
        label = "Tabanca Mermisi (9mm)",
        maxStack = 250,
        pricePerUnit = 5,
        weaponCategories = { "pistols" },
    },

    ["smg_ammo"] = {
        label = "SMG Mermisi (.45 ACP)",
        maxStack = 500,
        pricePerUnit = 8,
        weaponCategories = { "smgs" },
    },

    ["rifle_ammo"] = {
        label = "Tüfek Mermisi (5.56mm)",
        maxStack = 500,
        pricePerUnit = 12,
        weaponCategories = { "rifles" },
    },

    ["shotgun_ammo"] = {
        label = "Pompalı Fişeği (12 Gauge)",
        maxStack = 100,
        pricePerUnit = 15,
        weaponCategories = { "shotguns" },
    },
}

-- ============================================================================
-- Weapon API Fonksiyonları
-- ============================================================================

--- Silah kaydı oluştur
function CreateWeapon(weaponName, options)
    IS4.Weapons.All[weaponName] = options
    IS4.Logger.Info(("[Weapons] Silah kaydedildi: %s"):format(weaponName))
end
exports("CreateWeapon", CreateWeapon)

--- Silah verisi getir
function GetWeaponData(weaponName)
    return IS4.Weapons.All[weaponName]
end
exports("GetWeaponData", GetWeaponData)

--- Tüm silahları getir
function GetAllWeapons()
    return IS4.Weapons.All
end
exports("GetAllWeapons", GetAllWeapons)

--- Kategoriye göre silahları getir
function GetWeaponsByCategory(category)
    local result = {}
    for name, data in pairs(IS4.Weapons.All) do
        if data.category == category then
            result[name] = data
        end
    end
    return result
end
exports("GetWeaponsByCategory", GetWeaponsByCategory)

--- Oyuncuya silah ver
function GiveWeapon(source, weaponName, ammo)
    local weaponData = IS4.Weapons.All[weaponName]
    if not weaponData then
        IS4.Logger.Warning(("[Weapons] Tanımsız silah: %s"):format(weaponName))
        return false
    end

    -- Polis kilidi kontrolü
    if weaponData.policeOnly then
        local player = exports['is4-core']:GetPlayer(source)
        if player then
            local playerJob = type(player.job) == "table" and player.job.name or player.job
            if playerJob ~= "police" then
                IS4.Logger.Warning(("[Weapons] Polis kilidi: %s → sadece polis kullanabilir"):format(weaponName))
                return false
            end
        end
    end

    -- Lisans kontrolü
    if weaponData.licenseRequired then
        local hasLicense = exports['is4-core']:HasLicense(source, "weapon")
        if not hasLicense then
            IS4.Logger.Warning(("[Weapons] Silah ruhsatı gerekli: %s"):format(source))
            -- İzin ver ama log'la (RP durumuna göre değerlendirilebilir)
        end
    end

    ammo = ammo or 0
    IS4.Events.emit("is4-core:weaponGiven", { source = source, weapon = weaponName, ammo = ammo })
    IS4.Logger.Info(("[Weapons] %s silahı (%s mermi) verildi → %s"):format(weaponName, ammo, source))
    return true
end
exports("GiveWeapon", GiveWeapon)

--- Silah kaldır
function RemoveWeapon(source, weaponName)
    IS4.Events.emit("is4-core:weaponRemoved", { source = source, weapon = weaponName })
    IS4.Logger.Info(("[Weapons] %s silahı kaldırıldı → %s"):format(weaponName, source))
    return true
end
exports("RemoveWeapon", RemoveWeapon)

--- Silah yasadışı mı kontrol et
function IsWeaponIllegal(weaponName)
    local data = IS4.Weapons.All[weaponName]
    return data and data.isIllegal == true
end
exports("IsWeaponIllegal", IsWeaponIllegal)

--- Silah dayanıklılığını düşür
function DegradeWeapon(source, weaponName, shots)
    local data = IS4.Weapons.All[weaponName]
    if not data then return end

    local degradation = (shots or 1) * (data.degradationRate or 0.5)
    IS4.Events.emit("is4-core:weaponDegraded", { source = source, weapon = weaponName, degradation = degradation })
    IS4.Logger.Info(("[Weapons] %s dayanıklılık düştü: -%.2f → %s"):format(weaponName, degradation, source))
end
exports("DegradeWeapon", DegradeWeapon)

--- Mermi tipi verisi getir
function GetAmmoTypeData(ammoType)
    return IS4.Weapons.AmmoTypes[ammoType]
end
exports("GetAmmoTypeData", GetAmmoTypeData)
