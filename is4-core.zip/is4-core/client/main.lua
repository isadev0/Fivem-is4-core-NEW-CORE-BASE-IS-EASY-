-- client/main.lua
Citizen.CreateThread(function()
    print("^2[is4-core INFO]^7 Initializing is4-core (Client)...")
    Wait(200)
    BootClientModules()
    print("^2[is4-core INFO]^7 IS4-Core Client Boot Sequence Complete!")
end)
