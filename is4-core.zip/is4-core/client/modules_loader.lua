-- client/modules_loader.lua
function BootClientModules()
    local count = 0
    for modName, _ in pairs(IS4.Modules) do
        print(('^2[is4-core INFO]^7   - Loaded module: %s'):format(modName))
        count = count + 1
    end
end
