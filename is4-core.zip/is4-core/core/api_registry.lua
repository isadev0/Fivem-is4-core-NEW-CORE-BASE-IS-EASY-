-- core/api_registry.lua
-- Handles the public facing API that modules can interact with.
-- Validates parameter signatures to prevent silent module crashes.

IS4.API = {
    _endpoints = {}
}

--- Registers a new API function securely
-- @param name (string) e.g., "GiveItem"
-- @param expectedArgs (number) How many arguments are strictly required
-- @param callback (function) The logic
function IS4.API.Register(name, expectedArgs, callback)
    if IS4.API._endpoints[name] then
        IS4.Logger.Warning(("[API Registry] Overwriting existing API endpoint: %s"):format(name))
    end
    
    IS4.API._endpoints[name] = {
        argsCount = expectedArgs,
        fn = callback
    }
end

--- Internal wrapper to call registered API functions with validation
local function ExecuteAPI(name, ...)
    local endpoint = IS4.API._endpoints[name]
    if not endpoint then
        IS4.Logger.Error(("[API Registry] Attempted to call missing endpoint: %s"):format(name))
        return nil
    end
    
    local args = {...}
    if #args < endpoint.argsCount then
        IS4.Logger.Error(("[API Registry] Endpoint '%s' expects %s arguments, got %s."):format(name, endpoint.argsCount, #args))
        return nil
    end

    local success, result = pcall(endpoint.fn, ...)
    if not success then
        IS4.Logger.Error(("[API Registry] Runtime error in endpoint '%s': %s"):format(name, result))
        return nil
    end
    
    return result
end

-- Create the Global Export table directly bound to the Registry
-- Instead of directly accessing functions, modules will call exports['is4-core']:Call("GiveItem", src, item, 1)
exports("Call", ExecuteAPI)

-- For internal backwards compatibility or direct framework access:
exports("GetAPI", function() return IS4.API end)
