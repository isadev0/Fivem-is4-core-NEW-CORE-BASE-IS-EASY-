Config = {}

-- Core Framework Properties
Config.Framework = {
    Lang = "en",
    Debug = true,
    LogLevel = 2,           -- 0: Error, 1: Warn, 2: Info, 3: Trace
    MaintenanceMode = false
}

-- System Timers & Caches
Config.System = {
    AutoSaveInterval = 60000 * 5, -- 5 mins cache to DB save
    CacheLifeTime = 300,          -- Object TTL
    RateLimitEnabled = true,
    MaxApiRequestsPerSec = 50     -- Flood control
}

-- Anti-Cheat Integration
Config.AntiCheat = {
    Enabled = true,
    Sensitivity = "high",
    LogSuspiciousEvents = true
}
