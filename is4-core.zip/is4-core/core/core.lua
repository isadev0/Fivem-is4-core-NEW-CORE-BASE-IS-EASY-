-- core/core.lua (Bootstrap)
-- This file brings everything together in order.

if IS4 then
    IS4.Logger.Error("IS4 Global already exists. Prevented duplicate bootstrap.")
    return
end

IS4 = {}

-- 1. Base Libraries
require 'core.config'
require 'core.logger'
require 'core.utils'

IS4.Logger.Info("Bootstrapping is4-core Enterprise (V4) ...")

-- 2. Core Systems
require 'core.event_bus'
require 'core.module_loader'

-- Note: The rest of the systems (`player_manager`, `datastore`, `api_registry`, `network`) will be injected here in later phases.

-- 3. Core Export
exports("GetCore", function() return IS4 end)

-- Mock the manifest loading on the server side for conceptual completion
if IsDuplicityVersion() then
    Citizen.CreateThread(function()
        Wait(500) -- Allow framework load
        
        -- In a production build, we'd use LoadResourceFile to parse the manifest.lua of each subfolder.
        -- For now, we simulate finding the manifestations.
        IS4.ModuleLoader.RegisterManifest({
            name = "datastore",
            version = "1.0",
            dependencies = {}
        })
        
        IS4.ModuleLoader.RegisterManifest({
            name = "players",
            version = "1.0",
            dependencies = {"datastore"}
        })
        
        IS4.ModuleLoader.RegisterManifest({
            name = "inventory",
            version = "1.0",
            dependencies = {"players", "datastore"}
        })
        
        IS4.ModuleLoader.BootAll()
    end)
end
