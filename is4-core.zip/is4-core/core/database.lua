if not IsDuplicityVersion() then return end

IS4.Players = {}

-- Create a Player Object (RAM Cached SQL Abstraction)
function CreatePlayer(source, identifier, data)
    local self = {}
    self.source = source
    self.identifier = identifier
    self.money = data.money or IS4.Config.StartingMoney
    self.job = data.job or "unemployed"
    self.inventory = data.inventory or {}
    
    -- Track if player has unsaved changes to avoid redundant DB writes
    self.isDirty = false 

    self.get = function(key) return self[key] end
    
    self.set = function(key, value)
        local oldValue = self[key]
        self[key] = value
        self.isDirty = true
        
        -- Trigger Pub/Sub Event (e.g. is4-core:playerUpdate:job)
        TriggerEvent(("is4-core:playerUpdate:%s"):format(key), self.source, value, oldValue)
        TriggerClientEvent(("is4-core:playerUpdate:%s"):format(key), self.source, value, oldValue)
    end

    self.addMoney = function(amount)
        self.money = self.money + amount
        self.isDirty = true
        TriggerEvent("is4-core:moneyAdded", self.source, amount, self.money)
        TriggerClientEvent("is4-core:moneyAdded", self.source, amount, self.money)
    end

    self.removeMoney = function(amount)
        if self.money >= amount then
            self.money = self.money - amount
            self.isDirty = true
            TriggerEvent("is4-core:moneyRemoved", self.source, amount, self.money)
            TriggerClientEvent("is4-core:moneyRemoved", self.source, amount, self.money)
            return true
        end
        return false
    end
    
    self.giveItem = function(itemName, amount)
        self.inventory[itemName] = (self.inventory[itemName] or 0) + amount
        self.isDirty = true
        TriggerEvent("is4-core:itemAdded", self.source, itemName, amount)
        TriggerClientEvent("is4-core:itemAdded", self.source, itemName, amount)
    end

    self.removeItem = function(itemName, amount)
        if self.inventory[itemName] and self.inventory[itemName] >= amount then
            self.inventory[itemName] = self.inventory[itemName] - amount
            if self.inventory[itemName] <= 0 then self.inventory[itemName] = nil end
            self.isDirty = true
            TriggerEvent("is4-core:itemRemoved", self.source, itemName, amount)
            TriggerClientEvent("is4-core:itemRemoved", self.source, itemName, amount)
            return true
        end
        return false
    end

    -- Forces a save to DB
    self.save = function()
        if not self.isDirty then return end
        
        -- oxmysql execute update here
        -- e.g. MySQL.Async.execute(...)
        
        self.isDirty = false
        if IS4.Config.Debug then
            IS4.Logger.Info(("[DB] Player %s saved to disk."):format(self.identifier))
        end
    end

    IS4.Players[source] = self
    
    -- Fire Global Load Event
    TriggerEvent("is4-core:playerLoaded", self.source, self)
    TriggerClientEvent("is4-core:playerLoaded", self.source, self)
    
    return self
end

-- Force save all cached data to database (Used in cron)
function SaveAllPlayers()
    local savedCount = 0
    for _, player in pairs(IS4.Players) do
        if player.isDirty then
            player.save()
            savedCount = savedCount + 1
        end
    end
    if IS4.Config.Debug and savedCount > 0 then
        IS4.Logger.Info(("[DB] Bulk saving complete. %s players saved."):format(savedCount))
    end
end
exports("SaveAllPlayers", SaveAllPlayers)

function GetPlayer(source)
    return IS4.Players[source]
end
exports("GetPlayer", GetPlayer)

-- When a player drops, save their data and remove from cache
AddEventHandler("playerDropped", function(reason)
    local src = source
    local player = IS4.Players[src]
    if player then
        player.save()
        IS4.Players[src] = nil
        IS4.Logger.Info(("[DB] Player %s disconnected, data saved and cleared from cache."):format(src))
    end
end)
