-- core/datastore.lua
-- Responsible for Database interactions and Batching

if not IsDuplicityVersion() then return end

IS4.Datastore = {}

--- Gerçek oxmysql sorgu sarmalayıcısı (execute)
function IS4.Datastore.Query(query, params, callback)
    if IS4.Config.Framework.Debug then
        IS4.Logger.Info(("[DB] Executing: %s"):format(query))
    end
    MySQL.Async.execute(query, params, function(rowsChanged)
        if callback then callback(rowsChanged and rowsChanged > 0) end
    end)
end

--- Tek satır çekme
function IS4.Datastore.FetchSingle(query, params, callback)
    MySQL.Async.fetchSingle(query, params, function(result)
        if callback then callback(result) end
    end)
end

--- Çoklu satır çekme
function IS4.Datastore.FetchAll(query, params, callback)
    MySQL.Async.fetchAll(query, params, function(results)
        if callback then callback(results) end
    end)
end

--- Oyuncu yoksa INSERT, varsa last_seen güncelle
function IS4.Datastore.EnsurePlayer(identifier, license, callback)
    MySQL.Async.fetchSingle(
        "SELECT identifier FROM players WHERE identifier = ? LIMIT 1",
        {identifier},
        function(row)
            if not row then
                local defaultMoney = json.encode({ cash = IS4.Config.Economy.StartingCash, bank = IS4.Config.Economy.StartingBank })
                local defaultInv   = json.encode({})
                local defaultMeta  = json.encode({})
                MySQL.Async.execute(
                    [[INSERT INTO players
                        (identifier, license, money, job, job_grade, inventory, metadata, status, last_seen)
                      VALUES (?, ?, ?, 'unemployed', 0, ?, ?, 1, NOW())]],
                    {identifier, license, defaultMoney, defaultInv, defaultMeta},
                    function()
                        IS4.Logger.Info(("[Datastore] Yeni oyuncu kaydı oluşturuldu: %s"):format(identifier))
                        if callback then callback(true) end
                    end
                )
            else
                MySQL.Async.execute(
                    "UPDATE players SET last_seen = NOW(), status = 1 WHERE identifier = ?",
                    {identifier}
                )
                if callback then callback(false) end
            end
        end
    )
end

--- Oyuncuyu DB'den yükle ve parse et
function IS4.Datastore.LoadPlayer(identifier, callback)
    MySQL.Async.fetchSingle(
        "SELECT * FROM players WHERE identifier = ? LIMIT 1",
        {identifier},
        function(row)
            if not row then
                if callback then callback(nil) end
                return
            end
            local data = {
                money     = (row.money     and json.decode(row.money))     or { cash = IS4.Config.Economy.StartingCash, bank = IS4.Config.Economy.StartingBank },
                job       = row.job       or "unemployed",
                job_grade = row.job_grade or 0,
                inventory = (row.inventory and json.decode(row.inventory)) or {},
                metadata  = (row.metadata  and json.decode(row.metadata))  or {},
            }
            if callback then callback(data) end
        end
    )
end

--- Takes a Player object and saves only if Dirty
function IS4.Datastore.SavePlayer(player)
    if not player or not player.isDirty then return end

    local identifier = player.identifier
    local money      = json.encode(player.money)
    local job        = player.job
    local job_grade  = player.job_grade or 0
    local inventory  = json.encode(player.inventory)
    local metadata   = json.encode(player.metadata or {})

    MySQL.Async.execute(
        "UPDATE players SET money = ?, job = ?, job_grade = ?, inventory = ?, metadata = ?, last_seen = NOW() WHERE identifier = ?",
        {money, job, job_grade, inventory, metadata, identifier},
        function(rowsChanged)
            if rowsChanged and rowsChanged > 0 then
                player.isDirty = false
                IS4.Logger.Info(("[Datastore] Oyuncu %s başarıyla kaydedildi."):format(identifier))
                IS4.Events.emit("datastore:playerSaved", identifier)
            else
                IS4.Logger.Error(("[Datastore] Oyuncu %s kaydedilemedi!"):format(identifier))
            end
        end
    )
end

--- Batch save all dirty players
function IS4.Datastore.SaveAllDirty()
    local count = 0
    for _, player in pairs(IS4.PlayerManager.GetPlayers()) do
        if player.isDirty then
            IS4.Datastore.SavePlayer(player)
            count = count + 1
        end
    end
    if count > 0 then
        IS4.Logger.Info(("[Datastore] Batch save completed. Synced %s players."):format(count))
    end
end

-- Initialize the background auto-save loop
Citizen.CreateThread(function()
    while true do
        Wait(IS4.Config.System.AutoSaveInterval or 300000)
        IS4.Datastore.SaveAllDirty()
    end
end)

exports("GetDatastore", function() return IS4.Datastore end)
