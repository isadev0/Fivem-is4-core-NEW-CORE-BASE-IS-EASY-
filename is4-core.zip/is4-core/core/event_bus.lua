-- core/event_bus.lua
-- The central nervous system of the framework.

IS4.EventBus = {
    _listeners = {}
}

--- Emit an event with a payload
function IS4.EventBus.emit(eventName, payload)
    if not IS4.EventBus._listeners[eventName] then return end
    
    for _, callback in ipairs(IS4.EventBus._listeners[eventName]) do
        -- Wrapped in pcall to prevent one bad listener from crashing the whole bus
        local success, err = pcall(callback, payload)
        if not success then
            IS4.Logger.Error(("Event Bus Error on '%s': %s"):format(eventName, err))
        end
    end
end

--- Listen to an event continuously
function IS4.EventBus.on(eventName, callback)
    if not IS4.EventBus._listeners[eventName] then
        IS4.EventBus._listeners[eventName] = {}
    end
    table.insert(IS4.EventBus._listeners[eventName], callback)
end

--- Remove a specific callback from an event
function IS4.EventBus.off(eventName, callbackToRemove)
    if not IS4.EventBus._listeners[eventName] then return end
    
    for i, callback in ipairs(IS4.EventBus._listeners[eventName]) do
        if callback == callbackToRemove then
            table.remove(IS4.EventBus._listeners[eventName], i)
            break
        end
    end
end

--- Listen to an event exactly once
function IS4.EventBus.once(eventName, callback)
    local wrapper
    wrapper = function(payload)
        callback(payload)
        IS4.EventBus.off(eventName, wrapper)
    end
    IS4.EventBus.on(eventName, wrapper)
end

-- Abstracting to global so modules can just call IS4.Events.on()
IS4.Events = IS4.EventBus

exports("GetEventBus", function() return IS4.EventBus end)
