-- Global Events Wrapper (Server & Client)
IS4.Events = {}

-- Pub/Sub Implementation
-- Emits an event internally and over the network if needed
function IS4.Events.Trigger(eventName, ...)
    if IsDuplicityVersion() then
        -- Server side trigger
        TriggerEvent(eventName, ...)
        TriggerClientEvent(eventName, -1, ...) -- Broadcast
    else
        -- Client side trigger
        TriggerEvent(eventName, ...)
        TriggerServerEvent(eventName, ...)
    end
end

-- Network specific triggers
if IsDuplicityVersion() then
    -- Server Side
    function RegisterCoreEvent(eventName, callback)
        RegisterNetEvent(eventName, function(...)
            local src = source
            callback(src, ...)
        end)
    end

    function TriggerClient(eventName, src, ...)
        TriggerClientEvent(eventName, src, ...)
    end
else
    -- Client Side
    function RegisterCoreEvent(eventName, callback)
        RegisterNetEvent(eventName, function(...)
            callback(...)
        end)
    end

    function TriggerServer(eventName, ...)
        TriggerServerEvent(eventName, ...)
    end
end
