-- Basic logger to format prints based on Type
IS4.Logger = {}

function IS4.Logger.Info(msg)
    print(("^2[is4-core INFO]^7 %s"):format(msg))
end

function IS4.Logger.Warning(msg)
    print(("^3[is4-core WARN]^7 %s"):format(msg))
end

function IS4.Logger.Error(msg)
    print(("^1[is4-core ERROR]^7 %s"):format(msg))
end

exports("Logger", function() return IS4.Logger end)
