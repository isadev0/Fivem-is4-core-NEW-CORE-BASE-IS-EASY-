-- core/module_loader.lua
-- Responsible for loading modules based on dependency graphs.

IS4.ModuleLoader = {
    _manifests = {},
    _loaded = {}
}

--- Register a parsed manifest from a module
function IS4.ModuleLoader.RegisterManifest(manifest)
    if not manifest.name then return end
    IS4.ModuleLoader._manifests[manifest.name] = manifest
end

--- Boot a specific module if its dependencies are met
function IS4.ModuleLoader.LoadModule(moduleName)
    if IS4.ModuleLoader._loaded[moduleName] then return true end
    
    local manifest = IS4.ModuleLoader._manifests[moduleName]
    if not manifest then
        IS4.Logger.Warning(("Attempted to load unknown module: %s"):format(moduleName))
        return false
    end

    -- Check Dependencies
    if manifest.dependencies then
        for _, dep in ipairs(manifest.dependencies) do
            if not IS4.ModuleLoader._loaded[dep] then
                -- Try to load the dependency first
                local success = IS4.ModuleLoader.LoadModule(dep)
                if not success then
                    IS4.Logger.Error(("Failed to load module '%s' due to missing dependency: '%s'"):format(moduleName, dep))
                    return false
                end
            end
        end
    end

    -- Initialize the module (Mock logic for now, in a real environment we'd execute the module's init closure here or rely on FXManifest order, but we track state at least)
    IS4.ModuleLoader._loaded[moduleName] = true
    IS4.Logger.Info(("✓ Module Loaded: %s (v%s)"):format(manifest.name, manifest.version))
    
    -- Emit event so other systems know a module is ready
    IS4.Events.emit("module:loaded", manifest.name)
    
    return true
end

--- Attempt to boot all registered manifests sequentially
function IS4.ModuleLoader.BootAll()
    IS4.Logger.Info("Initializing Module Dependency Graph...")
    local count = 0
    for name, _ in pairs(IS4.ModuleLoader._manifests) do
        if IS4.ModuleLoader.LoadModule(name) then
            count = count + 1
        end
    end
    IS4.Logger.Info(("Boot Sequence Complete. Loaded %s modules."):format(count))
    IS4.Events.emit("core:modulesLoaded", {count = count})
end

exports("GetModuleLoader", function() return IS4.ModuleLoader end)
