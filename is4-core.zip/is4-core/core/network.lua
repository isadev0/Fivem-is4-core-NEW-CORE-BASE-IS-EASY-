-- core/network.lua
-- The secure barrier between the Client and Server.
-- Prevents random Lua executors from flooding the server with raw net events.

IS4.Network = {
    _rateLimits = {} -- Track requests per second per player
}

if IsDuplicityVersion() then
    -- Server Side
    
    --- Register a secure network event for the server to listen to from clients
    function IS4.Network.RegisterServerCallback(eventName, callback)
        RegisterNetEvent(eventName, function(...)
            local src = source
            
            -- Basic Rate Limiting
            if IS4.Config.System.RateLimitEnabled then
                local currentTick = GetGameTimer()
                if not IS4.Network._rateLimits[src] then
                    IS4.Network._rateLimits[src] = {count = 1, lastReset = currentTick}
                else
                    if currentTick - IS4.Network._rateLimits[src].lastReset > 1000 then
                        -- Reset every second
                        IS4.Network._rateLimits[src].count = 1
                        IS4.Network._rateLimits[src].lastReset = currentTick
                    else
                        -- Increment
                        IS4.Network._rateLimits[src].count = IS4.Network._rateLimits[src].count + 1
                        if IS4.Network._rateLimits[src].count > IS4.Config.System.MaxApiRequestsPerSec then
                            IS4.Logger.Warning(("[Network] Rate limit exceeded by Player %s! Dropping packet '%s'."):format(src, eventName))
                            -- Trigger AntiCheat anomaly here later
                            return
                        end
                    end
                end
            end
            
            -- Payload passed
            callback(src, ...)
        end)
    end
    
    exports("RegisterServerCallback", IS4.Network.RegisterServerCallback)
    
else
    -- Client Side
    
    --- Send a secure payload to the Server
    function IS4.Network.TriggerServer(eventName, ...)
        -- Could add client-side payload cryptography here later
        TriggerServerEvent(eventName, ...)
    end
    
    exports("TriggerServer", IS4.Network.TriggerServer)
end
