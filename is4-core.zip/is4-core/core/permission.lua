-- core/permission.lua
if not IsDuplicityVersion() then return end

IS4.Permissions = {
    _roles = {}
}

--- Assign a role to a player securely
function IS4.Permissions.SetRole(source, role)
    local player = IS4.PlayerManager.GetPlayer(source)
    if player then
        player.set("permission_role", role)
        IS4.Permissions._roles[source] = role
        IS4.Logger.Info(("[Permissions] Assigned role '%s' to %s"):format(role, source))
        return true
    end
    return false
end

--- Check if the source has a specific role
function IS4.Permissions.HasRole(source, requiredRole)
    if IS4.Permissions._roles[source] == "god" then return true end -- God overrides all
    return IS4.Permissions._roles[source] == requiredRole
end

--- Validate module operation based on role
function IS4.Permissions.HasPermission(source, permissionStr)
    -- Eg. 'inventory.give'
    local role = IS4.Permissions._roles[source] or "user"
    
    -- In a real DB, we'd lookup `SELECT * from permission_rules where role = ? and perm = ?`
    -- For now, if role is admin they get access to everything.
    if role == "admin" or role == "god" then
        return true
    elseif role == "mod" and not permissionStr:match("admin.") then
        return true
    end
    
    return false
end

exports("GetPermissions", function() return IS4.Permissions end)
