-- core/player_manager.lua
-- Ram caching and Player object instantiation

if not IsDuplicityVersion() then return end

IS4.PlayerManager = {
    _players = {}
}

--- Create the Player Object instance map
function IS4.PlayerManager.CreatePlayer(source, identifier, data)
    local self = {}
    self.source = source
    self.identifier = identifier
    
    self.money = data.money or {cash = IS4.Config.Economy.StartingCash, bank = IS4.Config.Economy.StartingBank}
    self.job = data.job or "unemployed"
    self.inventory = data.inventory or {}
    
    self.isDirty = false 

    -- Getters
    self.get = function(key) return self[key] end
    
    -- Generic setter
    self.set = function(key, value)
        local oldValue = self[key]
        self[key] = value
        self.isDirty = true
        IS4.Events.emit(("is4-core:playerUpdate:%s"):format(key), {source = self.source, new = value, old = oldValue})
    end
    
    -- Specific functions
    self.addMoney = function(type, amount)
        if not self.money[type] then return false end
        self.money[type] = self.money[type] + amount
        self.isDirty = true
        IS4.Events.emit("is4-core:moneyAdded", {source = self.source, type = type, amount = amount, total = self.money[type]})
        return true
    end

    self.removeMoney = function(type, amount)
        if not self.money[type] or self.money[type] < amount then return false end
        self.money[type] = self.money[type] - amount
        self.isDirty = true
        IS4.Events.emit("is4-core:moneyRemoved", {source = self.source, type = type, amount = amount, total = self.money[type]})
        return true
    end

    self.giveItem = function(itemName, amount)
        self.inventory[itemName] = (self.inventory[itemName] or 0) + amount
        self.isDirty = true
        IS4.Events.emit("is4-core:itemAdded", {source = self.source, item = itemName, amount = amount})
    end

    self.removeItem = function(itemName, amount)
        if self.inventory[itemName] and self.inventory[itemName] >= amount then
            self.inventory[itemName] = self.inventory[itemName] - amount
            if self.inventory[itemName] <= 0 then self.inventory[itemName] = nil end
            self.isDirty = true
            IS4.Events.emit("is4-core:itemRemoved", {source = self.source, item = itemName, amount = amount})
            return true
        end
        return false
    end

    IS4.PlayerManager._players[source] = self
    IS4.Events.emit("is4-core:playerLoaded", {source = self.source, identifier = self.identifier})
    IS4.Logger.Info(("[PlayerManager] Loaded caching profile for %s"):format(identifier))
    
    return self
end

function IS4.PlayerManager.GetPlayer(source)
    return IS4.PlayerManager._players[source]
end

function IS4.PlayerManager.GetPlayers()
    return IS4.PlayerManager._players
end

-- Hook into playerDrop to save and clean Cache
AddEventHandler("playerDropped", function(reason)
    local src = source
    local player = IS4.PlayerManager.GetPlayer(src)
    if player then
        -- Force Save
        IS4.Datastore.SavePlayer(player)
        IS4.PlayerManager._players[src] = nil
        IS4.Logger.Info(("[PlayerManager] Cleared memory mapping for dropped player %s."):format(src))
    end
end)

exports("GetPlayerManager", function() return IS4.PlayerManager end)
exports("GetPlayer", IS4.PlayerManager.GetPlayer)
