-- core/profiler.lua
-- Measures performance of events and DB queries.

IS4.Profiler = {
    _traces = {}
}

--- Start a CPU time trace
-- @return traceId string
function IS4.Profiler.StartTrace(label)
    local id = tostring(math.random(100000, 999999))
    IS4.Profiler._traces[id] = {
        label = label,
        startTick = os.clock()
    }
    return id
end

--- End a CPU time trace and log if it takes too long
function IS4.Profiler.EndTrace(id)
    local trace = IS4.Profiler._traces[id]
    if not trace then return end
    
    local diff = (os.clock() - trace.startTick) * 1000 -- diff in ms
    if diff > 15.0 then
        -- Anything taking more than 15ms per frame/event is a bottleneck in FiveM Lua
        IS4.Logger.Warning(("[Profiler] Lag Spike Detected: '%s' took %.2f ms"):format(trace.label, diff))
    end
    
    IS4.Profiler._traces[id] = nil
end

exports("GetProfiler", function() return IS4.Profiler end)

-- Mock usage within the Datastore loop
-- Id = IS4.Profiler.StartTrace("SaveAllDirty")
-- IS4.Datastore.SaveAllDirty()
-- IS4.Profiler.EndTrace(Id)
