IS4.Utils = {}

-- Dump Helper for debugging tables
function IS4.Utils.DumpTable(node)
    local cache, res = {}, {}
    local function dump(n, indent)
        if cache[tostring(n)] then table.insert(res, indent .. "*" .. tostring(n)) return end
        cache[tostring(n)] = true
        for k, v in pairs(n) do
            if type(v) == "table" then
                table.insert(res, indent .. "[" .. tostring(k) .. "] = {")
                dump(v, indent .. "  ")
                table.insert(res, indent .. "}")
            else
                table.insert(res, indent .. "[" .. tostring(k) .. "] = " .. tostring(v))
            end
        end
    end
    dump(node, "")
    print(table.concat(res, "\n"))
end

exports("Utils", function() return IS4.Utils end)
