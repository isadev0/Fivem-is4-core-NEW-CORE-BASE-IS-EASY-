# is4-core API Reference

## Global Object (`IS4`)
The core object can be accessed anywhere using:
```lua
local core = exports['is4-core']:GetCore()
```

## Money API
- `exports['is4-core']:AddMoney(source, amount)` - Adds money to the player.
- `exports['is4-core']:RemoveMoney(source, amount)` - Removes money.
- `exports['is4-core']:TransferMoney(source, target, amount)` - Transfers money between players.

## Jobs API
- `exports['is4-core']:CreateJob("jobName", options)` - Registers a job.
- `exports['is4-core']:StartJob(source, "jobName")` - Sets the player's job.

## Items API
- `exports['is4-core']:GiveItem(source, itemName, amount)` - Gives an item.
- `exports['is4-core']:RemoveItem(source, itemName, amount)` - Removes an item.

## Notifications
- `exports['is4-core']:SendNotification(source, text)` (Server Side)
- `exports['is4-core']:SendNotification(text)` (Client Side)
