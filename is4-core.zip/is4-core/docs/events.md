# is4-core Event Pub/Sub Registry

The framework automatically dispatches Core Events whenever internal data is changed through the API layer. Modules should subscribe to these events instead of manually checking values.

## Player Data Flow
- `is4-core:playerLoaded` - `(source, playerObject)` - Fires when mapping completes.
- `is4-core:playerUpdate:job` - `(source, newJob, oldJob)` - Fires when a job is assigned.
- `is4-core:playerUpdate:money` - `(source, newBal, oldBal)` - Fires when money is set strictly.

## Economy Flow
- `is4-core:moneyAdded` - `(source, amount, totalBal)`
- `is4-core:moneyRemoved` - `(source, amount, totalBal)`

## Inventory Flow
- `is4-core:itemAdded` - `(source, itemName, amount)`
- `is4-core:itemRemoved` - `(source, itemName, amount)`

## Weapon Flow
- `is4-core:weaponGiven` - `(source, weaponName, ammo)`
- `is4-core:weaponRemoved` - `(source, weaponName)`

## Vehicle Flow
- `is4-core:vehicleSpawned` - `(source, model, coords)`
- `is4-core:vehicleDeleted` - `(source)`
