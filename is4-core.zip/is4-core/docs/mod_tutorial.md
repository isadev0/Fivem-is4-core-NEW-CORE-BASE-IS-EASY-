# How to write a Module for is4-core

Modules are strictly isolated from the core framework but can easily interact with it via the Module Registry.

## File Structure
Modules belong in `modules/[category]/[moduleName]/init.lua`.
Example: `modules/jobs/police/init.lua`

## Registering the Module
Use the `RegisterModule` function anywhere in the module's server-side code:

```lua
RegisterModule("policeJob", {
    name = "policeJob",
    version = "1.0",
    
    events = {
        onPlayerStart = function(source)
            exports['is4-core']:AddMoney(source, 500)
            exports['is4-core']:SendNotification(source, "Polis olarak göreve başladın!")
        end
    },
    
    config = {
        armoryCoords = {x = 100.0, y = 100.0, z = 50.0}
    }
})
```
