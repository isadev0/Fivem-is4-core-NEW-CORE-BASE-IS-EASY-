# 🏗️ is4-core — Enterprise FiveM Framework

> **Versiyon:** 4.0.0 | **Yazar:** nazir | **Lisans:** Private
> **Mimari:** Event-Driven, Loose-Coupled, RAM-Cached, Batch-Synced

---

## 📋 İçindekiler

1. [Framework Nedir?](#-framework-nedir)
2. [Mimari Yapı (5 Katman)](#-mimari-yapı-5-katman)
3. [Core Dosyaları](#-core-dosyaları)
4. [API Katmanı](#-api-katmanı)
5. [Modül Listesi](#-modül-listesi)
6. [Nasıl Script Yazılır?](#-nasıl-script-yazılır)
7. [Event Bus Rehberi](#-event-bus-rehberi)
8. [Config Felsefesi](#-config-felsefesi)
9. [Performans Notları](#-performans-notları)

---

## 🧠 Framework Nedir?

`is4-core`, FiveM sunucunuz için **sıfırdan** inşa edilmiş bağımsız bir çekirdek framework'tür. ESX veya QBCore'a bağımlı değildir. Kendi Event Bus sistemi, kendi RAM Cache mekanizması, kendi API Registry'si ve kendi Modül Yükleyicisi vardır.

**Temel Felsefe:**
- Modüller birbirini **direkt çağırmaz**. Herkes Core'un Event Bus'ı üzerinden konuşur.
- Veritabanına **sürekli** sorgu atılmaz. Tüm oyuncu verisi RAM'de tutulur, sadece periyodik olarak (5dk) veya oyuncu çıkışında DB'ye yazılır.
- Her API çağrısı `pcall` ile sarılır. Tek bir modülün hatası tüm sunucuyu çökertmez.
- Client → Server iletişimi Rate Limit ile korunur. Hilecilerin event spam'i engellenir.

---

## 🏛️ Mimari Yapı (5 Katman)

```
┌──────────────────────────────────────────┐
│              LAYER 1: CORE               │
│  event_bus · module_loader · datastore   │
│  player_manager · api_registry · network │
│  permission · profiler · logger          │
├──────────────────────────────────────────┤
│              LAYER 2: API                │
│  jobs · items · money · weapons          │
│  vehicles · players · notifications      │
├──────────────────────────────────────────┤
│            LAYER 3: MODULES              │
│  is4-players · is4-hud · is4-needs       │
│  is4-garages · is4-housing · is4-motels  │
│  is4-policejob · is4-ambulancejob        │
│  is4-mechanic · is4-gangs · is4-crypto   │
│  is4-phone · is4-chat · is4-system       │
│  is4-anticheat · is4-advancedresources   │
│  is4-others                              │
├──────────────────────────────────────────┤
│         LAYER 4: CLIENT / SERVER         │
│  main.lua · modules_loader.lua           │
│  ui.lua · animations.lua · cron.lua      │
├──────────────────────────────────────────┤
│             LAYER 5: ASSETS              │
│  /docs · /assets                         │
└──────────────────────────────────────────┘
```

---

## ⚙️ Core Dosyaları

Her dosya tek bir sorumluluk taşır (Single Responsibility Principle):

| Dosya | Görev |
|---|---|
| `core/config.lua` | Global ayarlar: Debug, Log seviyesi, Rate Limit, Anti-Cheat hassasiyeti, Auto-Save süresi |
| `core/event_bus.lua` | Pub/Sub sinir sistemi. `emit()`, `on()`, `off()`, `once()` fonksiyonlarıyla modüller arası bağımsız iletişim sağlar |
| `core/module_loader.lua` | `manifest.lua` dosyalarını okur, bağımlılıkları çözer, sıralı yükleme yapar |
| `core/player_manager.lua` | Oyuncu nesnelerini RAM'de tutar. `addMoney()`, `removeMoney()`, `giveItem()`, `removeItem()`, `set()` fonksiyonları burada yaşar. Her değişiklik otomatik olarak `isDirty = true` işaretler |
| `core/datastore.lua` | Arka planda 5 dakikada bir `isDirty` olan oyuncuları toplu olarak MySQL'e yazar. Oyuncu disconnect olduğunda anında kaydeder |
| `core/api_registry.lua` | Modüllerin register ettiği API fonksiyonlarının parametre sayısını doğrular, `pcall` ile çalıştırır, hata olursa izole eder |
| `core/network.lua` | Client → Server iletişiminde saniyede 50'den fazla event atılırsa paketi düşürür (Rate Limiting). Anti-exploit katmanı |
| `core/permission.lua` | Rol tabanlı yetki kontrolü (RBAC): `god`, `admin`, `mod`, `user`. Fonksiyon bazlı izin (`inventory.give`, `admin.kick`) |
| `core/profiler.lua` | CPU ölçümü. Bir işlem 15ms'den uzun sürerse `[Profiler] Lag Spike Detected` uyarısı fırlatır |
| `core/logger.lua` | `Info`, `Warning`, `Error` seviyeleriyle loglama: Hangi modül ne yaptı, ne zaman hata verdi |
| `core/utils.lua` | Yardımcı fonksiyonlar (tablo yazdırma vb.) |
| `core/core.lua` | Bootstrap: Tüm Core sistemlerini sırasıyla ayağa kaldırır, `GetCore()` export'unu oluşturur |

---

## 📡 API Katmanı

`/api` klasöründeki dosyalar, modüllerin kullanması için basitleştirilmiş DSL (Domain Specific Language) fonksiyonları sunar:

| Dosya | Fonksiyonlar |
|---|---|
| `api/items.lua` | `CreateItem(name, opts)`, `GiveItem(src, name, amount)`, `RemoveItem(src, name, amount)` |
| `api/money.lua` | `AddMoney(src, amount)`, `RemoveMoney(src, amount)`, `TransferMoney(from, to, amount)` |
| `api/weapons.lua` | `CreateWeapon(name, opts)`, `GiveWeapon(src, name, ammo)`, `RemoveWeapon(src, name)` |
| `api/vehicles.lua` | `CreateVehicle(model, opts)`, `SpawnVehicle(src, model, coords)`, `DeleteVehicle(src)` |
| `api/jobs.lua` | `CreateJob(name, opts)`, `StartJob(src, jobName)` |
| `api/players.lua` | `GetPlayerData(src)`, `SetPlayerJob(src, jobName)` |
| `api/notifications.lua` | `SendNotification(src, text, type)` |

**Kullanım:**
```lua
local Core = exports['is4-core']:GetCore()
exports['is4-core']:AddMoney(source, 5000)
exports['is4-core']:GiveItem(source, "water", 3)
```

---

## 📦 Modül Listesi

### 🧑 is4-players — Karakter Sistemi
**Amaç:** Oyuncunun sunucuya girdiğinde kimlik seçmesi, karakter oluşturması ve dünyaya spawn olması.

**Sunucu Tarafı:**
- `playerSpawned` event'inde FiveM License tanımlayıcısını çeker
- Veritabanından karakterleri sorgulatır (mock: SQL `SELECT * FROM players WHERE identifier LIKE ?`)
- Seçilen karakteri `Core.PlayerManager.CreatePlayer()` ile RAM'e yükler
- Client'a spawn koordinatlarını gönderir

**Client Tarafı:**
- Oyuncu dondurulur ve görünmez yapılır (karakter seçim ekranı için)
- Karakter seçtikten sonra Config'deki koordinatlara teleport edilir
- `Config.SpawnInvincibilityTimer` süresince ölümsüzlük verilir
- `is4-core:clientSpawned` Event'i fırlatılır → HUD ve diğer tüm client modüller bu sinyal ile uyanır

**Config Ayarları:** `MaxCharacters = 4`, `StartingCoords`, `SpawnInvincibilityTimer = 5000ms`

---

### 📊 is4-hud — NUI Arayüzü (Heads-Up Display)
**Amaç:** Oyuncunun ekranında sağlık, zırh, açlık, susuzluk ve para bilgisini göstermek.

**Mimari:**
- **HTML/CSS/JS** tabanlı NUI (`modules/is4-hud/ui/`)
- Sol alt köşede 4 adet yuvarlak durum çemberi (Health = Yeşil, Armor = Mavi, Hunger = Turuncu, Thirst = Açık Mavi)
- Sağ üst köşede Banka ve Nakit göstergesi
- Para değişimlerinde `+$500` (yeşil) veya `-$200` (kırmızı) animasyonu oynar

**Event Bus Bağlantıları:**
- `is4-core:clientSpawned` → HUD'u açar
- `client:updateNeeds` → Açlık/Susuzluk barlarını günceller
- `is4-core:moneyAdded` / `moneyRemoved` → Para animasyonu tetikler (server → client)

**Performans Notu:** HUD sürekli `While true Wait(0)` yapmaz! Sadece Event geldiğinde güncellenir. Tek istisna: Health/Armor her 500ms'de bir okunur (GTA native zorunluluğu).

---

### 🍔 is4-needs — Açlık & Susuzluk Sistemi
**Amaç:** Survival mekaniklerini yönetmek.

**Sunucu Tarafı:**
- `Config.StatusTickRate` (varsayılan 60 saniye) aralığıyla tüm oyuncuların `metadata.hunger` ve `metadata.thirst` değerlerini düşürür
- Değer 0'a inerse `is4-needs:starvationDamage` event'i ile client'a hasar uygulatır
- `Config.FoodItems` tablosundaki her item otomatik olarak `CreateItem` API'si ile Framework'e register edilir
- Item kullanıldığında hunger/thirst değerleri yükseltilir, item envanterden kaldırılır

**Client Tarafı:**
- `is4-needs:updateStatus` event'ini dinler → Event Bus'a `client:updateNeeds` olarak yayar → HUD modülü bunu yakalar
- `is4-needs:starvationDamage` geldiğinde ped'e 5 HP hasar verir

**Config Ayarları:** `HungerDepletion = 1.0`, `ThirstDepletion = 1.5`, `FoodItems = {water = {thirst = 25}, hamburger = {hunger = 40}, ...}`

---

### 🚗 is4-garages — Garaj Sistemi
**Amaç:** Oyuncuların araçlarını saklaması, çıkarması ve garajlar arası yönetmesi.

**Sunucu Tarafı:**
- `playerLoaded` event'inde DB'den araç listesini çeker ve RAM'de tutar
- `is4-garages:getVehicles` → Sadece `stored = true` olan araçları döner
- `is4-garages:spawnVehicle` → Aracı `stored = false` yapar, client'a spawn emri gönderir
- `is4-garages:storeVehicle` → Aracı `stored = true` yapar, client'ta siler

**Client Tarafı:**
- Spawn sonrası tüm garazlar için haritada **blip** oluşturur (Sprite: 357, Renk: Mavi)
- Her 500ms'de proximity kontrolü yapar (mesafe < 5.0), marker çizer
- Mesafe < 2.5 olduğunda [E] tuşuyla garaj menüsü açılır
- Araç spawn edildiğinde plaka, yakıt, hasar değerleri uygulanır, oyuncu araca bindirilir

**Config Ayarları:** `GarageLocations` tablosu (Legion Square, Pillbox Hill, Impound Lot koordinatları ve blip ayarları)

---

### 🏠 is4-housing — Ev & Mülk Sistemi
**Amaç:** Haritadaki mülkleri satın alma, giriş yapma, anahtar paylaşma ve depo kullanma.

**Sunucu Tarafı:**
- `is4-housing:buyHouse` → Müsait mi kontrol eder, bankadan para çeker, mülk sahibini kaydeder
- `is4-housing:enterHouse` → Sahip veya anahtar sahibi mi kontrol eder, interior'a teleport eder
- `is4-housing:giveKey` → Sadece mülk sahibi başka oyunculara anahtar verebilir
- `is4-housing:getStorage` → Evin deposuna erişim sağlar

**Config Ayarları:** `PriceMultiplier = 1.0`, `PoliceAccess = true` (polis baskını), `AllowWeaponStorage = true`, Ev tanımları (Grove Street $150K, Vinewood $350K)

---

### 🏨 is4-motels — Motel Sistemi
**Amaç:** Yeni oyuncular için ucuz geçici barınma.

**Sunucu Tarafı:**
- `is4-motels:rentRoom` → Boş oda arar, nakit çeker, `os.time()` + 3600 (1 saat) son kullanma kaydeder
- Arka plan döngüsü her 60 saniyede bir süresi dolan odaları siler ve kiracıyı bilgilendirir

**Client Tarafı:** Motel lokasyonlarına blip koyar, proximity kontrolü ile [E] tuşuyla kiralama başlatır

**Config Ayarları:** `RentPricePerHour = $200`, `MaxRentHours = 24`, `StorageSlots = 20`, Lokasyonlar (Pink Cage Motel, Dream View Motel)

---

### 👮 is4-policejob — Polis Mesleği
**Amaç:** Tam donanımlı kolluk kuvveti sistemi.

**Sunucu Tarafı:**
- `toggleDuty` → Mesai aç/kapa
- `cuff` → Hedefi kelepçeler, animasyon başlatır
- `uncuff` → Kelepçeyi çıkarır
- `escort` → Hedefi sürükler (polis pedin arkasında takip ettirir)
- `putInVehicle` → Kelepçeli hedefi en yakın aracın arka koltuğuna bindirir
- `jail` → Hedefi Bolingbroke Hapishanesine teleport eder, süre başlatır
- `fine` → Hedefin banka hesabından para keser

**Client Tarafı:**
- Kelepçe animasyonu (`mp_arresting` dict), ateş etme engeli
- Escort: Polisin 0.5m arkasında zorla yürütme
- Hapishane: `FreezeEntityPosition` + countdown timer, süre bitince karakola teleport
- MRPD blip (sprite: 60)

**Config Ayarları:** `Ranks = {Cadet → Chief}`, `Armory` (Taser, Pistol, Shotgun, Rifle, Kelepçe, Baret), `Jail = {MinTime = 5dk, MaxTime = 60dk}`

---

### 🚑 is4-ambulancejob — Ambulans / EMS Mesleği
**Amaç:** Sağlık hizmetleri, yaralı kurtarma ve hastane sistemi.

**Sunucu Tarafı:**
- `reportDeath` → Oyuncu öldüğünde tüm nöbetçi EMS'lere bildirim gönderir
- `revive` → Nöbetçi doktor hedefi canlandırır
- `heal` → Kısmi iyileştirme (Config'deki HealAmount kadar)
- `hospitalRespawn` → EMS yoksa $2500 ödeyerek hastanede uyan
- `buyItem` → Eczaneden bandaj, medkit, ağrı kesici satın al

**Client Tarafı:**
- Ölüm algılama: `IsEntityDead()` kontrolü, 5 dakika bleedout sayacı
- Sayaç bitince [E] ile hastane respawn seçeneği
- Revive animasyonu (`get_up@directional@transition`)
- Hospital blip (sprite: 61)

**Config Ayarları:** `ReviveTime = 10s`, `WakeUpCost = $2500`, `Pharmacy Items` (Bandage $50, Medkit $200, Painkillers $100)

---

### 🔧 is4-mechanic — Tamirci Mesleği
**Amaç:** Araç onarımı, modifikasyonu ve çekici hizmeti.

**Sunucu Tarafı:**
- `repairVehicle` → Gövde/Motor/Tam tamir. Müşteriden para keser, tamirciye %70'ini öder
- `spawnTowTruck` → Nöbetçi tamirciye flatbed çekici verir

**Client Tarafı:**
- `doRepair` → `mini@repair` animasyonu, ardından `SetVehicleFixed()` / `SetVehicleBodyHealth()` vb.
- `doSpawnTow` → Çekiciyi spawn edip tamirciyi bindirir
- LS Customs blip (sprite: 446)

**Config Ayarları:** `BodyRepair = $500`, `EngineRepair = $750`, `FullRepair = $1000`, `Respray = $250`

---

### 🏴 is4-gangs — Gang / Çete Sistemi
**Amaç:** Organize suç örgütleri, bölge kontrolü ve paylaşımlı kasa.

**Sunucu Tarafı:**
- `create` → Yeni gang kurar. İsim çakışması kontrolü yapar
- `invite` → Gang liderinin başka oyuncuları davet etmesi (max 20 üye)
- `deposit` → Nakit parayı gang kasasına yatırma
- `withdraw` → Sadece lider gang kasasından para çekebilir
- Rütbe sistemi: Boss, Soldier (genişletilebilir)

---

### 💰 is4-crypto — Kripto Para Sistemi
**Amaç:** Dark web ekonomisi ve dijital para birimi.

**Sunucu Tarafı:**
- `mine` → "cryptostick" envanterinde varsa rastgele 1-5 crypto kazanır
- `exchange` → 1 Crypto = $500 nakit paraya çevrilir
- `transfer` → Oyuncular arası P2P kripto transferi

---

### 📱 is4-phone — Telefon Sistemi
**Amaç:** Mesajlaşma, acil arama (911) ve banka transferi.

**Sunucu Tarafı:**
- `sendSMS` → Hedef oyuncuya metin mesajı gönderir
- `call911` → Tüm nöbetçi polis/EMS'lere bildirim + haritada blip gösterir
- `bankTransfer` → Banka hesabından başka oyuncuya para transferi

**Client Tarafı:**
- SMS geldiğinde bildirim gösterir
- 911 çağrısında 2 dakikalık kırmızı blip çizer

---

### 💬 is4-chat — Sohbet Sistemi (NUI)
**Amaç:** Yakınlık tabanlı RP sohbeti ve global kanallar.

**Mimari:** **HTML/CSS/JS** tabanlı NUI (`modules/is4-chat/ui/`)

**Kanallar:**
| Prefix | Kanal | Renk | Kapsam |
|---|---|---|---|
| *(yok)* | LOCAL | Beyaz | Yakınlık (20m) |
| `/ooc` | OOC | Gri | Global |
| `/me` | ME | Mor | Yakınlık |
| `/do` | DO | Açık Mavi | Yakınlık |
| `/ad` | AD | Yeşil | Global |
| `/twit` | TWIT | Twitter Mavisi | Global |

**Özellikler:**
- **T** tuşu ile açılıp kapanır
- Enter ile mesaj gönderilir, Escape ile kapatılır
- Mesajlar 15 saniye sonra otomatik fade-out olur
- DOM'da maksimum 50 mesaj tutulur (performans)

---

### ⚙️ is4-system — Sunucu Yönetimi
**Amaç:** Hava durumu/saat senkronizasyonu ve admin komutları.

**Sunucu Tarafı:**
- Her 5 dakikada bir saat 10 dakika ilerler ve tüm oyunculara senkronize edilir
- `/setweather [type]` → Admin hava durumu değiştirir (CLEAR, RAIN, THUNDER vb.)
- `/settime [saat] [dakika]` → Admin saati değiştirir
- `/kick [id] [sebep]` → Oyuncu atar
- `/announce [mesaj]` → Global duyuru gönderir

**Client Tarafı:**
- `NetworkOverrideClockTime()` ile saati uygular
- `SetWeatherTypeNowPersist()` ile hava durumunu uygular
- Saat otomatik ilerlemesini engellemek için her saniye freeze yapar

---

### 🛡️ is4-anticheat — Hile Önleme Sistemi
**Amaç:** Event Bus üzerinden anomali tespiti.

**Algılama Mekanizmaları:**
1. **Para Enjeksiyonu:** `is4-core:moneyAdded` event'inde `amount > $100.000` → uyarı. 3 uyarı → otomatik kick
2. **Godmode:** Client her 10 saniyede bir HP raporlar. `health > 200` → 2 flag. 5 flag → kick
3. **Hız Hilesi:** Client her 10 saniyede bir hız raporlar. `speed > 500 km/h` → flag

---

### 🖥️ is4-advancedresources — Performans Optimizasyonu
**Amaç:** FPS ve sunucu performansını artırmak.

**Client Tarafı:**
- NPC ve araç yoğunluğu **%30'a** düşürülür (`SetPedDensityMultiplierThisFrame`)
- Polis, itfaiye, EMS, SWAT dispatch servisleri devre dışı bırakılır
- Çöp kamyonları, rastgele tekneler ve trenler kaldırılır

---

### 🎭 is4-others — Küçük RP Etkileşimleri
**Amaç:** Roleplay animasyonları ve mini etkileşimler.

**Komutlar:**
| Komut | Açıklama |
|---|---|
| `/point` | İşaret parmağıyla gösterme animasyonu (toggle) |
| `/handsup` | Ellerini kaldır (teslim ol) |
| `/crouch` | Çömelme (movement clipset değişir) |
| `/carry` | En yakın oyuncuyu sırtına al ve taşı |

---

## 🔧 Nasıl Script Yazılır?

### 1. Klasör Yapısı
```
/modules/is4-senin-modulun/
├── client/main.lua
├── server/main.lua
├── data/
├── config.lua
└── manifest.lua
```

### 2. Manifest Dosyası
```lua
return {
    name = "is4-senin-modulun",
    version = "1.0.0",
    dependencies = {"datastore", "players"},
    client = true,
    server = true
}
```
Core, bağımlılıkları çözer. `datastore` ve `players` yüklenmeden senin modülün **çalışmaz**.

### 3. Server Kodlama
```lua
local Core = exports['is4-core']:GetCore()

-- API ile para ver
exports['is4-core']:AddMoney(source, 5000)

-- Event Bus dinle
Core.Events.on("is4-core:moneyAdded", function(payload)
    print(("Oyuncu %s, %s$ kazandı!"):format(payload.source, payload.amount))
end)

-- Güvenli network callback
Core.Network.RegisterServerCallback('benim-eventim', function(src, data)
    -- Rate limit otomatik uygulanır
end)
```

### 4. Client Kodlama
```lua
local Core = exports['is4-core']:GetCore()

-- Spawn sonrası tetiklenen event
Core.Events.on("is4-core:clientSpawned", function()
    -- HUD aç, blip yükle vb.
end)

-- Sunucuya güvenli mesaj at
Core.Network.TriggerServer('benim-eventim', data)
```

---

## 📡 Event Bus Rehberi

| Event Adı | Payload | Tetiklenme Zamanı |
|---|---|---|
| `is4-core:playerLoaded` | `{source, identifier}` | Oyuncu RAM'e yüklendiğinde |
| `is4-core:clientSpawned` | — | Client dünyaya spawn olduğunda |
| `is4-core:moneyAdded` | `{source, type, amount, total}` | Para eklendiğinde |
| `is4-core:moneyRemoved` | `{source, type, amount, total}` | Para çıkarıldığında |
| `is4-core:itemAdded` | `{source, item, amount}` | Eşya verildiğinde |
| `is4-core:itemRemoved` | `{source, item, amount}` | Eşya alındığında |
| `is4-core:vehicleSpawned` | `{source, model, plate}` | Araç spawn edildiğinde |
| `module:loaded` | `moduleName` | Modül yüklendiğinde |
| `core:modulesLoaded` | `{count}` | Tüm modüller yüklendiğinde |

---

## 🎯 Config Felsefesi

**YANLIŞ:**
```lua
weaponsEnabled = true
```

**DOĞRU:**
```lua
Config.WeaponRules = {
    MaxCarried = 3,
    DurabilityMechanics = true,
    DegradationRate = 0.01,
    RepairMechanics = true,
    LicenseRequired = true
}
```

Config'leri "aç/kapa" switch'i olarak değil, **davranış tanımı** (Behavior Definition) olarak yaz. Bu yaklaşım seni gelecekte onlarca ayar ekleme derdinden kurtarır.

---

## ⚡ Performans Notları

| Özellik | Detay |
|---|---|
| **RAM Cache** | Tüm oyuncu verisi bellekte. SQL sorgusu sadece periyodik batch save'de |
| **Batch Save** | 5 dakikada bir, sadece `isDirty` oyuncular yazılır |
| **Rate Limiting** | Client → Server saniyede max 50 event |
| **Profiler** | 15ms+ süren işlemler otomatik loglanır |
| **NPC Density** | %30'a düşürülmüş (is4-advancedresources) |
| **Event Bus** | Her listener `pcall` ile sarılı, tek bir hata diğerlerini etkilemez |

---

> **is4-core** — Sıfırdan inşa edilmiş, Enterprise seviyede, tamamen bağımsız bir FiveM Framework. 🚀
