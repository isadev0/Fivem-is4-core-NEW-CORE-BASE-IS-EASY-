fx_version 'cerulean'
game 'gta5'

author 'Isa'
description 'is4-core Framework'
version '4.0.0'

shared_scripts {
    'core/config.lua',
    'core/utils.lua',
    'core/logger.lua',
    'core/profiler.lua',
    'core/event_bus.lua',
    'core/api_registry.lua',
    'core/network.lua',
    'core/module_loader.lua',
    'core/core.lua'
}

client_scripts {
    'api/notifications.lua',
    'client/modules_loader.lua',
    'client/ui.lua',
    'client/animations.lua',
    'client/map_markers.lua',
    'client/main.lua',
    
    -- Load manifest logic
    'modules/**/manifest.lua',
    
    -- Load core module logic dynamically
    'modules/**/config.lua',
    'modules/**/data/*.lua',
    'modules/**/client/*.lua'
}

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    
    'core/datastore.lua',
    'core/player_manager.lua',
    'core/permission.lua',
    
    'api/jobs.lua',
    'api/items.lua',
    'api/money.lua',
    'api/players.lua',
    'api/weapons.lua',
    'api/vehicles.lua',
    'api/notifications.lua',
    
    'server/modules_loader.lua',
    'server/commands.lua',
    'server/anti_cheat.lua',
    'server/cron.lua',
    'server/main.lua',
    
    -- Load manifest logic
    'modules/**/manifest.lua',
    
    -- Load core module logic dynamically
    'modules/**/config.lua',
    'modules/**/data/*.lua',
    'modules/**/server/*.lua'
}

-- Make Core globally accessible
export 'GetCore'
