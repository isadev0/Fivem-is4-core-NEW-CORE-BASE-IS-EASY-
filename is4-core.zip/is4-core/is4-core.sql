-- ============================================================
--  is4-core Database Schema
--  FiveM Framework - Isa tarafından yazılmıştır.
--  oxmysql uyumlu (MySQL 5.7+ / MariaDB 10.3+)
-- ============================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ------------------------------------------------------------
-- OYUNCULAR: Bağlantı bilgileri & oyun verisi
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `players` (
    `id`           INT UNSIGNED     NOT NULL AUTO_INCREMENT,
    `identifier`   VARCHAR(80)      NOT NULL UNIQUE,   -- license:XXX:char:1
    `license`      VARCHAR(60)      NOT NULL,          -- ham license:XXX
    `money`        LONGTEXT         DEFAULT NULL,      -- JSON: {cash, bank, black}
    `job`          VARCHAR(50)      NOT NULL DEFAULT 'unemployed',
    `job_grade`    TINYINT UNSIGNED NOT NULL DEFAULT 0,
    `inventory`    LONGTEXT         DEFAULT NULL,      -- JSON: {itemName: amount}
    `metadata`     LONGTEXT         DEFAULT NULL,      -- JSON: ad, soyad, kan grubu...
    `status`       TINYINT UNSIGNED NOT NULL DEFAULT 0, -- 0=offline 1=online
    `last_seen`    DATETIME         DEFAULT NULL,
    `created_at`   DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    INDEX `idx_license` (`license`),
    INDEX `idx_status`  (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- KARAKTERLER: Kimlik bilgileri (çok-karakter desteği)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `characters` (
    `id`          INT UNSIGNED  NOT NULL AUTO_INCREMENT,
    `license`     VARCHAR(60)   NOT NULL,
    `firstname`   VARCHAR(50)   NOT NULL,
    `lastname`    VARCHAR(50)   NOT NULL,
    `dob`         VARCHAR(12)   NOT NULL,              -- GG/AA/YYYY
    `gender`      TINYINT       NOT NULL DEFAULT 0,    -- 0=erkek 1=kadın
    `bloodtype`   VARCHAR(5)    NOT NULL DEFAULT 'A+',
    `fingerprint` VARCHAR(30)   DEFAULT NULL,
    `last_seen`   DATETIME      DEFAULT NULL,
    `created_at`  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    INDEX `idx_char_license` (`license`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- ENVANTER: Ayrı tablo (isteğe bağlı, büyük envanter için)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `inventories` (
    `id`         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `owner`      VARCHAR(80)     NOT NULL,             -- identifier veya 'stash:XXX'
    `type`       VARCHAR(20)     NOT NULL DEFAULT 'player', -- player, stash, vehicle, drop
    `items`      LONGTEXT        DEFAULT NULL,          -- JSON
    `updated_at` DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_owner_type` (`owner`, `type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- BANKALAR: İşlem geçmişi
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `bank_transactions` (
    `id`          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `identifier`  VARCHAR(80)     NOT NULL,
    `type`        VARCHAR(20)     NOT NULL,             -- deposit, withdraw, transfer, salary
    `amount`      INT             NOT NULL,
    `balance_after` INT           NOT NULL,
    `description` VARCHAR(255)    DEFAULT NULL,
    `created_at`  DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    INDEX `idx_bt_identifier` (`identifier`),
    INDEX `idx_bt_created`    (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- ARAÇLAR: Garajdaki araçlar
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `player_vehicles` (
    `id`          INT UNSIGNED   NOT NULL AUTO_INCREMENT,
    `identifier`  VARCHAR(80)    NOT NULL,
    `plate`       VARCHAR(10)    NOT NULL UNIQUE,
    `model`       VARCHAR(50)    NOT NULL,
    `mods`        LONGTEXT       DEFAULT NULL,          -- JSON: renk, motor, tekerlekler...
    `fuel`        FLOAT          NOT NULL DEFAULT 100.0,
    `engine`      FLOAT          NOT NULL DEFAULT 1000.0,
    `body`        FLOAT          NOT NULL DEFAULT 1000.0,
    `garage`      VARCHAR(50)    NOT NULL DEFAULT 'main',
    `state`       TINYINT        NOT NULL DEFAULT 0,    -- 0=garajda 1=dışarıda 2=impound
    `parked_x`    FLOAT          DEFAULT NULL,
    `parked_y`    FLOAT          DEFAULT NULL,
    `parked_z`    FLOAT          DEFAULT NULL,
    `parked_h`    FLOAT          DEFAULT NULL,
    `created_at`  DATETIME       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    INDEX `idx_pv_identifier` (`identifier`),
    INDEX `idx_pv_plate`      (`plate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- EVLER / MOTELler
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `properties` (
    `id`          INT UNSIGNED  NOT NULL AUTO_INCREMENT,
    `identifier`  VARCHAR(80)   NOT NULL,
    `property_id` VARCHAR(50)   NOT NULL,              -- config'deki ev adı/id
    `type`        VARCHAR(20)   NOT NULL DEFAULT 'house', -- house, motel, apartment
    `tier`        TINYINT       NOT NULL DEFAULT 1,
    `locked`      TINYINT       NOT NULL DEFAULT 1,
    `stash`       LONGTEXT      DEFAULT NULL,           -- JSON envanter
    `furniture`   LONGTEXT      DEFAULT NULL,           -- JSON mobilyalar
    `created_at`  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_property` (`property_id`),
    INDEX `idx_prop_owner` (`identifier`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- GANGS / ÇETEler
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `gangs` (
    `id`         INT UNSIGNED  NOT NULL AUTO_INCREMENT,
    `name`       VARCHAR(50)   NOT NULL UNIQUE,
    `label`      VARCHAR(100)  NOT NULL,
    `boss`       VARCHAR(80)   DEFAULT NULL,            -- identifier
    `bank`       INT UNSIGNED  NOT NULL DEFAULT 0,
    `created_at` DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `gang_members` (
    `id`          INT UNSIGNED  NOT NULL AUTO_INCREMENT,
    `identifier`  VARCHAR(80)   NOT NULL,
    `gang`        VARCHAR(50)   NOT NULL,
    `grade`       TINYINT       NOT NULL DEFAULT 0,
    `joined_at`   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_gang_member` (`identifier`),
    INDEX `idx_gm_gang` (`gang`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- SOCIETY (Şirket Kasaları)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `societies` (
    `id`         INT UNSIGNED  NOT NULL AUTO_INCREMENT,
    `job`        VARCHAR(50)   NOT NULL UNIQUE,
    `bank`       INT UNSIGNED  NOT NULL DEFAULT 0,
    `updated_at` DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- KRİPTO
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `crypto_wallets` (
    `id`          INT UNSIGNED  NOT NULL AUTO_INCREMENT,
    `identifier`  VARCHAR(80)   NOT NULL,
    `coin`        VARCHAR(20)   NOT NULL,              -- BTC, ETH, IS4COIN...
    `amount`      DECIMAL(18,8) NOT NULL DEFAULT 0,
    `updated_at`  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_wallet` (`identifier`, `coin`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- ANTICHEAT LOG
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `anticheat_logs` (
    `id`          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `identifier`  VARCHAR(80)     DEFAULT NULL,
    `player_name` VARCHAR(100)    DEFAULT NULL,
    `event_type`  VARCHAR(50)     NOT NULL,
    `details`     TEXT            DEFAULT NULL,
    `coords`      VARCHAR(80)     DEFAULT NULL,
    `created_at`  DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    INDEX `idx_ac_identifier` (`identifier`),
    INDEX `idx_ac_event`      (`event_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- SUNUCU LOG
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `server_logs` (
    `id`         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `level`      VARCHAR(10)     NOT NULL DEFAULT 'INFO', -- INFO, WARN, ERROR, TRACE
    `module`     VARCHAR(50)     DEFAULT NULL,
    `message`    TEXT            NOT NULL,
    `created_at` DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    INDEX `idx_sl_level`   (`level`),
    INDEX `idx_sl_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- ÖRNEK VERİLER (isteğe bağlı - kaldırabilirsin)
-- ------------------------------------------------------------
INSERT IGNORE INTO `societies` (`job`, `bank`) VALUES
    ('police',     50000),
    ('ambulance',  30000),
    ('mechanic',   10000),
    ('unemployed', 0);

SET FOREIGN_KEY_CHECKS = 1;

-- ============================================================
-- Kurulum tamamlandı.
-- oxmysql'in server.cfg'de yüklü olduğundan emin ol:
--   ensure oxmysql
--   ensure is4-core
-- ============================================================
