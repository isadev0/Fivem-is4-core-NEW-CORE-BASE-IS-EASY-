Config = {}

Config.CraftingRules = {
    BaseCraftTimeSeconds = 5,
    LevelSystemEnabled = true,
    LoseMaterialsOnFail = true,
    GlobalSuccessChance = 0.8 -- 80% default
}

Config.Restrictions = {
    RequireCraftingStation = true,
    JobRestrictedRecipes = true,
    AllowIllegalCrafting = true
}
