-- modules/economy/client/main.lua
-- Ekonomi Sistemi: Client Tarafı
local Core = exports['is4-core']:GetCore()
local isNearATM = false
local isNearBank = false

-- ═══════════════════════════════════════════
-- ATM MARKER & ETKİLEŞİM
-- ═══════════════════════════════════════════
Citizen.CreateThread(function()
    while true do
        Wait(0)
        local playerCoords = GetEntityCoords(PlayerPedId())
        isNearATM = false

        for _, atmCoords in ipairs(IS4.Economy.ATMLocations) do
            local dist = #(playerCoords - atmCoords)

            if dist < 15.0 then
                DrawMarker(29, atmCoords.x, atmCoords.y, atmCoords.z - 0.5, 0, 0, 0, 0, 0, 0, 0.3, 0.3, 0.3, 50, 200, 50, 150, false, false, 2, false, nil, nil, false)

                if dist < 1.5 then
                    isNearATM = true
                    ShowHelpNotification("~INPUT_CONTEXT~ ATM Kullan")

                    if IsControlJustPressed(0, 38) then -- E tuşu
                        TriggerEvent("is4-economy:openATM")
                    end
                end
            end
        end

        -- Yakında yoksa CPU tasarrufu
        if not isNearATM then
            Wait(500)
        end
    end
end)

-- ═══════════════════════════════════════════
-- BANKA MARKER & ETKİLEŞİM
-- ═══════════════════════════════════════════
Citizen.CreateThread(function()
    while true do
        Wait(0)
        local playerCoords = GetEntityCoords(PlayerPedId())
        isNearBank = false

        for _, bankData in ipairs(IS4.Economy.BankLocations) do
            local dist = #(playerCoords - bankData.coords)

            if dist < 20.0 then
                DrawMarker(1, bankData.coords.x, bankData.coords.y, bankData.coords.z - 1.0, 0, 0, 0, 0, 0, 0, 1.5, 1.5, 0.5, 0, 100, 255, 100, false, false, 2, false, nil, nil, false)

                if dist < 2.0 then
                    isNearBank = true
                    ShowHelpNotification(("~INPUT_CONTEXT~ %s Bankası"):format(bankData.label))

                    if IsControlJustPressed(0, 38) then
                        TriggerEvent("is4-economy:openBank", bankData.label)
                    end
                end
            end
        end

        if not isNearBank then
            Wait(500)
        end
    end
end)

-- ═══════════════════════════════════════════
-- BİLDİRİMLER
-- ═══════════════════════════════════════════
RegisterNetEvent("is4-economy:salaryReceived", function(amount, tax)
    exports['is4-core']:SendNotification(-1, ("💰 Maaş alındı: $%s (Vergi: $%s)"):format(amount, tax))
end)

RegisterNetEvent("is4-economy:interestReceived", function(interest)
    exports['is4-core']:SendNotification(-1, ("🏦 Faiz geliri: +$%s"):format(interest))
end)

RegisterNetEvent("is4-economy:transactionComplete", function(txType, amount)
    local messages = {
        withdraw = ("💳 $%s çekildi."):format(amount),
        deposit = ("💳 $%s yatırıldı."):format(amount),
        launder = ("💰 $%s aklandı."):format(amount),
        transfer_sent = ("📤 $%s transfer edildi."):format(amount),
        transfer_received = ("📥 $%s transfer alındı."):format(amount),
    }
    exports['is4-core']:SendNotification(-1, messages[txType] or "İşlem tamamlandı.")
end)

RegisterNetEvent("is4-economy:transactionFailed", function(reason)
    exports['is4-core']:SendNotification(-1, ("❌ İşlem başarısız: %s"):format(reason))
end)

-- ═══════════════════════════════════════════
-- YARDIMCI FONKSİYONLAR
-- ═══════════════════════════════════════════
function ShowHelpNotification(text)
    BeginTextCommandDisplayHelp("STRING")
    AddTextComponentSubstringPlayerName(text)
    EndTextCommandDisplayHelp(0, false, true, -1)
end
