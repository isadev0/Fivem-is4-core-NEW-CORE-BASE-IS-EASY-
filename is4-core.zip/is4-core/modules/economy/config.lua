Config = {}

Config.Economy = {
    StartingCash = 500,
    StartingBank = 5000,
    CurrencyFormat = "$",
    InflationMultiplier = 1.0,
    MarketPriceMultiplier = 1.0,
    SalaryInterval = 30 * 60 * 1000,  -- 30 dakika (ms)
}

Config.Transactions = {
    TransferLimit = 50000,
    DailyTransferLimit = 200000,
    BankInterestRate = 0.01,
    TaxRate = 0.05,
    LaunderingFee = 0.15,
    AllowDirtyMoney = true,
    AllowCrypto = true,
}
