-- modules/economy/server/main.lua
-- Ekonomi Sistemi: Server Tarafı
local Core = exports['is4-core']:GetCore()

-- ═══════════════════════════════════════════
-- MAAŞ ÖDEME SİSTEMİ
-- ═══════════════════════════════════════════
Citizen.CreateThread(function()
    while true do
        Wait(Config.Economy.SalaryInterval or (30 * 60 * 1000)) -- 30 dakika varsayılan

        local players = exports['is4-core']:GetAllPlayers()
        for src, player in pairs(players) do
            if player and player.job then
                local jobData = type(player.job) == "table" and player.job or nil
                local salary = 0

                if jobData then
                    salary = jobData.salary or 0
                else
                    local jobInfo = IS4.Jobs.All[player.job]
                    if jobInfo then
                        local grade = jobInfo.defaultGrade or 1
                        salary = jobInfo.grades[grade] and jobInfo.grades[grade].salary or 0
                    end
                end

                if salary > 0 then
                    local taxRate = Config.Transactions.TaxRate or 0
                    local tax = math.floor(salary * taxRate)
                    local netSalary = salary - tax

                    exports['is4-core']:AddMoney(src, "bank", netSalary)
                    TriggerClientEvent("is4-economy:salaryReceived", src, netSalary, tax)
                    IS4.Logger.Info(("[Economy] Maaş ödendi: %s → $%d (Vergi: $%d)"):format(src, netSalary, tax))
                end
            end
        end
    end
end)

-- ═══════════════════════════════════════════
-- BANKA FAİZ SİSTEMİ
-- ═══════════════════════════════════════════
Citizen.CreateThread(function()
    while true do
        Wait(60 * 60 * 1000) -- 1 saat

        local bankData = IS4.Economy.All.bank
        local interestRate = bankData and bankData.interest or 0.01

        local players = exports['is4-core']:GetAllPlayers()
        for src, player in pairs(players) do
            if player and type(player.money) == "table" then
                local bankBalance = player.money.bank or 0
                local interest = math.floor(bankBalance * interestRate)

                if interest > 0 then
                    exports['is4-core']:AddMoney(src, "bank", interest)
                    TriggerClientEvent("is4-economy:interestReceived", src, interest)
                    IS4.Logger.Info(("[Economy] Faiz ödendi: %s → +$%d"):format(src, interest))
                end
            end
        end
    end
end)

-- ═══════════════════════════════════════════
-- ATM İŞLEMLERİ
-- ═══════════════════════════════════════════
RegisterNetEvent("is4-economy:withdraw", function(amount)
    local src = source
    amount = tonumber(amount)
    if not amount or amount <= 0 then return end

    local bankMoney = exports['is4-core']:GetMoney(src, "bank")
    if bankMoney >= amount then
        exports['is4-core']:RemoveMoney(src, "bank", amount)
        exports['is4-core']:AddMoney(src, "cash", amount)
        TriggerClientEvent("is4-economy:transactionComplete", src, "withdraw", amount)
        IS4.Logger.Info(("[Economy] Para çekildi: %s → $%d"):format(src, amount))
    else
        TriggerClientEvent("is4-economy:transactionFailed", src, "Yetersiz banka bakiyesi")
    end
end)

RegisterNetEvent("is4-economy:deposit", function(amount)
    local src = source
    amount = tonumber(amount)
    if not amount or amount <= 0 then return end

    local cashMoney = exports['is4-core']:GetMoney(src, "cash")
    if cashMoney >= amount then
        exports['is4-core']:RemoveMoney(src, "cash", amount)
        exports['is4-core']:AddMoney(src, "bank", amount)
        TriggerClientEvent("is4-economy:transactionComplete", src, "deposit", amount)
        IS4.Logger.Info(("[Economy] Para yatırıldı: %s → $%d"):format(src, amount))
    else
        TriggerClientEvent("is4-economy:transactionFailed", src, "Yetersiz nakit")
    end
end)

-- ═══════════════════════════════════════════
-- KARA PARA AKLAMA
-- ═══════════════════════════════════════════
RegisterNetEvent("is4-economy:launderMoney", function(amount)
    local src = source
    amount = tonumber(amount)
    if not amount or amount <= 0 then return end

    local blackMoney = exports['is4-core']:GetMoney(src, "black_money")
    if blackMoney >= amount then
        local fee = math.floor(amount * (IS4.Economy.All.Rules.LaunderingFee or 0.15))
        local cleanAmount = amount - fee

        exports['is4-core']:RemoveMoney(src, "black_money", amount)
        exports['is4-core']:AddMoney(src, "cash", cleanAmount)
        TriggerClientEvent("is4-economy:transactionComplete", src, "launder", cleanAmount)
        IS4.Logger.Info(("[Economy] Kara para aklandı: %s → $%d (Komisyon: $%d)"):format(src, cleanAmount, fee))
    else
        TriggerClientEvent("is4-economy:transactionFailed", src, "Yetersiz kara para")
    end
end)

-- ═══════════════════════════════════════════
-- TRANSFER
-- ═══════════════════════════════════════════
RegisterNetEvent("is4-economy:transfer", function(targetId, amount)
    local src = source
    targetId = tonumber(targetId)
    amount = tonumber(amount)
    if not targetId or not amount or amount <= 0 then return end

    local success = exports['is4-core']:TransferMoney(src, targetId, "bank", amount)
    if success then
        TriggerClientEvent("is4-economy:transactionComplete", src, "transfer_sent", amount)
        TriggerClientEvent("is4-economy:transactionComplete", targetId, "transfer_received", amount)
    else
        TriggerClientEvent("is4-economy:transactionFailed", src, "Transfer başarısız")
    end
end)
