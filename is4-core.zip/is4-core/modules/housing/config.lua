Config = {}

Config.Properties = {
    PriceMultiplier = 1.0,
    RentSystemEnabled = true,
    PoliceAccess = true, -- Police can raid/unlock
    MaxUpgradeLevels = 3
}

Config.StorageLimits = {
    BaseItemSlots = 100,
    AllowWeaponStorage = true,
    AllowDirtyMoneyStorage = true
}

Config.Security = {
    RaidEnabled = true,
    KeySharingEnabled = true
}
