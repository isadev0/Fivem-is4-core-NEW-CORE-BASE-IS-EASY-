-- is4-advancedresources: Client Main
-- Performance optimization: Dynamic entity density management

local Core = exports['is4-core']:GetCore()

Core.Events.on("is4-core:clientSpawned", function()
    -- Reduce NPC density significantly for better performance
    SetPedDensityMultiplierThisFrame(0.3)
    SetVehicleDensityMultiplierThisFrame(0.3)
    SetRandomVehicleDensityMultiplierThisFrame(0.3)
    SetParkedVehicleDensityMultiplierThisFrame(0.3)
    SetScenarioPedDensityMultiplierThisFrame(0.3, 0.3)
end)

-- Continuous density control
Citizen.CreateThread(function()
    while true do
        Wait(0)
        SetPedDensityMultiplierThisFrame(0.3)
        SetVehicleDensityMultiplierThisFrame(0.3)
        SetRandomVehicleDensityMultiplierThisFrame(0.3)
        SetParkedVehicleDensityMultiplierThisFrame(0.3)
        SetScenarioPedDensityMultiplierThisFrame(0.3, 0.3)
        
        -- Disable unnecessary services
        EnableDispatchService(1, false) -- Police automobile
        EnableDispatchService(2, false) -- Police helicopter
        EnableDispatchService(3, false) -- Fire department
        EnableDispatchService(4, false) -- EMS
        EnableDispatchService(5, false) -- Gangs
        EnableDispatchService(7, false) -- SWAT
        EnableDispatchService(8, false) -- Police boats
        EnableDispatchService(9, false) -- Police train
    end
end)

-- Disable ambient sounds and overhead planes
Citizen.CreateThread(function()
    while true do
        Wait(5000)
        -- Remove random ambient sounds which eat CPU
        SetGarbageTrucks(false)
        SetRandomBoats(false)
        SetRandomTrains(false)
    end
end)
