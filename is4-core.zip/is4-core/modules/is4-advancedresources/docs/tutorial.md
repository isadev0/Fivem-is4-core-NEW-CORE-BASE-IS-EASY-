# is4-advancedresources Tutorial

How to use is4-advancedresources module.
