return {
  name = "is4-advancedresources",
  version = "1.0.0",
  dependencies = {},
  client = true,
  server = true
}
