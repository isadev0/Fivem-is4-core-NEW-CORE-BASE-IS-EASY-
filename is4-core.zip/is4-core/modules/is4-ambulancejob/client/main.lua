-- is4-ambulancejob: Client Main
local Core = exports['is4-core']:GetCore()

local isDead = false
local deathTimer = 0

-- Death detection loop
Citizen.CreateThread(function()
    while true do
        Wait(500)
        local ped = PlayerPedId()
        
        if IsEntityDead(ped) and not isDead then
            isDead = true
            deathTimer = 300 -- 5 minute bleedout timer (seconds)
            Core.Network.TriggerServer('is4-ambulance:reportDeath')
        end
        
        if isDead then
            -- Display respawn countdown
            deathTimer = deathTimer - 1
            
            if deathTimer <= 0 then
                -- Auto hospital respawn available
                BeginTextCommandDisplayHelp("STRING")
                AddTextComponentSubstringPlayerName("~INPUT_CONTEXT~ to Respawn at Hospital ($" .. Config.HospitalBed.WakeUpCost .. ")")
                EndTextCommandDisplayHelp(0, false, true, -1)
                
                if IsControlJustReleased(0, 38) then
                    Core.Network.TriggerServer('is4-ambulance:hospitalRespawn')
                end
            end
        end
    end
end)

-- Server tells us we're revived
RegisterNetEvent('is4-ambulance:doRevive', function()
    local ped = PlayerPedId()
    
    local animDict = "get_up@directional@transition@prone_to_knees@injured"
    RequestAnimDict(animDict)
    while not HasAnimDictLoaded(animDict) do Wait(10) end
    
    NetworkResurrectLocalPlayer(GetEntityCoords(ped).x, GetEntityCoords(ped).y, GetEntityCoords(ped).z, GetEntityHeading(ped), true, false)
    SetEntityHealth(ped, GetEntityMaxHealth(ped))
    ClearPedBloodDamage(ped)
    
    TaskPlayAnim(ped, animDict, "front", 8.0, -8.0, 3000, 0, 0, false, false, false)
    
    isDead = false
    deathTimer = 0
end)

-- Heal from EMS
RegisterNetEvent('is4-ambulance:applyHeal', function(amount)
    local ped = PlayerPedId()
    local currentHealth = GetEntityHealth(ped)
    SetEntityHealth(ped, math.min(currentHealth + amount, GetEntityMaxHealth(ped)))
end)

-- Hospital blip
Core.Events.on("is4-core:clientSpawned", function()
    for _, loc in ipairs(Config.Ambulance.DutyLocations) do
        local blip = AddBlipForCoord(loc.x, loc.y, loc.z)
        SetBlipSprite(blip, 61)
        SetBlipScale(blip, 0.9)
        SetBlipColour(blip, 1)
        SetBlipAsShortRange(blip, true)
        BeginTextCommandSetBlipName("STRING")
        AddTextComponentString("Hospital")
        EndTextCommandSetBlipName(blip)
    end
end)
