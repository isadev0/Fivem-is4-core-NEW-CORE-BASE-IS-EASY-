Config = {}

Config.Ambulance = {
    JobName = "ambulance",
    Ranks = {"Trainee", "Paramedic", "Doctor", "Surgeon", "Chief of Medicine"},
    DutyLocations = {
        vector3(311.23, -597.33, 43.28) -- Pillbox Hospital
    }
}

Config.ReviveSettings = {
    ReviveTime = 10000,      -- ms animation
    HealAmount = 100,
    ReviveCost = 0           -- free if EMS does it
}

Config.HospitalBed = {
    Location = vector3(311.89, -590.73, 43.29),
    WakeUpCost = 2500        -- NPC respawn cost if no EMS online
}

Config.Pharmacy = {
    Location = vector3(310.38, -594.62, 43.28),
    Items = {
        {name = "bandage", label = "Bandage", price = 50, healAmount = 20},
        {name = "medkit", label = "Medical Kit", price = 200, healAmount = 75},
        {name = "painkillers", label = "Painkillers", price = 100, healAmount = 40}
    }
}
