# is4-ambulancejob Tutorial

How to use is4-ambulancejob module.
