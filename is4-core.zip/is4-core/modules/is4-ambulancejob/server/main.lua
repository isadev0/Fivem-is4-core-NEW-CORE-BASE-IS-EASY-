-- is4-ambulancejob: Server Main
local Core = exports['is4-core']:GetCore()

local OnDuty = {}
local DeadPlayers = {} -- DeadPlayers[src] = true

-- Player death tracking
Core.Network.RegisterServerCallback('is4-ambulance:reportDeath', function(src)
    DeadPlayers[src] = true
    Core.Events.emit("is4-ambulance:playerDown", {source = src})
    
    -- Alert on-duty EMS
    for emsSrc, _ in pairs(OnDuty) do
        TriggerClientEvent('is4-core:notify', emsSrc, {text = ("Patient down! Player ID: %s"):format(src), type = "warning"})
    end
end)

-- Toggle Duty
Core.Network.RegisterServerCallback('is4-ambulance:toggleDuty', function(src)
    local player = Core.PlayerManager.GetPlayer(src)
    if not player or player.get("job") ~= Config.Ambulance.JobName then return end
    
    OnDuty[src] = not OnDuty[src]
    local status = OnDuty[src] and "ON" or "OFF"
    TriggerClientEvent('is4-core:notify', src, {text = ("EMS Duty: %s"):format(status), type = "info"})
end)

-- Revive a downed player
Core.Network.RegisterServerCallback('is4-ambulance:revive', function(src, targetId)
    if not OnDuty[src] then
        TriggerClientEvent('is4-core:notify', src, {text = "You must be on duty!", type = "error"})
        return
    end
    
    if not DeadPlayers[targetId] then return end
    
    DeadPlayers[targetId] = nil
    TriggerClientEvent('is4-ambulance:doRevive', targetId)
    TriggerClientEvent('is4-core:notify', src, {text = ("Patient %s revived!"):format(targetId), type = "success"})
    TriggerClientEvent('is4-core:notify', targetId, {text = "An EMS revived you!", type = "success"})
    Core.Events.emit("is4-ambulance:playerRevived", {source = targetId, ems = src})
end)

-- Heal a player (partially)
Core.Network.RegisterServerCallback('is4-ambulance:heal', function(src, targetId)
    if not OnDuty[src] then return end
    
    TriggerClientEvent('is4-ambulance:applyHeal', targetId, Config.ReviveSettings.HealAmount)
    TriggerClientEvent('is4-core:notify', targetId, {text = "EMS healed you.", type = "success"})
end)  

-- NPC Hospital respawn (self-revive if no EMS is online)
Core.Network.RegisterServerCallback('is4-ambulance:hospitalRespawn', function(src)
    if not DeadPlayers[src] then return end
    
    local player = Core.PlayerManager.GetPlayer(src)
    if not player then return end
    
    if not player.removeMoney("bank", Config.HospitalBed.WakeUpCost) then
        TriggerClientEvent('is4-core:notify', src, {text = ("Hospital fee: $%s. Not enough funds!"):format(Config.HospitalBed.WakeUpCost), type = "error"})
        return
    end
    
    DeadPlayers[src] = nil
    TriggerClientEvent('is4-ambulance:doRevive', src)
    TriggerClientEvent('is4-core:notify', src, {text = ("Hospital bill: $%s"):format(Config.HospitalBed.WakeUpCost), type = "warning"})
end)

-- Pharmacy purchase
Core.Network.RegisterServerCallback('is4-ambulance:buyItem', function(src, itemName)
    local player = Core.PlayerManager.GetPlayer(src)
    if not player then return end
    
    for _, item in ipairs(Config.Pharmacy.Items) do
        if item.name == itemName then
            if player.removeMoney("cash", item.price) then
                player.giveItem(item.name, 1)
                TriggerClientEvent('is4-core:notify', src, {text = ("Bought %s for $%s"):format(item.label, item.price), type = "success"})
            else
                TriggerClientEvent('is4-core:notify', src, {text = "Not enough cash!", type = "error"})
            end
            return
        end
    end
end)

AddEventHandler("playerDropped", function()
    OnDuty[source] = nil
    DeadPlayers[source] = nil
end)
