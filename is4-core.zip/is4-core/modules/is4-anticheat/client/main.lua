-- is4-anticheat: Client Main
local Core = exports['is4-core']:GetCore()

-- Periodic health/speed reporting to server
Citizen.CreateThread(function()
    while true do
        Wait(10000) -- Every 10 seconds
        local ped = PlayerPedId()
        local health = GetEntityHealth(ped)
        local speed = GetEntitySpeed(ped) * 3.6 -- m/s to km/h
        
        Core.Network.TriggerServer('is4-anticheat:healthReport', health)
        Core.Network.TriggerServer('is4-anticheat:speedReport', speed)
    end
end)
