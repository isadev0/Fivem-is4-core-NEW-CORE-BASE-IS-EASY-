# is4-anticheat Tutorial

How to use is4-anticheat module.
