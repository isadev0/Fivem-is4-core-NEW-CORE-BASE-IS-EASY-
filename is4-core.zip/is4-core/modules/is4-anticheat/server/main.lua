-- is4-anticheat: Server Main
local Core = exports['is4-core']:GetCore()

local SuspiciousFlags = {} -- SuspiciousFlags[src] = count

-- Listen to economy events for anomaly detection
Core.Events.on('is4-core:moneyAdded', function(data)
    if data.amount > 100000 then
        SuspiciousFlags[data.source] = (SuspiciousFlags[data.source] or 0) + 1
        Core.Logger.Warning(("[AntiCheat] ⚠️ Suspicious money injection: Player %s received $%s"):format(data.source, data.amount))
        
        if SuspiciousFlags[data.source] >= 3 then
            DropPlayer(data.source, "[is4-anticheat] Suspicious activity detected. You have been kicked.")
            Core.Logger.Error(("[AntiCheat] 🚫 Player %s KICKED for repeated suspicious money injection."):format(data.source))
        end
    end
end)

-- Health anomaly (godmode detection)
Core.Network.RegisterServerCallback('is4-anticheat:healthReport', function(src, health)
    if health > 200 then
        SuspiciousFlags[src] = (SuspiciousFlags[src] or 0) + 2
        Core.Logger.Warning(("[AntiCheat] ⚠️ Godmode suspected for player %s (health: %s)"):format(src, health))
        
        if SuspiciousFlags[src] >= 5 then
            DropPlayer(src, "[is4-anticheat] Abnormal health detected.")
        end
    end
end)

-- Speed anomaly (teleport/speed hack detection)  
Core.Network.RegisterServerCallback('is4-anticheat:speedReport', function(src, speed)
    if speed > 500.0 then -- km/h, no normal vehicle reaches this
        SuspiciousFlags[src] = (SuspiciousFlags[src] or 0) + 1
        Core.Logger.Warning(("[AntiCheat] ⚠️ Speed anomaly for player %s (speed: %.1f)"):format(src, speed))
    end
end)

-- Weapon anomaly
Core.Events.on('is4-core:weaponGiven', function(data)
    -- If weapons are given too fast (like injector spam)
    -- This is just a basic check
    Core.Logger.Info(("[AntiCheat] Weapon monitoring: %s gave weapon to %s"):format("API", data.source))
end)

AddEventHandler("playerDropped", function() SuspiciousFlags[source] = nil end)
