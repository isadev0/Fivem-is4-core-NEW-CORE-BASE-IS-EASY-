-- is4-chat: Client Main
local Core = exports['is4-core']:GetCore()

local chatOpen = false

-- Toggle chat
RegisterCommand('', function() end) -- Placeholder

-- Open chat with T key
Citizen.CreateThread(function()
    while true do
        Wait(0)
        if IsControlJustPressed(0, 245) then -- T key
            chatOpen = not chatOpen
            SendNUIMessage({action = chatOpen and "openChat" or "closeChat"})
            SetNuiFocus(chatOpen, chatOpen)
        end
    end
end)

-- NUI callback 'sendMessage' from JS
RegisterNUICallback("sendMessage", function(data, cb)
    if data.message and #data.message > 0 then
        Core.Network.TriggerServer('is4-chat:sendMessage', data.message)
    end
    chatOpen = false
    SetNuiFocus(false, false)
    SendNUIMessage({action = "closeChat"})
    cb("ok")
end)

-- NUI callback 'closeChat' from JS (Escape key)
RegisterNUICallback("closeChat", function(data, cb)
    chatOpen = false
    SetNuiFocus(false, false)
    cb("ok")
end)

-- Receive messages from server
RegisterNetEvent('is4-chat:receiveMessage', function(msgData)
    SendNUIMessage({
        action = "addMessage",
        sender = msgData.sender,
        message = msgData.message,
        channel = msgData.channel,
        color = msgData.color
    })
end)
