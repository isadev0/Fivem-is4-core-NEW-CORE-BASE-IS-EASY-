Config = {}

Config.Chat = {
    MaxMessageLength = 256,
    ProximityRange = 20.0,
    DefaultColor = {r = 255, g = 255, b = 255}
}

Config.Channels = {
    {name = "OOC", prefix = "/ooc", color = {r = 200, g = 200, b = 200}, global = true},
    {name = "ME", prefix = "/me", color = {r = 198, g = 132, b = 255}, global = false},
    {name = "DO", prefix = "/do", color = {r = 132, g = 198, b = 255}, global = false},
    {name = "AD", prefix = "/ad", color = {r = 50, g = 205, b = 50}, global = true},
    {name = "TWIT", prefix = "/twit", color = {r = 29, g = 161, b = 242}, global = true}
}
