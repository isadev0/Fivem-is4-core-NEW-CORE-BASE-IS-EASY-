-- is4-chat: Server Main
local Core = exports['is4-core']:GetCore()

-- Normal proximity chat
Core.Network.RegisterServerCallback('is4-chat:sendMessage', function(src, message)
    if not message or #message == 0 or #message > Config.Chat.MaxMessageLength then return end
    
    local player = Core.PlayerManager.GetPlayer(src)
    local senderName = "Unknown"
    if player then
        local meta = player.get("metadata")
        if meta and meta.firstname then
            senderName = meta.firstname .. " " .. (meta.lastname or "")
        end
    end
    
    -- Check for channel prefixes
    local channel = nil
    for _, ch in ipairs(Config.Channels) do
        if message:sub(1, #ch.prefix) == ch.prefix then
            channel = ch
            message = message:sub(#ch.prefix + 2) -- Remove prefix + space
            break
        end
    end
    
    if channel then
        if channel.global then
            -- Broadcast to all players
            TriggerClientEvent('is4-chat:receiveMessage', -1, {
                sender = senderName,
                message = message,
                channel = channel.name,
                color = channel.color
            })
        else
            -- Proximity-only (/me, /do)
            local senderCoords = GetEntityCoords(GetPlayerPed(src))
            local players = GetPlayers()
            
            for _, targetSrc in ipairs(players) do
                local targetPed = GetPlayerPed(tonumber(targetSrc))
                if targetPed then
                    local dist = #(senderCoords - GetEntityCoords(targetPed))
                    if dist <= Config.Chat.ProximityRange then
                        TriggerClientEvent('is4-chat:receiveMessage', tonumber(targetSrc), {
                            sender = senderName,
                            message = message,
                            channel = channel.name,
                            color = channel.color
                        })
                    end
                end
            end
        end
    else
        -- Default proximity chat (no prefix)
        local senderCoords = GetEntityCoords(GetPlayerPed(src))
        local players = GetPlayers()
        
        for _, targetSrc in ipairs(players) do
            local targetPed = GetPlayerPed(tonumber(targetSrc))
            if targetPed then
                local dist = #(senderCoords - GetEntityCoords(targetPed))
                if dist <= Config.Chat.ProximityRange then
                    TriggerClientEvent('is4-chat:receiveMessage', tonumber(targetSrc), {
                        sender = senderName,
                        message = message,
                        channel = "LOCAL",
                        color = Config.Chat.DefaultColor
                    })
                end
            end
        end
    end
end)
