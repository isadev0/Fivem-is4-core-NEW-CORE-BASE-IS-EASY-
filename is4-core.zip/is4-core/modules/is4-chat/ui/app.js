const MAX_MESSAGES = 50;

window.addEventListener('message', function (event) {
    let data = event.data;

    switch (data.action) {
        case "openChat":
            document.getElementById("chat-input-wrapper").style.display = "block";
            document.getElementById("chat-input").focus();
            break;

        case "closeChat":
            document.getElementById("chat-input-wrapper").style.display = "none";
            document.getElementById("chat-input").value = "";
            break;

        case "addMessage":
            let container = document.getElementById("chat-messages");
            let msg = document.createElement("div");
            msg.classList.add("chat-msg");

            let channelTag = document.createElement("span");
            channelTag.classList.add("channel-tag");
            channelTag.innerText = `[${data.channel}]`;
            if (data.color) {
                channelTag.style.color = `rgb(${data.color.r}, ${data.color.g}, ${data.color.b})`;
            }
            msg.appendChild(channelTag);

            let senderName = document.createElement("span");
            senderName.classList.add("sender-name");
            senderName.innerText = data.sender + ":";
            msg.appendChild(senderName);

            let text = document.createTextNode(" " + data.message);
            msg.appendChild(text);

            container.appendChild(msg);
            container.scrollTop = container.scrollHeight;

            // Limit messages in DOM
            while (container.children.length > MAX_MESSAGES) {
                container.removeChild(container.firstChild);
            }

            // Auto-fade messages after 15 seconds
            setTimeout(() => {
                msg.style.transition = "opacity 2s";
                msg.style.opacity = "0";
                setTimeout(() => msg.remove(), 2000);
            }, 15000);
            break;
    }
});

// Enter key sends message, Escape closes chat
document.addEventListener('keydown', function (e) {
    if (e.key === 'Enter') {
        let input = document.getElementById("chat-input");
        if (input.value.trim().length > 0) {
            fetch(`https://${GetParentResourceName()}/sendMessage`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ message: input.value.trim() })
            });
        }
        input.value = "";
    } else if (e.key === 'Escape') {
        fetch(`https://${GetParentResourceName()}/closeChat`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({})
        });
    }
});
