-- is4-crypto: Client Main
local Core = exports['is4-core']:GetCore()

Core.Events.on("is4-core:clientSpawned", function()
    Core.Logger.Info("[is4-crypto] Crypto wallet module initialized on client.")
end)
