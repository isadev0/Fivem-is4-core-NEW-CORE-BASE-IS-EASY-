-- is4-crypto: Server Main
local Core = exports['is4-core']:GetCore()

local CryptoWallets = {} -- CryptoWallets[src] = {balance = 0}

Core.Events.on('is4-core:playerLoaded', function(data)
    CryptoWallets[data.source] = {balance = 0}
end)

-- Mine crypto (requires a "cryptostick" item)
Core.Network.RegisterServerCallback('is4-crypto:mine', function(src)
    local player = Core.PlayerManager.GetPlayer(src)
    if not player then return end
    
    if not player.get("inventory")["cryptostick"] then
        TriggerClientEvent('is4-core:notify', src, {text = "You need a CryptoStick USB to mine!", type = "error"})
        return
    end
    
    local mined = math.random(1, 5)
    CryptoWallets[src].balance = CryptoWallets[src].balance + mined
    TriggerClientEvent('is4-core:notify', src, {text = ("+%s Crypto mined! Total: %s"):format(mined, CryptoWallets[src].balance), type = "success"})
    Core.Events.emit("is4-crypto:mined", {source = src, amount = mined})
end)

-- Exchange crypto to cash
Core.Network.RegisterServerCallback('is4-crypto:exchange', function(src, amount)
    if not CryptoWallets[src] or CryptoWallets[src].balance < amount then
        TriggerClientEvent('is4-core:notify', src, {text = "Not enough crypto!", type = "error"})
        return
    end
    
    local cashValue = amount * 500 -- 1 crypto = $500
    CryptoWallets[src].balance = CryptoWallets[src].balance - amount
    
    local player = Core.PlayerManager.GetPlayer(src)
    player.addMoney("cash", cashValue)
    TriggerClientEvent('is4-core:notify', src, {text = ("Exchanged %s crypto for $%s"):format(amount, cashValue), type = "success"})
end)

-- Transfer crypto between players
Core.Network.RegisterServerCallback('is4-crypto:transfer', function(src, targetId, amount)
    if not CryptoWallets[src] or CryptoWallets[src].balance < amount then return end
    if not CryptoWallets[targetId] then CryptoWallets[targetId] = {balance = 0} end
    
    CryptoWallets[src].balance = CryptoWallets[src].balance - amount
    CryptoWallets[targetId].balance = CryptoWallets[targetId].balance + amount
    
    TriggerClientEvent('is4-core:notify', src, {text = ("Sent %s crypto to player %s"):format(amount, targetId), type = "success"})
    TriggerClientEvent('is4-core:notify', targetId, {text = ("Received %s crypto!"):format(amount), type = "success"})
end)

AddEventHandler("playerDropped", function() CryptoWallets[source] = nil end)
