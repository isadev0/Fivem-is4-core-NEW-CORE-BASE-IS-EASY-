-- is4-gangs: Client Main
local Core = exports['is4-core']:GetCore()

-- Placeholder for gang territory markers
Core.Events.on("is4-core:clientSpawned", function()
    Core.Logger.Info("[is4-gangs] Gang client module initialized. Territory markers will load from server data.")
end)
