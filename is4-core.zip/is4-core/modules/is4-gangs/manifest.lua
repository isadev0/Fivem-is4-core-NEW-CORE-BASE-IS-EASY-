return {
  name = "is4-gangs",
  version = "1.0.0",
  dependencies = {},
  client = true,
  server = true
}
