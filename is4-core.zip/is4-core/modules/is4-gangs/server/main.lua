-- is4-gangs: Server Main
local Core = exports['is4-core']:GetCore()

local Gangs = {} -- Gangs["ballas"] = {leader = src, members = {}, stash = {}, territory = {}, money = 0}

Core.Network.RegisterServerCallback('is4-gangs:create', function(src, gangName)
    if Gangs[gangName] then
        TriggerClientEvent('is4-core:notify', src, {text = "Gang name taken!", type = "error"})
        return
    end
    local player = Core.PlayerManager.GetPlayer(src)
    if not player then return end
    
    Gangs[gangName] = {
        leader = player.get("identifier"),
        members = {player.get("identifier")},
        stash = {},
        territory = {},
        money = 0,
        rank = {[player.get("identifier")] = "Boss"}
    }
    TriggerClientEvent('is4-core:notify', src, {text = ("Gang '%s' created!"):format(gangName), type = "success"})
    Core.Events.emit("is4-gangs:created", {source = src, gang = gangName})
end)

Core.Network.RegisterServerCallback('is4-gangs:invite', function(src, targetId, gangName)
    local gang = Gangs[gangName]
    if not gang then return end
    local player = Core.PlayerManager.GetPlayer(src)
    if gang.leader ~= player.get("identifier") then return end
    
    local target = Core.PlayerManager.GetPlayer(targetId)
    if not target then return end
    
    if #gang.members >= 20 then
        TriggerClientEvent('is4-core:notify', src, {text = "Gang is full!", type = "error"})
        return
    end
    
    table.insert(gang.members, target.get("identifier"))
    gang.rank[target.get("identifier")] = "Soldier"
    TriggerClientEvent('is4-core:notify', targetId, {text = ("You joined gang '%s'!"):format(gangName), type = "success"})
end)

Core.Network.RegisterServerCallback('is4-gangs:deposit', function(src, gangName, amount)
    local gang = Gangs[gangName]
    if not gang then return end
    local player = Core.PlayerManager.GetPlayer(src)
    if player.removeMoney("cash", amount) then
        gang.money = gang.money + amount
        TriggerClientEvent('is4-core:notify', src, {text = ("$%s deposited to gang stash."):format(amount), type = "success"})
    end
end)

Core.Network.RegisterServerCallback('is4-gangs:withdraw', function(src, gangName, amount)
    local gang = Gangs[gangName]
    if not gang then return end
    local player = Core.PlayerManager.GetPlayer(src)
    if gang.leader ~= player.get("identifier") then return end
    
    if gang.money >= amount then
        gang.money = gang.money - amount
        player.addMoney("cash", amount)
        TriggerClientEvent('is4-core:notify', src, {text = ("$%s withdrawn from gang stash."):format(amount), type = "success"})
    end
end)
