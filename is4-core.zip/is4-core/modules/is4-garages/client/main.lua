-- is4-garages: Client Main
local Core = exports['is4-core']:GetCore()
local currentGarage = nil

-- Create blips for all garage locations on spawn
Core.Events.on("is4-core:clientSpawned", function()
    for name, data in pairs(Config.GarageLocations) do
        local blip = AddBlipForCoord(data.coords.x, data.coords.y, data.coords.z)
        SetBlipSprite(blip, data.blip.sprite)
        SetBlipDisplay(blip, 4)
        SetBlipScale(blip, 0.8)
        SetBlipColour(blip, data.blip.color)
        SetBlipAsShortRange(blip, true)
        BeginTextCommandSetBlipName("STRING")
        AddTextComponentString(data.label)
        EndTextCommandSetBlipName(blip)
    end
end)

-- Proximity check thread
Citizen.CreateThread(function()
    while true do
        Wait(500)
        local playerCoords = GetEntityCoords(PlayerPedId())
        
        for name, data in pairs(Config.GarageLocations) do
            local dist = #(playerCoords - data.coords)
            if dist < 5.0 then
                -- Draw 3D text or marker
                DrawMarker(1, data.coords.x, data.coords.y, data.coords.z - 1.0, 0, 0, 0, 0, 0, 0, 2.0, 2.0, 1.0, 50, 150, 255, 100, false, true, 2, false)
                
                if dist < 2.5 then
                    -- Show help text
                    BeginTextCommandDisplayHelp("STRING")
                    AddTextComponentSubstringPlayerName("~INPUT_CONTEXT~ to open Garage")
                    EndTextCommandDisplayHelp(0, false, true, -1)
                    
                    if IsControlJustReleased(0, 38) then -- E key
                        currentGarage = name
                        Core.Network.TriggerServer('is4-garages:getVehicles', name)
                    end
                end
            end
        end
    end
end)

RegisterNetEvent('is4-garages:receiveVehicles', function(vehicles)
    -- In production this opens a NUI menu listing all vehicles
    -- For now, auto-spawn the first vehicle for testing
    if #vehicles > 0 and currentGarage then
        Core.Network.TriggerServer('is4-garages:spawnVehicle', vehicles[1].plate, currentGarage)
    end
end)

RegisterNetEvent('is4-garages:doSpawn', function(model, spawnPoint, vehData)
    local hash = GetHashKey(model)
    RequestModel(hash)
    while not HasModelLoaded(hash) do Wait(10) end
    
    local veh = CreateVehicle(hash, spawnPoint.x, spawnPoint.y, spawnPoint.z, spawnPoint.w, true, false)
    SetVehicleNumberPlateText(veh, vehData.plate)
    SetVehicleFuelLevel(veh, vehData.fuel + 0.0)
    SetVehicleBodyHealth(veh, 1000.0 - vehData.bodyDamage)
    SetVehicleEngineHealth(veh, 1000.0 - vehData.engineDamage)
    
    TaskWarpPedIntoVehicle(PlayerPedId(), veh, -1)
    SetModelAsNoLongerNeeded(hash)
    
    Core.Logger.Info("[is4-garages] Vehicle spawned successfully.")
end)

RegisterNetEvent('is4-garages:doStore', function()
    local ped = PlayerPedId()
    local veh = GetVehiclePedIsIn(ped, false)
    if veh ~= 0 then
        DeleteEntity(veh)
    end
    Core.Logger.Info("[is4-garages] Vehicle stored successfully.")
end)
