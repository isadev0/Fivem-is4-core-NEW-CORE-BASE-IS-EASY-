Config = {}

Config.Garages = {
    MaxCapacity = 5,
    SpawnCooldown = 60,
    ImpoundFee = 500,
    InsuranceEnabled = true
}

Config.GarageLocations = {
    ["legion"]    = {label = "Legion Square", coords = vector3(215.83, -810.18, 30.73), spawnPoint = vector4(223.49, -800.44, 30.55, 248.92), blip = {sprite = 357, color = 3}},
    ["pillbox"]   = {label = "Pillbox Hill", coords = vector3(274.81, -345.0, 44.91), spawnPoint = vector4(270.68, -342.18, 44.74, 161.86), blip = {sprite = 357, color = 3}},
    ["impound"]   = {label = "Impound Lot", coords = vector3(409.09, -1623.1, 29.29), spawnPoint = vector4(408.83, -1631.26, 29.29, 230.93), blip = {sprite = 68, color = 1}}
}
