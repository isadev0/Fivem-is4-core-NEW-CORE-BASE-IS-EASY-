-- is4-garages: Server Main
local Core = exports['is4-core']:GetCore()

-- In-memory garage storage per player
local PlayerGarages = {} -- PlayerGarages[src] = { {plate="ABC123", model="blista", stored=true, fuel=100, damage=0.0}, ... }

-- When player loads, fetch their vehicles from DB
Core.Events.on('is4-core:playerLoaded', function(data)
    local src = data.source
    local identifier = data.identifier
    
    -- Mock DB fetch
    PlayerGarages[src] = {
        {plate = "IS4 001", model = "blista", stored = true, fuel = 85, bodyDamage = 0.0, engineDamage = 0.0},
        {plate = "IS4 002", model = "sultan", stored = true, fuel = 60, bodyDamage = 150.0, engineDamage = 50.0}
    }
    
    Core.Logger.Info(("[is4-garages] Loaded %s vehicles for player %s"):format(#PlayerGarages[src], src))
end)

-- Fetch stored vehicles for a specific garage
Core.Network.RegisterServerCallback('is4-garages:getVehicles', function(src, garageName)
    local vehicles = PlayerGarages[src]
    if not vehicles then
        TriggerClientEvent('is4-garages:receiveVehicles', src, {})
        return
    end
    
    local storedOnly = {}
    for _, v in ipairs(vehicles) do
        if v.stored then
            table.insert(storedOnly, v)
        end
    end
    
    TriggerClientEvent('is4-garages:receiveVehicles', src, storedOnly)
end)

-- Spawn a stored vehicle
Core.Network.RegisterServerCallback('is4-garages:spawnVehicle', function(src, plate, garageName)
    local vehicles = PlayerGarages[src]
    if not vehicles then return end
    
    local garageConf = Config.GarageLocations[garageName]
    if not garageConf then return end
    
    for _, v in ipairs(vehicles) do
        if v.plate == plate and v.stored then
            v.stored = false
            TriggerClientEvent('is4-garages:doSpawn', src, v.model, garageConf.spawnPoint, v)
            Core.Events.emit("is4-core:vehicleSpawned", {source = src, model = v.model, plate = plate})
            Core.Logger.Info(("[is4-garages] Player %s spawned vehicle %s"):format(src, plate))
            return
        end
    end
end)

-- Store (park) a vehicle back
Core.Network.RegisterServerCallback('is4-garages:storeVehicle', function(src, plate)
    local vehicles = PlayerGarages[src]
    if not vehicles then return end
    
    for _, v in ipairs(vehicles) do
        if v.plate == plate then
            v.stored = true
            TriggerClientEvent('is4-garages:doStore', src)
            Core.Logger.Info(("[is4-garages] Player %s stored vehicle %s"):format(src, plate))
            return
        end
    end
end)

-- Clean up on disconnect
AddEventHandler("playerDropped", function()
    PlayerGarages[source] = nil
end)
