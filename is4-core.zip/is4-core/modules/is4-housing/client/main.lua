-- is4-housing: Client Main
local Core = exports['is4-core']:GetCore()
local insideHouse = nil

Core.Events.on("is4-core:clientSpawned", function()
    for id, data in pairs(Config.Houses) do
        local blip = AddBlipForCoord(data.coords.x, data.coords.y, data.coords.z)
        SetBlipSprite(blip, data.blip.sprite)
        SetBlipScale(blip, 0.7)
        SetBlipColour(blip, data.blip.color)
        SetBlipAsShortRange(blip, true)
        BeginTextCommandSetBlipName("STRING")
        AddTextComponentString(data.label)
        EndTextCommandSetBlipName(blip)
    end
end)

Citizen.CreateThread(function()
    while true do
        Wait(500)
        local playerCoords = GetEntityCoords(PlayerPedId())
        
        for id, data in pairs(Config.Houses) do
            if not insideHouse then
                local dist = #(playerCoords - data.enter)
                if dist < 2.0 then
                    BeginTextCommandDisplayHelp("STRING")
                    AddTextComponentSubstringPlayerName("~INPUT_CONTEXT~ to Enter / Buy Property")
                    EndTextCommandDisplayHelp(0, false, true, -1)
                    
                    if IsControlJustReleased(0, 38) then
                        Core.Network.TriggerServer('is4-housing:enterHouse', id)
                    end
                end
            end
        end
    end
end)

RegisterNetEvent('is4-housing:teleportInside', function(interiorCoords)
    SetEntityCoords(PlayerPedId(), interiorCoords.x, interiorCoords.y, interiorCoords.z, false, false, false, true)
    insideHouse = true
end)
