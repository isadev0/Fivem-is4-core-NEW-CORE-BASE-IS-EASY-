Config = {}

Config.Properties = {
    PriceMultiplier = 1.0,
    RentSystemEnabled = true,
    PoliceAccess = true,
    MaxUpgradeLevels = 3
}

Config.StorageLimits = {
    BaseItemSlots = 100,
    AllowWeaponStorage = true,
    AllowDirtyMoneyStorage = true
}

Config.Houses = {
    ["grove_house_1"] = {
        label = "Grove Street House",
        price = 150000,
        coords = vector3(-14.54, -1438.87, 31.1),
        enter = vector3(-14.54, -1438.87, 31.1),
        exit = vector3(266.05, -1007.53, -101.01),
        interior = vector3(266.05, -1007.53, -101.01),
        blip = {sprite = 40, color = 2}
    },
    ["vinewood_apt_1"] = {
        label = "Vinewood Apartment",
        price = 350000,
        coords = vector3(-1453.51, -537.65, 34.74),
        enter = vector3(-1453.51, -537.65, 34.74),
        exit = vector3(266.05, -1007.53, -101.01),
        interior = vector3(266.05, -1007.53, -101.01),
        blip = {sprite = 40, color = 5}
    }
}
