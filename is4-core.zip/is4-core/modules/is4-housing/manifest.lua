return {
  name = "is4-housing",
  version = "1.0.0",
  dependencies = {},
  client = true,
  server = true
}
