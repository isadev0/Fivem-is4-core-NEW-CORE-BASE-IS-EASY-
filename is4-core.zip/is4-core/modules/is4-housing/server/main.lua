-- is4-housing: Server Main
local Core = exports['is4-core']:GetCore()

local OwnedHouses = {} -- OwnedHouses["grove_house_1"] = {owner = "license:xxx", keys = {"license:yyy"}, storage = {}}

-- Load house ownership from DB on resource start
Citizen.CreateThread(function()
    Wait(1000)
    -- Mock: In production, SELECT * FROM houses
    Core.Logger.Info("[is4-housing] Housing system initialized. Loaded property data.")
end)

-- Purchase a house
Core.Network.RegisterServerCallback('is4-housing:buyHouse', function(src, houseId)
    local houseConf = Config.Houses[houseId]
    if not houseConf then return end
    
    -- Check if already owned
    if OwnedHouses[houseId] then
        TriggerClientEvent('is4-core:notify', src, {text = "This property is already owned!", type = "error"})
        return
    end
    
    local player = Core.PlayerManager.GetPlayer(src)
    if not player then return end
    
    local price = math.floor(houseConf.price * Config.Properties.PriceMultiplier)
    
    -- Check bank balance
    if player.get("money").bank < price then
        TriggerClientEvent('is4-core:notify', src, {text = "Insufficient funds!", type = "error"})
        return
    end
    
    player.removeMoney("bank", price)
    
    OwnedHouses[houseId] = {
        owner = player.get("identifier"),
        keys = {},
        storage = {},
        upgradeLevel = 0
    }
    
    TriggerClientEvent('is4-core:notify', src, {text = ("You bought %s for $%s!"):format(houseConf.label, price), type = "success"})
    Core.Events.emit("is4-housing:purchased", {source = src, houseId = houseId, price = price})
    Core.Logger.Info(("[is4-housing] Player %s purchased %s for $%s"):format(src, houseId, price))
end)

-- Enter house
Core.Network.RegisterServerCallback('is4-housing:enterHouse', function(src, houseId)
    local house = OwnedHouses[houseId]
    if not house then return end
    
    local player = Core.PlayerManager.GetPlayer(src)
    if not player then return end
    
    local isOwner = house.owner == player.get("identifier")
    local hasKey = false
    for _, k in ipairs(house.keys) do
        if k == player.get("identifier") then hasKey = true break end
    end
    
    if isOwner or hasKey then
        local houseConf = Config.Houses[houseId]
        TriggerClientEvent('is4-housing:teleportInside', src, houseConf.interior)
    else
        TriggerClientEvent('is4-core:notify', src, {text = "You don't have keys to this property.", type = "error"})
    end
end)

-- Give key to another player
Core.Network.RegisterServerCallback('is4-housing:giveKey', function(src, houseId, targetId)
    local house = OwnedHouses[houseId]
    if not house then return end
    
    local player = Core.PlayerManager.GetPlayer(src)
    if house.owner ~= player.get("identifier") then return end
    
    local target = Core.PlayerManager.GetPlayer(targetId)
    if not target then return end
    
    table.insert(house.keys, target.get("identifier"))
    TriggerClientEvent('is4-core:notify', src, {text = ("Key given to player %s"):format(targetId), type = "success"})
    TriggerClientEvent('is4-core:notify', targetId, {text = "You received a house key!", type = "success"})
end)

-- Access house storage
Core.Network.RegisterServerCallback('is4-housing:getStorage', function(src, houseId)
    local house = OwnedHouses[houseId]
    if not house then return end
    
    TriggerClientEvent('is4-housing:openStorage', src, house.storage)
end)
