-- is4-hud Client Script
local Core = exports['is4-core']:GetCore()
local isVisible = false

-- Listen to the global event bus explicitly (Event-Driven Architecture)
-- The UI doesn't run continuous Citizen loops checking for variables it doesn't own

-- 1. Display HUD on spawn
Core.Events.on("is4-core:clientSpawned", function()
    isVisible = true
    SendNUIMessage({ action = "showHUD" })
end)

-- 2. Update Needs from `is4-needs` module
Core.Events.on("client:updateNeeds", function(data)
    if not isVisible then return end
    SendNUIMessage({
        action = "updateStatus",
        hunger = data.hunger,
        thirst = data.thirst
    })
end)

-- 3. Native Health & Armor Loop (Since GTA manages this locally mostly)
Citizen.CreateThread(function()
    while true do
        Wait(500)
        if isVisible then
            local ped = PlayerPedId()
            local hp = GetEntityHealth(ped) - 100 -- Default ped health is 200 max, 100 is dead
            local armor = GetPedArmour(ped)
            
            if hp < 0 then hp = 0 end
            if hp > 100 then hp = 100 end

            SendNUIMessage({
                action = "updateStatus",
                health = hp,
                armor = armor
            })
        end
    end
end)

-- Display money updates securely
RegisterNetEvent('is4-hud:updateEconomy', function(cash, bank)
    SendNUIMessage({
        action = "updateEconomy",
        cash = cash,
        bank = bank
    })
end)

RegisterNetEvent('is4-hud:moneyFlash', function(type, amount)
    SendNUIMessage({
        action = "moneyFlash",
        type = type, -- "plus" or "minus"
        amount = amount
    })
end)
