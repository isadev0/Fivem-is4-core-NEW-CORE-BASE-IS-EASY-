return {
    name = "is4-hud",
    version = "1.0.0",
    dependencies = {},
    client = true,
    server = true,
    ui_page = "ui/index.html",
    files = {
        "ui/index.html",
        "ui/style.css",
        "ui/app.js"
    }
}
