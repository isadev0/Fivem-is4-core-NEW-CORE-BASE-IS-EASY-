-- is4-hud Server Script
local Core = exports['is4-core']:GetCore()

-- The Server listens to the Core event bus, then triggers NetEvents to specific clients to update their screen
-- This embodies complete "Loose Coupling". The Core doesn't know about UI, the UI only knows to listen to the Core.

-- When player object loads in DB/RAM
Core.Events.on('is4-core:playerLoaded', function(data)
    local src = data.source
    local player = Core.PlayerManager.GetPlayer(src)
    if player then
        local cash = player.get("money").cash
        local bank = player.get("money").bank
        TriggerClientEvent('is4-hud:updateEconomy', src, cash, bank)
    end
end)

-- Economy Events
Core.Events.on('is4-core:moneyAdded', function(data)
    -- data shape: {source = src, type = "cash"/"bank", amount = 100, total = 600}
    TriggerClientEvent('is4-hud:moneyFlash', data.source, "plus", data.amount)
    
    local cashUpdate = nil
    local bankUpdate = nil
    if data.type == "cash" then cashUpdate = data.total else bankUpdate = data.total end
    
    TriggerClientEvent('is4-hud:updateEconomy', data.source, cashUpdate, bankUpdate)
end)

Core.Events.on('is4-core:moneyRemoved', function(data)
    TriggerClientEvent('is4-hud:moneyFlash', data.source, "minus", data.amount)
    
    local cashUpdate = nil
    local bankUpdate = nil
    if data.type == "cash" then cashUpdate = data.total else bankUpdate = data.total end
    
    TriggerClientEvent('is4-hud:updateEconomy', data.source, cashUpdate, bankUpdate)
end)
