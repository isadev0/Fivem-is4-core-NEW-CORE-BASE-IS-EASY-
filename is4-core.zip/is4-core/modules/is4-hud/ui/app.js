window.addEventListener('message', function(event) {
    let data = event.data;

    switch(data.action) {
        case "showHUD":
            document.getElementById("hud-container").style.display = "block";
            break;
        case "hideHUD":
            document.getElementById("hud-container").style.display = "none";
            break;
        
        case "updateEconomy":
            if (data.bank !== undefined) {
                document.getElementById("bank-val").innerText = "$" + data.bank.toLocaleString();
            }
            if (data.cash !== undefined) {
                document.getElementById("cash-val").innerText = "$" + data.cash.toLocaleString();
            }
            break;

        case "moneyFlash":
            let container = document.getElementById("money-anim-container");
            let anim = document.createElement("div");
            anim.classList.add("money-anim");
            anim.innerText = (data.type === "plus" ? "+" : "-") + "$" + data.amount.toLocaleString();
            anim.classList.add(data.type);
            
            container.appendChild(anim);
            
            setTimeout(() => {
                anim.remove();
            }, 2000);
            break;

        case "updateStatus":
            if (data.health !== undefined) document.getElementById("health-fill").style.height = data.health + "%";
            if (data.armor !== undefined) document.getElementById("armor-fill").style.height = data.armor + "%";
            if (data.hunger !== undefined) document.getElementById("hunger-fill").style.height = data.hunger + "%";
            if (data.thirst !== undefined) document.getElementById("thirst-fill").style.height = data.thirst + "%";
            break;
    }
});
