-- is4-mechanic: Client Main
local Core = exports['is4-core']:GetCore()

-- Repair vehicle client-side application
RegisterNetEvent('is4-mechanic:doRepair', function(repairType)
    local ped = PlayerPedId()
    local veh = GetVehiclePedIsIn(ped, false)
    if veh == 0 then
        veh = GetClosestVehicle(GetEntityCoords(ped).x, GetEntityCoords(ped).y, GetEntityCoords(ped).z, 5.0, 0, 71)
    end
    
    if veh == 0 then return end
    
    -- Play wrench animation
    local dict = "mini@repair"
    RequestAnimDict(dict)
    while not HasAnimDictLoaded(dict) do Wait(10) end
    TaskPlayAnim(ped, dict, "fixing_a_player", 8.0, -8.0, 5000, 1, 0, false, false, false)
    Wait(5000)
    
    if repairType == "BodyRepair" then
        SetVehicleBodyHealth(veh, 1000.0)
        SetVehicleDeformationFixed(veh)
    elseif repairType == "EngineRepair" then
        SetVehicleEngineHealth(veh, 1000.0)
    elseif repairType == "FullRepair" then
        SetVehicleFixed(veh)
        SetVehicleBodyHealth(veh, 1000.0)
        SetVehicleEngineHealth(veh, 1000.0)
        SetVehicleDeformationFixed(veh)
    end
    
    ClearPedTasks(ped)
end)

-- Spawn tow truck
RegisterNetEvent('is4-mechanic:doSpawnTow', function(model, spawnPoint)
    local hash = GetHashKey(model)
    RequestModel(hash)
    while not HasModelLoaded(hash) do Wait(10) end
    
    local veh = CreateVehicle(hash, spawnPoint.x, spawnPoint.y, spawnPoint.z, spawnPoint.w, true, false)
    TaskWarpPedIntoVehicle(PlayerPedId(), veh, -1)
    SetModelAsNoLongerNeeded(hash)
end)

-- Blip
Core.Events.on("is4-core:clientSpawned", function()
    local loc = Config.Mechanic.DutyLocation
    local blip = AddBlipForCoord(loc.x, loc.y, loc.z)
    SetBlipSprite(blip, 446)
    SetBlipScale(blip, 0.8)
    SetBlipColour(blip, 47)
    SetBlipAsShortRange(blip, true)
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString("Mechanic Shop")
    EndTextCommandSetBlipName(blip)
end)
