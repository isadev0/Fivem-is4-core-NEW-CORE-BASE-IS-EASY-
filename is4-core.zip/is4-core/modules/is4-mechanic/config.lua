Config = {}

Config.Mechanic = {
    JobName = "mechanic",
    Ranks = {"Apprentice", "Mechanic", "Senior Mechanic", "Manager"},
    DutyLocation = vector3(-337.39, -134.61, 39.01) -- LS Customs area
}

Config.RepairPricing = {
    BodyRepair = 500,
    EngineRepair = 750,
    FullRepair = 1000,
    Respray = 250
}

Config.TowTruck = {
    Model = "flatbed",
    SpawnPoint = vector4(-339.77, -136.46, 39.01, 160.0)
}
