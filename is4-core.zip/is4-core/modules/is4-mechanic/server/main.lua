-- is4-mechanic: Server Main
local Core = exports['is4-core']:GetCore()

local OnDuty = {}

Core.Network.RegisterServerCallback('is4-mechanic:toggleDuty', function(src)
    local player = Core.PlayerManager.GetPlayer(src)
    if not player or player.get("job") ~= Config.Mechanic.JobName then return end
    
    OnDuty[src] = not OnDuty[src]
    local status = OnDuty[src] and "ON" or "OFF"
    TriggerClientEvent('is4-core:notify', src, {text = ("Mechanic Duty: %s"):format(status), type = "info"})
end)

-- Repair vehicle
Core.Network.RegisterServerCallback('is4-mechanic:repairVehicle', function(src, targetSrc, repairType)
    if not OnDuty[src] then
        TriggerClientEvent('is4-core:notify', src, {text = "You must be on duty!", type = "error"})
        return
    end
    
    local price = Config.RepairPricing[repairType] or Config.RepairPricing.FullRepair
    local target = Core.PlayerManager.GetPlayer(targetSrc)
    
    if target then
        if target.removeMoney("cash", price) then
            TriggerClientEvent('is4-mechanic:doRepair', targetSrc, repairType)
            TriggerClientEvent('is4-core:notify', targetSrc, {text = ("%s completed. Cost: $%s"):format(repairType, price), type = "success"})
            
            -- Pay mechanic
            local mechanic = Core.PlayerManager.GetPlayer(src)
            if mechanic then
                mechanic.addMoney("cash", math.floor(price * 0.7))
            end
        else
            TriggerClientEvent('is4-core:notify', src, {text = "Customer can't afford the repair!", type = "error"})
        end
    end
end)

-- Tow truck spawn
Core.Network.RegisterServerCallback('is4-mechanic:spawnTowTruck', function(src)
    if not OnDuty[src] then return end
    TriggerClientEvent('is4-mechanic:doSpawnTow', src, Config.TowTruck.Model, Config.TowTruck.SpawnPoint)
end)

AddEventHandler("playerDropped", function()
    OnDuty[source] = nil
end)
