-- is4-motels: Client Main
local Core = exports['is4-core']:GetCore()

Core.Events.on("is4-core:clientSpawned", function()
    for id, data in pairs(Config.MotelLocations) do
        local blip = AddBlipForCoord(data.coords.x, data.coords.y, data.coords.z)
        SetBlipSprite(blip, data.blip.sprite)
        SetBlipScale(blip, 0.7)
        SetBlipColour(blip, data.blip.color)
        SetBlipAsShortRange(blip, true)
        BeginTextCommandSetBlipName("STRING")
        AddTextComponentString(data.label)
        EndTextCommandSetBlipName(blip)
    end
end)

Citizen.CreateThread(function()
    while true do
        Wait(500)
        local playerCoords = GetEntityCoords(PlayerPedId())
        
        for id, data in pairs(Config.MotelLocations) do
            local dist = #(playerCoords - data.coords)
            if dist < 3.0 then
                BeginTextCommandDisplayHelp("STRING")
                AddTextComponentSubstringPlayerName("~INPUT_CONTEXT~ to Rent a Room")
                EndTextCommandDisplayHelp(0, false, true, -1)
                
                if IsControlJustReleased(0, 38) then
                    Core.Network.TriggerServer('is4-motels:rentRoom', id)
                end
            end
        end
    end
end)
