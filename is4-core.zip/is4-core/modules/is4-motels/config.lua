Config = {}

Config.Motels = {
    RentPricePerHour = 200,
    MaxRentHours = 24,
    StorageSlots = 20
}

Config.MotelLocations = {
    ["pink_cage"] = {
        label = "Pink Cage Motel",
        coords = vector3(327.67, -205.08, 54.08),
        rooms = 6,
        blip = {sprite = 475, color = 8}
    },
    ["dream_view"] = {
        label = "Dream View Motel",
        coords = vector3(151.25, -1007.65, 29.37),
        rooms = 4,
        blip = {sprite = 475, color = 8}
    }
}
