# is4-motels Tutorial

How to use is4-motels module.
