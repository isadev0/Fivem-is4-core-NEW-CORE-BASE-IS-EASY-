-- is4-motels: Server Main
local Core = exports['is4-core']:GetCore()

local RentedRooms = {} -- RentedRooms["pink_cage_1"] = {tenant = src, expiresAt = os.time() + 3600, storage = {}}

Core.Network.RegisterServerCallback('is4-motels:rentRoom', function(src, motelId)
    local motelConf = Config.MotelLocations[motelId]
    if not motelConf then return end
    
    local player = Core.PlayerManager.GetPlayer(src)
    if not player then return end
    
    -- Find an available room
    for i = 1, motelConf.rooms do
        local roomKey = motelId .. "_" .. i
        if not RentedRooms[roomKey] then
            local price = Config.Motels.RentPricePerHour
            if not player.removeMoney("cash", price) then
                TriggerClientEvent('is4-core:notify', src, {text = "Not enough cash!", type = "error"})
                return
            end
            
            RentedRooms[roomKey] = {
                tenant = src,
                identifier = player.get("identifier"),
                expiresAt = os.time() + 3600,
                storage = {}
            }
            
            TriggerClientEvent('is4-core:notify', src, {text = ("Room %s rented at %s! ($%s/hr)"):format(i, motelConf.label, price), type = "success"})
            Core.Logger.Info(("[is4-motels] Player %s rented %s"):format(src, roomKey))
            return
        end
    end
    
    TriggerClientEvent('is4-core:notify', src, {text = "No rooms available!", type = "error"})
end)

-- Expiration loop
Citizen.CreateThread(function()
    while true do
        Wait(60000)
        local now = os.time()
        for key, room in pairs(RentedRooms) do
            if now >= room.expiresAt then
                if room.tenant then
                    TriggerClientEvent('is4-core:notify', room.tenant, {text = "Your motel room has expired!", type = "warning"})
                end
                RentedRooms[key] = nil
                Core.Logger.Info(("[is4-motels] Room %s expired."):format(key))
            end
        end
    end
end)
