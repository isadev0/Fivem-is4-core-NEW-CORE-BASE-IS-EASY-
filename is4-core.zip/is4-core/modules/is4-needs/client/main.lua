local Core = exports['is4-core']:GetCore()

local isDead = false

RegisterNetEvent('is4-needs:updateStatus', function(hunger, thirst)
    -- In a real scenario, this forwards via SendNUIMessage to Vue/React HUD
    -- SendNUIMessage({
    --     action = "updateStatus",
    --     hunger = hunger,
    --     thirst = thirst
    -- })
    
    -- We can also broadcast this over the local Event Bus so the `is4-hud` client script catches it!
    Core.Events.emit('client:updateNeeds', {hunger = hunger, thirst = thirst})
end)

RegisterNetEvent('is4-needs:starvationDamage', function()
    local ped = PlayerPedId()
    if not isDead then
        -- Apply a bit of damage every tick if starving
        local health = GetEntityHealth(ped)
        if health > 0 then
            SetEntityHealth(ped, health - 5)
        end
    end
end)
