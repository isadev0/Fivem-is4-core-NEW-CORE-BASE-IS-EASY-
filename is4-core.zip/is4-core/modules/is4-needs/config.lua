Config = {}

Config.StatusTickRate = 60000 -- Decrease needs every 60 seconds
Config.HungerDepletion = 1.0  -- Percent per tick
Config.ThirstDepletion = 1.5

Config.FoodItems = {
    ["water"]        = {thirst = 25, hunger = 0},
    ["cola"]         = {thirst = 35, hunger = 5},
    ["hamburger"]    = {thirst = 0, hunger = 40},
    ["chips"]        = {thirst = -5, hunger = 15}
}
