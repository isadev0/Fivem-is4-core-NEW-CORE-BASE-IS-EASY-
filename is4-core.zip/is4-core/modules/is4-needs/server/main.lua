local Core = exports['is4-core']:GetCore()

-- We store the metadata variables (Hunger/Thirst) inside the player object's metadata table.
-- When the player is loaded into memory, ensure they have default needs.
Core.Events.on('is4-core:playerLoaded', function(data)
    local src = data.source
    local player = Core.PlayerManager.GetPlayer(src)
    
    if player then
        local metadata = player.get("metadata") or {}
        if not metadata.hunger then metadata.hunger = 100.0 end
        if not metadata.thirst then metadata.thirst = 100.0 end
        
        player.set("metadata", metadata)
        
        -- Send initial stats to Client UI
        TriggerClientEvent('is4-needs:updateStatus', src, metadata.hunger, metadata.thirst)
    end
end)

-- Background loop to deplete needs
Citizen.CreateThread(function()
    while true do
        Wait(Config.StatusTickRate)
        
        local players = Core.PlayerManager.GetPlayers()
        for src, player in pairs(players) do
            local metadata = player.get("metadata")
            if metadata and metadata.hunger and metadata.thirst then
                metadata.hunger = math.max(0.0, metadata.hunger - Config.HungerDepletion)
                metadata.thirst = math.max(0.0, metadata.thirst - Config.ThirstDepletion)
                
                -- The `set` function marks them as dirty so they save to the DB in the next batch automatically!
                player.set("metadata", metadata) 
                
                -- Send HUD update
                TriggerClientEvent('is4-needs:updateStatus', src, metadata.hunger, metadata.thirst)
                
                -- If starving, send damage event to client
                if metadata.hunger <= 0.0 or metadata.thirst <= 0.0 then
                    TriggerClientEvent('is4-needs:starvationDamage', src)
                end
            end
        end
    end
end)

-- Generate Items and Usable logic based on config
Citizen.CreateThread(function()
    Wait(100)
    for itemName, effects in pairs(Config.FoodItems) do
        Core.API.Call("CreateItem", itemName, {
            label = itemName:gsub("^%l", string.upper),
            weight = 0.5,
            usable = true,
            cb = function(source)
                local player = Core.PlayerManager.GetPlayer(source)
                if not player then return end
                
                local metadata = player.get("metadata")
                if metadata then
                    if effects.hunger then metadata.hunger = math.min(100.0, metadata.hunger + effects.hunger) end
                    if effects.thirst then metadata.thirst = math.min(100.0, metadata.thirst + effects.thirst) end
                    
                    player.set("metadata", metadata)
                    Core.API.Call("RemoveItem", source, itemName, 1)
                    
                    TriggerClientEvent('is4-needs:updateStatus', source, metadata.hunger, metadata.thirst)
                    TriggerClientEvent('is4-core:notify', source, {text = ("You consumed a %s"):format(itemName), type = "success"})
                end
            end
        })
    end
    Core.Logger.Info("[is4-needs] Loaded food items into Framework Registry.")
end)
