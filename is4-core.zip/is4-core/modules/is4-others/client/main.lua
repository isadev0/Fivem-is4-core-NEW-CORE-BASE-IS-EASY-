-- is4-others: Client Main
-- Miscellaneous RP interactions

local Core = exports['is4-core']:GetCore()
local isPointing = false

-- Point animation
RegisterCommand("point", function()
    local ped = PlayerPedId()
    if isPointing then
        ClearPedTasks(ped)
        isPointing = false
    else
        RequestAnimDict("anim@mp_point")
        while not HasAnimDictLoaded("anim@mp_point") do Wait(10) end
        TaskPlayAnim(ped, "anim@mp_point", "task_mp_point_a", 8.0, -8.0, -1, 49, 0, false, false, false)
        isPointing = true
    end
end, false)

-- Hands Up animation
RegisterCommand("handsup", function()
    local ped = PlayerPedId()
    local dict = "missminuteman_1ig_2"
    RequestAnimDict(dict)
    while not HasAnimDictLoaded(dict) do Wait(10) end
    TaskPlayAnim(ped, dict, "handsup_enter", 8.0, -8.0, -1, 50, 0, false, false, false)
end, false)

-- Crouch toggle
local isCrouching = false
RegisterCommand("crouch", function()
    local ped = PlayerPedId()
    isCrouching = not isCrouching
    
    if isCrouching then
        RequestAnimSet("move_ped_crouched")
        while not HasAnimSetLoaded("move_ped_crouched") do Wait(10) end
        SetPedMovementClipset(ped, "move_ped_crouched", 0.25)
    else
        ResetPedMovementClipset(ped, 0)
    end
end, false)

-- Carry player (piggyback)
RegisterCommand("carry", function()
    local ped = PlayerPedId()
    local closestPlayer, closestDist = nil, 3.0
    
    for _, playerId in ipairs(GetActivePlayers()) do
        if playerId ~= PlayerId() then
            local targetPed = GetPlayerPed(playerId)
            local dist = #(GetEntityCoords(ped) - GetEntityCoords(targetPed))
            if dist < closestDist then
                closestPlayer = playerId
                closestDist = dist
            end
        end
    end
    
    if closestPlayer then
        local targetPed = GetPlayerPed(closestPlayer)
        RequestAnimDict("missfinale_c2mcs_1")
        while not HasAnimDictLoaded("missfinale_c2mcs_1") do Wait(10) end
        
        AttachEntityToEntity(targetPed, ped, 11816, 0.27, 0.15, 0.63, 0.5, 0.5, 0.0, false, false, false, false, 2, false)
        TaskPlayAnim(ped, "missfinale_c2mcs_1", "fin_c2_mcs_1_camman", 8.0, -8.0, -1, 49, 0, false, false, false)
    end
end, false)
