-- is4-phone: Client Main
local Core = exports['is4-core']:GetCore()

RegisterNetEvent('is4-phone:receiveSMS', function(data)
    TriggerEvent('is4-core:notify', {text = ("📱 SMS from %s: %s"):format(data.from, data.message), type = "info"})
end)

RegisterNetEvent('is4-phone:show911Blip', function(coords)
    local blip = AddBlipForCoord(coords.x, coords.y, coords.z)
    SetBlipSprite(blip, 526)
    SetBlipColour(blip, 1)
    SetBlipScale(blip, 1.5)
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString("911 Call")
    EndTextCommandSetBlipName(blip)
    
    -- Auto-remove after 2 minutes
    Citizen.CreateThread(function()
        Wait(120000)
        RemoveBlip(blip)
    end)
end)
