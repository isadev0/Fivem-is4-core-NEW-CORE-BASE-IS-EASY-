-- is4-phone: Server Main
local Core = exports['is4-core']:GetCore()

local PhoneContacts = {} -- PhoneContacts[src] = {{name="Police", number="911"}}

Core.Events.on('is4-core:playerLoaded', function(data)
    PhoneContacts[data.source] = {
        {name = "Emergency", number = "911"},
        {name = "Mechanic", number = "555-MECH"},
        {name = "Taxi", number = "555-TAXI"}
    }
end)

-- Send a text message
Core.Network.RegisterServerCallback('is4-phone:sendSMS', function(src, targetNumber, messageText)
    -- Find the target player by their phone number (we'd match via DB, mock for now)
    local allPlayers = Core.PlayerManager.GetPlayers()
    for tSrc, _ in pairs(allPlayers) do
        -- In production: player.get("metadata").phone == targetNumber
        if tSrc ~= src then
            local senderPlayer = Core.PlayerManager.GetPlayer(src)
            local senderName = "Unknown"
            if senderPlayer then
                local meta = senderPlayer.get("metadata")
                if meta and meta.firstname then senderName = meta.firstname end
            end
            
            TriggerClientEvent('is4-phone:receiveSMS', tSrc, {from = senderName, message = messageText})
            TriggerClientEvent('is4-core:notify', src, {text = "Message sent!", type = "success"})
            return
        end
    end
    TriggerClientEvent('is4-core:notify', src, {text = "Number not found!", type = "error"})
end)

-- Call emergency services
Core.Network.RegisterServerCallback('is4-phone:call911', function(src, message)
    local senderCoords = GetEntityCoords(GetPlayerPed(src))
    local player = Core.PlayerManager.GetPlayer(src)
    local callerName = "Unknown"
    if player then
        local meta = player.get("metadata")
        if meta and meta.firstname then callerName = meta.firstname .. " " .. (meta.lastname or "") end
    end
    
    -- Broadcast to all police/ems on duty
    local allPlayers = Core.PlayerManager.GetPlayers()
    for tSrc, tPlayer in pairs(allPlayers) do
        local job = tPlayer.get("job")
        if job == "police" or job == "ambulance" then
            TriggerClientEvent('is4-core:notify', tSrc, {text = ("📞 911 Call from %s: %s"):format(callerName, message), type = "warning"})
            TriggerClientEvent('is4-phone:show911Blip', tSrc, senderCoords)
        end
    end
    
    TriggerClientEvent('is4-core:notify', src, {text = "911 call dispatched.", type = "success"})
end)

-- Bank transfer via phone
Core.Network.RegisterServerCallback('is4-phone:bankTransfer', function(src, targetId, amount)
    local player = Core.PlayerManager.GetPlayer(src)
    local target = Core.PlayerManager.GetPlayer(targetId)
    
    if not player or not target then return end
    
    if player.removeMoney("bank", amount) then
        target.addMoney("bank", amount)
        TriggerClientEvent('is4-core:notify', src, {text = ("Transferred $%s"):format(amount), type = "success"})
        TriggerClientEvent('is4-core:notify', targetId, {text = ("Received $%s bank transfer"):format(amount), type = "success"})
    else
        TriggerClientEvent('is4-core:notify', src, {text = "Insufficient funds!", type = "error"})
    end
end)

AddEventHandler("playerDropped", function() PhoneContacts[source] = nil end)
