-- modules/is4-players/client/main.lua
-- Oyuncu Sistemi: Client Tarafı
local Core = exports['is4-core']:GetCore()

-- ═══════════════════════════════════════════
-- SPAWN SİSTEMİ
-- ═══════════════════════════════════════════
RegisterNetEvent("is4-players:spawnCharacter", function(spawnCoords)
    local playerPed = PlayerPedId()

    -- Ekranı karat
    DoScreenFadeOut(500)
    Wait(1000)

    -- Spawn noktasına ışınla
    if spawnCoords then
        SetEntityCoords(playerPed, spawnCoords.x, spawnCoords.y, spawnCoords.z, false, false, false, true)
        if spawnCoords.w then
            SetEntityHeading(playerPed, spawnCoords.w)
        end
    end

    -- Canlanma süresi (invincibility)
    local invTimer = IS4.Players.All.SpawnSettings.SpawnInvincibilityTimer or 5000
    SetPlayerInvincible(PlayerId(), true)

    DoScreenFadeIn(1000)
    Wait(invTimer)

    SetPlayerInvincible(PlayerId(), false)
    exports['is4-core']:SendNotification(-1, "🎮 Hoş geldin! Karakterin yüklendi.")
end)

-- ═══════════════════════════════════════════
-- İHTİYAÇ SİSTEMİ (AÇLIK / SUSUZLUK)
-- ═══════════════════════════════════════════
local playerStatus = {
    hunger = 100,
    thirst = 100,
    stress = 0,
    stamina = 100,
}

Citizen.CreateThread(function()
    while true do
        local decayInterval = (IS4.Players.All.NeedsSystem.DecayInterval or 60) * 1000
        Wait(decayInterval)

        local playerPed = PlayerPedId()
        if not IsEntityDead(playerPed) then
            -- Açlık düşür
            playerStatus.hunger = math.max(0, playerStatus.hunger - (IS4.Players.All.NeedsSystem.HungerDecayRate or 0.5))

            -- Susuzluk düşür
            playerStatus.thirst = math.max(0, playerStatus.thirst - (IS4.Players.All.NeedsSystem.ThirstDecayRate or 0.7))

            -- Stres doğal azalma
            playerStatus.stress = math.max(0, playerStatus.stress - (IS4.Players.All.NeedsSystem.StressDecayRate or 0.2))

            -- Dayanıklılık regen (koşmuyorsa)
            if not IsPedRunning(playerPed) and not IsPedSprinting(playerPed) then
                playerStatus.stamina = math.min(100, playerStatus.stamina + (IS4.Players.All.NeedsSystem.StaminaRegenRate or 1.0))
            end

            -- Düşük değerlerde hasar
            local dmgThreshold = IS4.Players.All.NeedsSystem.DamageThreshold or 10
            if playerStatus.hunger <= dmgThreshold then
                ApplyDamageToPed(playerPed, 2, false)
                exports['is4-core']:SendNotification(-1, "⚠️ Açlıktan ölüyorsun!")
            end

            if playerStatus.thirst <= dmgThreshold then
                ApplyDamageToPed(playerPed, 3, false)
                exports['is4-core']:SendNotification(-1, "⚠️ Susuzluktan ölüyorsun!")
            end

            -- Status'ü sunucuya bildir (auto-save)
            TriggerServerEvent("is4-players:syncStatus", playerStatus)
        end
    end
end)

-- ═══════════════════════════════════════════
-- İHTİYAÇ GÜNCELLEMELERİ (ITEM KULLANINDAN)
-- ═══════════════════════════════════════════
RegisterNetEvent("is4-items:useFood", function(itemName, hungerRestore)
    playerStatus.hunger = math.min(100, playerStatus.hunger + (hungerRestore or 0))
end)

RegisterNetEvent("is4-items:useDrink", function(itemName, thirstRestore, stressRestore)
    playerStatus.thirst = math.min(100, playerStatus.thirst + (thirstRestore or 0))
    if stressRestore then
        playerStatus.stress = math.max(0, playerStatus.stress + stressRestore) -- stressRestore negatif olabilir
    end
end)

-- ═══════════════════════════════════════════
-- HUD STATUS EXPORT
-- ═══════════════════════════════════════════
exports("GetPlayerStatus", function()
    return playerStatus
end)

-- ═══════════════════════════════════════════
-- KARAKTER SEÇİM EKRANI
-- ═══════════════════════════════════════════
RegisterNetEvent("is4-players:showCharacterSelection", function(characters)
    -- Basit karakter seçim gösterimi (gerçek UI modülü ile değiştirilecek)
    if #characters == 0 then
        exports['is4-core']:SendNotification(-1, "📋 Henüz karakter oluşturmamışsın.")
        return
    end

    for i, char in ipairs(characters) do
        local genderLabel = char.gender == 0 and "Erkek" or "Kadın"
        exports['is4-core']:SendNotification(-1, ("%d. %s %s (%s) — %s"):format(i, char.firstname, char.lastname, genderLabel, char.dob))
    end
    exports['is4-core']:SendNotification(-1, "/selectchar [numara] ile karakter seç.")
end)

-- ═══════════════════════════════════════════
-- STRES SİSTEMİ
-- ═══════════════════════════════════════════
Citizen.CreateThread(function()
    while true do
        Wait(5000)
        local playerPed = PlayerPedId()

        -- Ateş altındaysa stres artar
        if IsPedBeingStunned(playerPed, 0) or IsEntityOnFire(playerPed) then
            playerStatus.stress = math.min(100, playerStatus.stress + 5)
        end

        -- Araçla hız yapıyorsa stres artar
        if IsPedInAnyVehicle(playerPed, false) then
            local vehicle = GetVehiclePedIsIn(playerPed, false)
            local speed = GetEntitySpeed(vehicle) * 3.6
            if speed > 150 then
                playerStatus.stress = math.min(100, playerStatus.stress + 2)
            end
        end

        -- Yüksek stres efektleri
        if playerStatus.stress > 80 then
            -- Ekran titremesin ama oyuncuyu uyar
            if math.random(1, 10) == 1 then
                exports['is4-core']:SendNotification(-1, "😰 Stresin çok yüksek! Dinlenmen lazım.")
            end
        end
    end
end)
