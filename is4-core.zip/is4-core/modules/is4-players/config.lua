Config = {}

Config.MaxCharacters = 4
Config.StartingCoords = vector4(-1036.96, -2740.06, 13.78, 330.0) -- LSIA
Config.SpawnInvincibilityTimer = 5000 -- ms
