# is4-players Tutorial

How to use is4-players module.
