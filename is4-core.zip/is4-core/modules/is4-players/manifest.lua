return {
    name = "is4-players",
    version = "1.0.0",
    dependencies = {}, -- Core injects datastore automatically, but we don't rely on other modules
    client = true,
    server = true
}
