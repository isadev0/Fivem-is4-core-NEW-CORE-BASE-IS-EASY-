-- is4-players: Server Side
local Core = exports['is4-core']:GetCore()

-- ─────────────────────────────────────────────────────────
-- OYUNCU BAĞLANTISI: DB'de yoksa oluştur, varsa yükle
-- ─────────────────────────────────────────────────────────
AddEventHandler("playerConnecting", function(name, setKickReason, deferrals)
    local src = source
    deferrals.defer()

    local identifiers = GetPlayerIdentifiers(src)
    local license, steam = nil, nil

    for _, v in pairs(identifiers) do
        if string.find(v, "license:") then license = v end
        if string.find(v, "steam:")   then steam   = v end
    end

    if not license then
        deferrals.done("Geçerli bir lisans kimliği bulunamadı.")
        return
    end

    deferrals.update("Karakterin yükleniyor...")

    -- İlk bağlanışta kayıt oluştur
    IS4.Datastore.EnsurePlayer(license, steam or license, function()
        deferrals.done()
    end)
end)

-- ─────────────────────────────────────────────────────────
-- KARAKTER SEÇİM EKRANI: Oyuncunun karakterlerini getir
-- ─────────────────────────────────────────────────────────
Core.Network.RegisterServerCallback('is4-players:fetchCharacters', function(source)
    local identifiers = GetPlayerIdentifiers(source)
    local license = nil
    for _, v in pairs(identifiers) do
        if string.find(v, "license:") then
            license = v
            break
        end
    end

    if not license then return end

    -- DB'den bu lisansa ait karakterleri çek
    IS4.Datastore.FetchAll(
        "SELECT id, firstname, lastname, dob, gender, last_seen FROM characters WHERE license = ? ORDER BY id ASC",
        {license},
        function(rows)
            local characters = rows or {}
            TriggerClientEvent('is4-players:showCharacterSelection', source, characters)
        end
    )
end)

-- ─────────────────────────────────────────────────────────
-- KARAKTER SEÇİMİ: Seçilen karakteri yükle
-- ─────────────────────────────────────────────────────────
RegisterNetEvent('is4-players:selectCharacter', function(charId)
    local src = source

    local identifiers = GetPlayerIdentifiers(src)
    local license = nil
    for _, v in pairs(identifiers) do
        if string.find(v, "license:") then license = v break end
    end

    if not license then
        Core.Logger.Error("[is4-players] Lisans bulunamadı: " .. tostring(src))
        return
    end

    -- Karakteri ve oyuncu datasını birlikte çek
    MySQL.Async.fetchSingle(
        [[SELECT c.id, c.firstname, c.lastname, c.dob, c.gender, c.bloodtype, c.fingerprint,
                 p.money, p.job, p.job_grade, p.inventory, p.metadata
          FROM characters c
          JOIN players p ON p.identifier = CONCAT(c.license, ':char:', c.id)
          WHERE c.id = ? AND c.license = ? LIMIT 1]],
        {charId, license},
        function(row)
            if not row then
                Core.Logger.Error(("[is4-players] Karakter bulunamadı: id=%s license=%s"):format(charId, license))
                TriggerClientEvent('is4-players:characterLoadFailed', src)
                return
            end

            local fullIdentifier = ("%s:char:%d"):format(license, charId)

            local dbData = {
                money     = (row.money     and json.decode(row.money))     or { cash = 500, bank = 5000 },
                job       = row.job       or "unemployed",
                job_grade = row.job_grade or 0,
                inventory = (row.inventory and json.decode(row.inventory)) or {},
                metadata  = (row.metadata  and json.decode(row.metadata)) or {
                    firstname   = row.firstname,
                    lastname    = row.lastname,
                    dob         = row.dob,
                    gender      = row.gender,
                    bloodtype   = row.bloodtype  or "A+",
                    fingerprint = row.fingerprint or "UNKNOWN",
                },
            }

            -- PlayerManager'a kaydet (RAM Cache)
            local playerFrame = Core.PlayerManager.CreatePlayer(src, fullIdentifier, dbData)

            if playerFrame then
                Core.Logger.Info(("[is4-players] Karakter %s yüklendi, kaynak: %s"):format(fullIdentifier, src))
                -- Son oturum tarihini güncelle
                MySQL.Async.execute(
                    "UPDATE characters SET last_seen = NOW() WHERE id = ?",
                    {charId}
                )
                TriggerClientEvent('is4-players:spawnCharacter', src, Config.StartingCoords)
            else
                Core.Logger.Error(("[is4-players] RAM Cache oluşturulamadı: %s"):format(fullIdentifier))
            end
        end
    )
end)

-- ─────────────────────────────────────────────────────────
-- YENİ KARAKTER OLUŞTUR
-- ─────────────────────────────────────────────────────────
RegisterNetEvent('is4-players:createCharacter', function(charData)
    local src = source

    -- Güvenlik: gerekli alanlar var mı?
    if not charData or not charData.firstname or not charData.lastname or not charData.dob then
        TriggerClientEvent('is4-players:characterCreateFailed', src, "Eksik karakter bilgisi.")
        return
    end

    local identifiers = GetPlayerIdentifiers(src)
    local license = nil
    for _, v in pairs(identifiers) do
        if string.find(v, "license:") then license = v break end
    end

    if not license then return end

    -- Karakter sınırı kontrolü (max 2)
    MySQL.Async.fetchSingle(
        "SELECT COUNT(*) as cnt FROM characters WHERE license = ?",
        {license},
        function(row)
            if row and row.cnt >= 2 then
                TriggerClientEvent('is4-players:characterCreateFailed', src, "Maksimum karakter sayısına ulaştın (2).")
                return
            end

            -- Yeni karakter ekle
            MySQL.Async.execute(
                [[INSERT INTO characters (license, firstname, lastname, dob, gender, bloodtype, fingerprint, last_seen)
                  VALUES (?, ?, ?, ?, ?, ?, ?, NOW())]],
                {
                    license,
                    charData.firstname,
                    charData.lastname,
                    charData.dob,
                    charData.gender or 0,
                    charData.bloodtype or "A+",
                    ("FP-%s-%d"):format(string.sub(license, -6), os.time()),
                },
                function(insertId)
                    if not insertId then
                        TriggerClientEvent('is4-players:characterCreateFailed', src, "Veritabanı hatası.")
                        return
                    end

                    local fullIdentifier = ("%s:char:%d"):format(license, insertId)
                    local defaultMoney   = json.encode({ cash = IS4.Config.Economy.StartingCash, bank = IS4.Config.Economy.StartingBank })

                    -- players tablosuna da kayıt aç
                    MySQL.Async.execute(
                        [[INSERT INTO players (identifier, license, money, job, job_grade, inventory, metadata, status, last_seen)
                          VALUES (?, ?, ?, 'unemployed', 0, '{}', '{}', 0, NOW())]],
                        {fullIdentifier, license, defaultMoney},
                        function()
                            Core.Logger.Info(("[is4-players] Yeni karakter oluşturuldu: %s"):format(fullIdentifier))
                            TriggerClientEvent('is4-players:characterCreated', src, insertId)
                        end
                    )
                end
            )
        end
    )
end)

-- ─────────────────────────────────────────────────────────
-- KARAKTER SİL
-- ─────────────────────────────────────────────────────────
RegisterNetEvent('is4-players:deleteCharacter', function(charId)
    local src = source

    local identifiers = GetPlayerIdentifiers(src)
    local license = nil
    for _, v in pairs(identifiers) do
        if string.find(v, "license:") then license = v break end
    end

    if not license then return end

    -- Sadece kendi karakterini silebilir
    MySQL.Async.execute(
        "DELETE FROM characters WHERE id = ? AND license = ?",
        {charId, license},
        function(rows)
            if rows and rows > 0 then
                local fullIdentifier = ("%s:char:%d"):format(license, charId)
                MySQL.Async.execute("DELETE FROM players WHERE identifier = ?", {fullIdentifier})
                Core.Logger.Info(("[is4-players] Karakter silindi: %s"):format(fullIdentifier))
                TriggerClientEvent('is4-players:characterDeleted', src, charId)
            end
        end
    )
end)
