-- is4-policejob: Client Main
local Core = exports['is4-core']:GetCore()

local isCuffed = false
local isEscorted = false
local escortBy = nil
local jailTimer = 0

-- Cuffing state
RegisterNetEvent('is4-police:setCuffed', function(state)
    isCuffed = state
    local ped = PlayerPedId()
    
    if isCuffed then
        RequestAnimDict("mp_arresting")
        while not HasAnimDictLoaded("mp_arresting") do Wait(10) end
        TaskPlayAnim(ped, "mp_arresting", "idle", 8.0, -8.0, -1, 49, 0, false, false, false)
        SetEnableHandcuffs(ped, true)
        DisablePlayerFiring(ped, true)
    else
        ClearPedTasks(ped)
        SetEnableHandcuffs(ped, false)
        DisablePlayerFiring(ped, false)
    end
end)

-- Escort state
RegisterNetEvent('is4-police:startEscort', function(copSource)
    isEscorted = true
    escortBy = GetPlayerFromServerId(copSource)
    
    Citizen.CreateThread(function()
        while isEscorted do
            Wait(0)
            local copPed = GetPlayerPed(escortBy)
            if copPed and DoesEntityExist(copPed) then
                local copCoords = GetEntityCoords(copPed)
                local heading = GetEntityHeading(copPed)
                local offset = GetOffsetFromEntityInWorldCoords(copPed, 0.0, 0.5, 0.0)
                SetEntityCoords(PlayerPedId(), offset.x, offset.y, offset.z)
            else
                isEscorted = false
            end
        end
    end)
end)

-- Force into vehicle
RegisterNetEvent('is4-police:forceIntoVehicle', function()
    local ped = PlayerPedId()
    local coords = GetEntityCoords(ped)
    local vehicle = GetClosestVehicle(coords.x, coords.y, coords.z, 5.0, 0, 71)
    
    if vehicle ~= 0 then
        local seat = 1 -- back left
        if not IsVehicleSeatFree(vehicle, seat) then seat = 2 end -- back right
        TaskWarpPedIntoVehicle(ped, vehicle, seat)
        isEscorted = false
    end
end)

-- Jail system
RegisterNetEvent('is4-police:sendToJail', function(jailCoords, timeMinutes)
    local ped = PlayerPedId()
    
    isCuffed = false
    ClearPedTasks(ped)
    SetEnableHandcuffs(ped, false)
    
    SetEntityCoords(ped, jailCoords.x, jailCoords.y, jailCoords.z)
    FreezeEntityPosition(ped, true)
    
    jailTimer = timeMinutes * 60 -- seconds
    
    Citizen.CreateThread(function()
        while jailTimer > 0 do
            Wait(1000)
            jailTimer = jailTimer - 1
        end
        
        FreezeEntityPosition(ped, false)
        SetEntityCoords(ped, Config.Police.DutyLocations[1].x, Config.Police.DutyLocations[1].y, Config.Police.DutyLocations[1].z)
        TriggerEvent('is4-core:notify', {text = "You have been released from jail.", type = "success"})
    end)
end)

-- Duty location blip
Core.Events.on("is4-core:clientSpawned", function()
    for _, loc in ipairs(Config.Police.DutyLocations) do
        local blip = AddBlipForCoord(loc.x, loc.y, loc.z)
        SetBlipSprite(blip, 60)
        SetBlipScale(blip, 0.9)
        SetBlipColour(blip, 29)
        SetBlipAsShortRange(blip, true)
        BeginTextCommandSetBlipName("STRING")
        AddTextComponentString("Police Department")
        EndTextCommandSetBlipName(blip)
    end
end)
