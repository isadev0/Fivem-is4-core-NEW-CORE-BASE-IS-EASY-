Config = {}

Config.Police = {
    JobName = "police",
    Ranks = {"Cadet", "Officer", "Sergeant", "Lieutenant", "Captain", "Chief"},
    DutyLocations = {
        vector3(440.08, -981.15, 30.69) -- MRPD
    }
}

Config.Armory = {
    Location = vector3(452.59, -980.01, 30.69),
    Items = {
        {name = "WEAPON_PISTOL", label = "Service Pistol", price = 0, rank = 1},
        {name = "WEAPON_STUNGUN", label = "Taser", price = 0, rank = 1},
        {name = "WEAPON_PUMPSHOTGUN", label = "Shotgun", price = 0, rank = 3},
        {name = "WEAPON_CARBINERIFLE", label = "Carbine Rifle", price = 0, rank = 4},
        {name = "kelepce", label = "Kelepçe", price = 0, rank = 1},
        {name = "armor", label = "Body Armor", price = 0, rank = 1}
    }
}

Config.Jail = {
    Location = vector3(1681.39, 2512.75, 45.56), -- Bolingbroke
    MinTime = 5,  -- minutes
    MaxTime = 60  -- minutes
}
