-- is4-policejob: Server Main
local Core = exports['is4-core']:GetCore()

local OnDuty = {}
local CuffedPlayers = {} -- CuffedPlayers[targetId] = copId

-- Toggle Duty
Core.Network.RegisterServerCallback('is4-police:toggleDuty', function(src)
    local player = Core.PlayerManager.GetPlayer(src)
    if not player or player.get("job") ~= Config.Police.JobName then return end
    
    OnDuty[src] = not OnDuty[src]
    local status = OnDuty[src] and "ON" or "OFF"
    TriggerClientEvent('is4-core:notify', src, {text = ("Duty: %s"):format(status), type = "info"})
    Core.Events.emit("is4-police:dutyToggled", {source = src, onDuty = OnDuty[src]})
end)

-- Handcuff a player
Core.Network.RegisterServerCallback('is4-police:cuff', function(src, targetId)
    if not OnDuty[src] then
        TriggerClientEvent('is4-core:notify', src, {text = "You must be on duty!", type = "error"})
        return
    end
    
    local target = Core.PlayerManager.GetPlayer(targetId)
    if not target then return end
    
    CuffedPlayers[targetId] = src
    TriggerClientEvent('is4-police:setCuffed', targetId, true)
    TriggerClientEvent('is4-core:notify', src, {text = ("Player %s cuffed."):format(targetId), type = "success"})
    TriggerClientEvent('is4-core:notify', targetId, {text = "You have been cuffed!", type = "warning"})
end)

-- Uncuff a player
Core.Network.RegisterServerCallback('is4-police:uncuff', function(src, targetId)
    if CuffedPlayers[targetId] then
        CuffedPlayers[targetId] = nil
        TriggerClientEvent('is4-police:setCuffed', targetId, false)
        TriggerClientEvent('is4-core:notify', targetId, {text = "You have been uncuffed.", type = "info"})
    end
end)

-- Escort (drag) a player
Core.Network.RegisterServerCallback('is4-police:escort', function(src, targetId)
    if not OnDuty[src] then return end
    TriggerClientEvent('is4-police:startEscort', targetId, src)
end)

-- Put in vehicle
Core.Network.RegisterServerCallback('is4-police:putInVehicle', function(src, targetId)
    if not CuffedPlayers[targetId] then return end
    TriggerClientEvent('is4-police:forceIntoVehicle', targetId)
end)

-- Jail a player
Core.Network.RegisterServerCallback('is4-police:jail', function(src, targetId, timeMinutes)
    if not OnDuty[src] then return end
    
    timeMinutes = math.min(math.max(timeMinutes, Config.Jail.MinTime), Config.Jail.MaxTime)
    
    CuffedPlayers[targetId] = nil
    TriggerClientEvent('is4-police:sendToJail', targetId, Config.Jail.Location, timeMinutes)
    TriggerClientEvent('is4-core:notify', targetId, {text = ("Jailed for %s minutes."):format(timeMinutes), type = "error"})
    Core.Events.emit("is4-police:playerJailed", {source = targetId, officer = src, time = timeMinutes})
end)

-- Fine a player
Core.Network.RegisterServerCallback('is4-police:fine', function(src, targetId, amount)
    if not OnDuty[src] then return end
    
    local target = Core.PlayerManager.GetPlayer(targetId)
    if target then
        target.removeMoney("bank", amount)
        TriggerClientEvent('is4-core:notify', targetId, {text = ("You were fined $%s"):format(amount), type = "error"})
        TriggerClientEvent('is4-core:notify', src, {text = ("Fined player %s for $%s"):format(targetId, amount), type = "success"})
    end
end)

-- Clean up on disconnect
AddEventHandler("playerDropped", function()
    OnDuty[source] = nil
    CuffedPlayers[source] = nil
end)
