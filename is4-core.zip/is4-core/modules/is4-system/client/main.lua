-- is4-system: Client Main
local Core = exports['is4-core']:GetCore()

-- Time Sync
RegisterNetEvent('is4-system:syncTime', function(hour, minute)
    NetworkOverrideClockTime(hour, minute, 0)
end)

-- Weather Sync
RegisterNetEvent('is4-system:syncWeather', function(weather)
    SetWeatherTypeNowPersist(weather)
    SetWeatherTypeNow(weather)
    SetOverrideWeather(weather)
end)

-- Freeze time client-side so it doesn't auto-advance
Citizen.CreateThread(function()
    while true do
        Wait(1000)
        local h, m = GetClockHours(), GetClockMinutes()
        NetworkOverrideClockTime(h, m, 0)
    end
end)
