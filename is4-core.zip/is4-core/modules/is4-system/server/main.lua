-- is4-system: Server Main
local Core = exports['is4-core']:GetCore()

local ServerTime = {hour = 12, minute = 0}
local ServerWeather = "CLEAR"

-- Weather/Time sync to all players every 5 minutes
Citizen.CreateThread(function()
    while true do
        Wait(300000) -- 5 min
        ServerTime.minute = ServerTime.minute + 10
        if ServerTime.minute >= 60 then
            ServerTime.minute = 0
            ServerTime.hour = ServerTime.hour + 1
            if ServerTime.hour >= 24 then ServerTime.hour = 0 end
        end
        TriggerClientEvent('is4-system:syncTime', -1, ServerTime.hour, ServerTime.minute)
    end
end)

-- Admin: Set Weather
RegisterCommand("setweather", function(src, args)
    if src > 0 then
        if not Core.Permissions.HasPermission(src, "admin.weather") then
            TriggerClientEvent('is4-core:notify', src, {text = "No permission!", type = "error"})
            return
        end
    end
    
    ServerWeather = args[1] or "CLEAR"
    TriggerClientEvent('is4-system:syncWeather', -1, ServerWeather)
    Core.Logger.Info(("[is4-system] Weather set to %s"):format(ServerWeather))
end, false)

-- Admin: Set Time
RegisterCommand("settime", function(src, args)
    if src > 0 and not Core.Permissions.HasPermission(src, "admin.time") then return end
    
    ServerTime.hour = tonumber(args[1]) or 12
    ServerTime.minute = tonumber(args[2]) or 0
    TriggerClientEvent('is4-system:syncTime', -1, ServerTime.hour, ServerTime.minute)
end, false)

-- Admin: Kick
RegisterCommand("kick", function(src, args)
    if src > 0 and not Core.Permissions.HasPermission(src, "admin.kick") then return end
    local target = tonumber(args[1])
    if target then
        DropPlayer(target, args[2] or "You were kicked by an administrator.")
    end
end, false)

-- Admin: Announce
RegisterCommand("announce", function(src, args)
    if src > 0 and not Core.Permissions.HasPermission(src, "admin.announce") then return end
    local msg = table.concat(args, " ")
    TriggerClientEvent('is4-core:notify', -1, {text = "📢 " .. msg, type = "warning"})
end, false)

-- Sync on player join
Core.Events.on('is4-core:playerLoaded', function(data)
    TriggerClientEvent('is4-system:syncTime', data.source, ServerTime.hour, ServerTime.minute)
    TriggerClientEvent('is4-system:syncWeather', data.source, ServerWeather)
end)
