-- modules/items/client/main.lua
-- Item Sistemi: Client Tarafı
local Core = exports['is4-core']:GetCore()

-- ═══════════════════════════════════════════
-- YİYECEK KULLANIM ANİMASYONU
-- ═══════════════════════════════════════════
RegisterNetEvent("is4-items:useFood", function(itemName, hungerRestore)
    local playerPed = PlayerPedId()
    local itemData = IS4.Items.All[itemName]

    -- Yeme animasyonu
    RequestAnimDict("mp_player_inteat@burger")
    while not HasAnimDictLoaded("mp_player_inteat@burger") do Wait(10) end

    TaskPlayAnim(playerPed, "mp_player_inteat@burger", "mp_player_int_eat_burger", 8.0, -8.0, 5000, 49, 0, false, false, false)

    -- Progress bar simülasyonu
    Wait(5000)
    ClearPedTasks(playerPed)

    exports['is4-core']:SendNotification(-1, ("%s yedin. (+%d açlık)"):format(itemData and itemData.label or itemName, hungerRestore))
end)

-- ═══════════════════════════════════════════
-- İÇECEK KULLANIM ANİMASYONU
-- ═══════════════════════════════════════════
RegisterNetEvent("is4-items:useDrink", function(itemName, thirstRestore, stressRestore)
    local playerPed = PlayerPedId()
    local itemData = IS4.Items.All[itemName]

    RequestAnimDict("mp_player_intdrink")
    while not HasAnimDictLoaded("mp_player_intdrink") do Wait(10) end

    TaskPlayAnim(playerPed, "mp_player_intdrink", "loop_bottle", 8.0, -8.0, 4000, 49, 0, false, false, false)

    Wait(4000)
    ClearPedTasks(playerPed)

    local msg = ("%s içtin. (+%d susuzluk)"):format(itemData and itemData.label or itemName, thirstRestore)
    if stressRestore and stressRestore ~= 0 then
        msg = msg .. (" (Stres: %d)"):format(stressRestore)
    end
    exports['is4-core']:SendNotification(-1, msg)
end)

-- ═══════════════════════════════════════════
-- TIBBİ MALZEME ANİMASYONU
-- ═══════════════════════════════════════════
RegisterNetEvent("is4-items:useMedical", function(itemName, healAmount)
    local playerPed = PlayerPedId()
    local itemData = IS4.Items.All[itemName]

    RequestAnimDict("anim@heists@narcotics@funding@gang_idle")
    while not HasAnimDictLoaded("anim@heists@narcotics@funding@gang_idle") do Wait(10) end

    TaskPlayAnim(playerPed, "anim@heists@narcotics@funding@gang_idle", "epi_loop", 8.0, -8.0, 3000, 49, 0, false, false, false)

    Wait(3000)
    ClearPedTasks(playerPed)

    -- Can ekle
    local currentHealth = GetEntityHealth(playerPed)
    SetEntityHealth(playerPed, math.min(200, currentHealth + healAmount))

    exports['is4-core']:SendNotification(-1, ("%s kullanıldı. (+%d can)"):format(itemData and itemData.label or itemName, healAmount))
end)

-- ═══════════════════════════════════════════
-- ARMOR KULLANIMI
-- ═══════════════════════════════════════════
RegisterNetEvent("is4-items:useArmor", function(armorValue)
    local playerPed = PlayerPedId()
    SetPedArmour(playerPed, armorValue)
    exports['is4-core']:SendNotification(-1, ("Zırh giyildi. (+%d armor)"):format(armorValue))
end)

-- ═══════════════════════════════════════════
-- BELGE GÖSTERME (YAKIN OYUNCUYA)
-- ═══════════════════════════════════════════
RegisterNetEvent("is4-items:showDocument", function(docType, identity)
    local docLabels = {
        id_card = "KİMLİK KARTI",
        driver_license = "EHLİYET",
        weapon_license = "SİLAH RUHSATI",
    }

    local label = docLabels[docType] or "BELGE"
    local text = ("━━ %s ━━\nAd: %s %s\nDoğum: %s\nKan: %s"):format(
        label,
        identity.firstname or "?",
        identity.lastname or "?",
        identity.dob or "?",
        identity.bloodtype or "?"
    )

    exports['is4-core']:SendNotification(-1, text)
end)

-- ═══════════════════════════════════════════
-- ALET KULLANIMI
-- ═══════════════════════════════════════════
RegisterNetEvent("is4-items:useTool", function(itemName)
    local itemData = IS4.Items.All[itemName]
    if not itemData then return end

    exports['is4-core']:SendNotification(-1, ("%s kullanıldı."):format(itemData.label or itemName))
end)
