Config = {}

Config.Inventory = {
    MaxWeight = 50.0,
    DefaultSlots = 40,
    AllowTrading = true
}

Config.Items = {
    DefaultStackLimit = 100,
    DropDecayEnabled = true,
    DropDecayTimeout = 300, -- seconds
    DropModel = "prop_paper_bag_01"
}

-- Example item weights mapping for performance tracking
Config.ItemWeights = {
    ["apple"] = 0.2,
    ["water"] = 0.3,
    ["iron"] = 1.5
}
