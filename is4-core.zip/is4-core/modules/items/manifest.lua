return {
  name = "items",
  version = "1.0.0",
  dependencies = {},
  client = true,
  server = true
}
