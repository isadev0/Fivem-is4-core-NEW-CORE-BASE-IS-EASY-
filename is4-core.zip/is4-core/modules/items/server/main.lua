-- modules/items/server/main.lua
-- Item Sistemi: Server Tarafı
local Core = exports['is4-core']:GetCore()

-- ═══════════════════════════════════════════
-- TÜM İTEMLERİ FRAMEWORK'E KAYDET
-- ═══════════════════════════════════════════
Citizen.CreateThread(function()
    Wait(1000) -- Framework'ün yüklenmesini bekle

    local count = 0
    for itemName, itemData in pairs(IS4.Items.All) do
        exports['is4-core']:CreateItem(itemName, itemData)
        count = count + 1
    end
    IS4.Logger.Info(("[Items Module] %d item başarıyla kaydedildi."):format(count))
end)

-- ═══════════════════════════════════════════
-- KULLANILABİLİR ITEM HANDLERLARI
-- ═══════════════════════════════════════════

--- Yiyecek kullanma
local function UseFood(source, itemName)
    local itemData = IS4.Items.All[itemName]
    if not itemData then return end

    local success = exports['is4-core']:RemoveItem(source, itemName, 1)
    if success then
        local hungerRestore = itemData.hunger or 0
        exports['is4-core']:SetPlayerMetadata(source, "hunger_restore", hungerRestore)
        TriggerClientEvent("is4-items:useFood", source, itemName, hungerRestore)
        IS4.Logger.Info(("[Items] %s yiyecek kullandı: %s (+%d açlık)"):format(source, itemName, hungerRestore))
    end
end

--- İçecek kullanma
local function UseDrink(source, itemName)
    local itemData = IS4.Items.All[itemName]
    if not itemData then return end

    local success = exports['is4-core']:RemoveItem(source, itemName, 1)
    if success then
        local thirstRestore = itemData.thirst or 0
        local stressRestore = itemData.stress or 0
        TriggerClientEvent("is4-items:useDrink", source, itemName, thirstRestore, stressRestore)
        IS4.Logger.Info(("[Items] %s içecek kullandı: %s (+%d susuzluk)"):format(source, itemName, thirstRestore))
    end
end

--- Tıbbi malzeme kullanma
local function UseMedical(source, itemName)
    local itemData = IS4.Items.All[itemName]
    if not itemData then return end

    local success = exports['is4-core']:RemoveItem(source, itemName, 1)
    if success then
        local healAmount = itemData.heal or 0
        TriggerClientEvent("is4-items:useMedical", source, itemName, healAmount)
        IS4.Logger.Info(("[Items] %s tıbbi malzeme kullandı: %s (+%d can)"):format(source, itemName, healAmount))
    end
end

--- Armor kullanma
local function UseArmor(source, itemName)
    local itemData = IS4.Items.All[itemName]
    if not itemData then return end

    local success = exports['is4-core']:RemoveItem(source, itemName, 1)
    if success then
        local armorValue = itemData.armorValue or 100
        TriggerClientEvent("is4-items:useArmor", source, armorValue)
        IS4.Logger.Info(("[Items] %s zırh kuşandı: +%d armor"):format(source, armorValue))
    end
end

--- Kimlik gösterme
local function UseDocument(source, itemName)
    local identity = exports['is4-core']:GetIdentity(source)
    if identity then
        -- Yakındaki oyunculara göster
        local playerPed = GetPlayerPed(source)
        local coords = GetEntityCoords(playerPed)

        local players = GetPlayers()
        for _, playerId in ipairs(players) do
            local targetPed = GetPlayerPed(playerId)
            local targetCoords = GetEntityCoords(targetPed)
            local distance = #(coords - targetCoords)

            if distance < 5.0 and tonumber(playerId) ~= source then
                TriggerClientEvent("is4-items:showDocument", tonumber(playerId), itemName, identity)
            end
        end
        IS4.Logger.Info(("[Items] %s belge gösterdi: %s"):format(source, itemName))
    end
end

-- ═══════════════════════════════════════════
-- ITEM KULLANIM EVENT'İ
-- ═══════════════════════════════════════════
RegisterNetEvent("is4-items:useItem", function(itemName)
    local src = source
    local itemData = IS4.Items.All[itemName]
    if not itemData or not itemData.usable then return end

    local itemType = itemData.type

    if itemType == "food" then
        UseFood(src, itemName)
    elseif itemType == "drink" then
        UseDrink(src, itemName)
    elseif itemType == "medical" then
        UseMedical(src, itemName)
    elseif itemType == "armor" then
        UseArmor(src, itemName)
    elseif itemType == "document" then
        UseDocument(src, itemName)
    elseif itemType == "tool" then
        TriggerClientEvent("is4-items:useTool", src, itemName)
    else
        IS4.Logger.Info(("[Items] %s item kullandı: %s (özel handler yok)"):format(src, itemName))
    end
end)
