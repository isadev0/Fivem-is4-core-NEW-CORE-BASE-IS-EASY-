Config = {}

Config.JobRules = {
    MaxJobsPerPlayer = 1,
    SalaryIntervalMinutes = 30,
    JobCooldownMinutes = 10,
    AFKKickTimeMinutes = 20,
    RankSystemEnabled = true
}

Config.Management = {
    RequireBossApproval = true, -- Boss must approve employment
    AllowOffDuty = true
}
