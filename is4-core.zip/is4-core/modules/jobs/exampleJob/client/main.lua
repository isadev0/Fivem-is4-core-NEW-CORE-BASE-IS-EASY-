-- client/main.lua (exampleJob)
-- Any local client loops (e.g., drawing markers or UI updates for the test job)
local core = exports['is4-core']:GetCore()

-- Subscribe to the framework's Pub/Sub system internally using core.Events (or RegisterNetEvent wrappers)
RegisterNetEvent("is4-core:playerUpdate:job")
AddEventHandler("is4-core:playerUpdate:job", function(source, newJob, oldJob)
    if newJob == Config.JobName then
        print(("[TestJob] Client detected job change to %s!"):format(newJob))
        -- In a real module, you'd spawn job markers here
    end
end)
