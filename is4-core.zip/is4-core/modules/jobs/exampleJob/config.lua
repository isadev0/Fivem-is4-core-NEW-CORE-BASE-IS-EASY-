Config = {}
Config.JobName = "testJob"
Config.MaxPlayers = 10
Config.StartingBonus = 50
Config.RewardItem = "water"
Config.RewardAmount = 2
