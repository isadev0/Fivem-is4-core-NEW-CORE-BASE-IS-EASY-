Data = {}
Data.Ranks = {
    [1] = { name = "Çaylak", salary = 1000 },
    [2] = { name = "Uzman", salary = 2000 },
    [3] = { name = "Şef", salary = 3500 }
}
