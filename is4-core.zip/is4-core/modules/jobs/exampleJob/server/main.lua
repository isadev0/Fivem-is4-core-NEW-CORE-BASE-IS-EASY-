-- server/main.lua (exampleJob)

RegisterModule("exampleJob", {
    name = "exampleJob",
    version = "2.0",
    
    events = {
        onPlayerStart = function(source)
            local player = exports['is4-core']:GetPlayer(source)
            if player then
                exports['is4-core']:AddMoney(source, Config.StartingBonus)
                exports['is4-core']:SendNotification(source, ("İşe başladın! $%s bonus kazandın."):format(Config.StartingBonus))
            end
        end,
        
        onPlayerFinish = function(source)
            local player = exports['is4-core']:GetPlayer(source)
            if player then
                exports['is4-core']:GiveItem(source, Config.RewardItem, Config.RewardAmount)
                exports['is4-core']:SendNotification(source, ("İşi bitirdin! %sx %s kazandın."):format(Config.RewardAmount, Config.RewardItem))
            end
        end
    }
})

-- We register the jobs through the API so other scripts can interact with it
-- We use Data.Ranks fetched from the /data/ package.
exports['is4-core']:CreateJob(Config.JobName, {
    label = "Test İşi",
    ranks = Data.Ranks
})

-- Mock Command
RegisterCommand("testjob", function(source, args)
    local action = args[1]
    local mod = exports['is4-core']:GetCore().Modules["exampleJob"]
    
    if action == "start" then
        mod.events.onPlayerStart(source)
    elseif action == "finish" then
        mod.events.onPlayerFinish(source)
    else
        exports['is4-core']:SendNotification(source, "Geçersiz komut. Kullanım: /testjob start|finish")
    end
end, false)
