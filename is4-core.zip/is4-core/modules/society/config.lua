Config = {}

Config.Members = {
    MaxCapacity = 20,
    HierarchyEnabled = true,
    UpgradeLevels = 5
}

Config.Financials = {
    SharedAccountEnabled = true,
    TaxContributionRate = 0.1 -- 10% of member income goes to society
}

Config.Territory = {
    Enabled = true,
    WarSystemEnabled = true,
    RaidCooldownMinutes = 60
}
