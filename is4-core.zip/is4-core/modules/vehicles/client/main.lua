-- modules/vehicles/client/main.lua
-- Araç Sistemi: Client Tarafı
local Core = exports['is4-core']:GetCore()

-- ═══════════════════════════════════════════
-- GARAJDAN ARAÇ SPAWN
-- ═══════════════════════════════════════════
RegisterNetEvent("is4-vehicles:spawnVehicle", function(vehicleData)
    local playerPed = PlayerPedId()
    local coords = GetEntityCoords(playerPed)
    local heading = GetEntityHeading(playerPed)
    local modelHash = GetHashKey(vehicleData.model)

    RequestModel(modelHash)
    while not HasModelLoaded(modelHash) do Wait(10) end

    local vehicle = CreateVehicle(modelHash, coords.x, coords.y + 3.0, coords.z, heading, true, false)
    SetVehicleNumberPlateText(vehicle, vehicleData.plate or "IS4")

    -- Yakıt ve hasar ayarla
    if vehicleData.fuel then
        SetVehicleFuelLevel(vehicle, vehicleData.fuel + 0.0)
    end

    if vehicleData.damage and vehicleData.damage > 0 then
        SetVehicleEngineHealth(vehicle, 1000.0 - (vehicleData.damage * 10))
    end

    TaskWarpPedIntoVehicle(playerPed, vehicle, -1)
    SetModelAsNoLongerNeeded(modelHash)

    exports['is4-core']:SendNotification(-1, ("🚗 %s garajdan çıkarıldı."):format(vehicleData.model))
end)

-- ═══════════════════════════════════════════
-- GARAJ LİSTESİ
-- ═══════════════════════════════════════════
RegisterNetEvent("is4-vehicles:showGarageList", function(garageList)
    if #garageList == 0 then
        exports['is4-core']:SendNotification(-1, "🅿️ Garajınız boş.")
        return
    end

    for i, veh in ipairs(garageList) do
        local vehInfo = IS4.Vehicles.All[veh.model]
        local label = vehInfo and vehInfo.label or veh.model
        exports['is4-core']:SendNotification(-1, ("%d. %s [%s] — Yakıt: %d%%"):format(i, label, veh.plate, veh.fuel or 100))
    end
end)

-- ═══════════════════════════════════════════
-- ARAÇ DURUM TAKİBİ (YAKIT & HASAR)
-- ═══════════════════════════════════════════
Citizen.CreateThread(function()
    while true do
        Wait(10000) -- 10 saniyede bir kontrol
        local playerPed = PlayerPedId()

        if IsPedInAnyVehicle(playerPed, false) then
            local vehicle = GetVehiclePedIsIn(playerPed, false)

            -- Yakıt tüketimi (basit simülasyon)
            local currentFuel = GetVehicleFuelLevel(vehicle)
            if currentFuel > 0 then
                local speed = GetEntitySpeed(vehicle) * 3.6 -- km/h
                local consumption = speed > 0 and (speed * 0.001) or 0
                SetVehicleFuelLevel(vehicle, math.max(0, currentFuel - consumption))
            end

            -- Motor sağlığı kontrolü
            local engineHealth = GetVehicleEngineHealth(vehicle)
            if engineHealth < 100 then
                exports['is4-core']:SendNotification(-1, "⚠️ Motor kritik durumda!")
            end
        end
    end
end)

-- ═══════════════════════════════════════════
-- BİLDİRİMLER
-- ═══════════════════════════════════════════
RegisterNetEvent("is4-vehicles:notification", function(msg)
    exports['is4-core']:SendNotification(-1, msg)
end)

-- ═══════════════════════════════════════════
-- YARDIMCI FONKSİYONLAR
-- ═══════════════════════════════════════════
function ShowHelpNotification(text)
    BeginTextCommandDisplayHelp("STRING")
    AddTextComponentSubstringPlayerName(text)
    EndTextCommandDisplayHelp(0, false, true, -1)
end
