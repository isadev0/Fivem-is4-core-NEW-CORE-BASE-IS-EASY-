Config = {}

Config.Garages = {
    MaxCapacity = 5,
    SpawnCooldown = 60, -- seconds between spawning new vehicles
    ImpoundFee = 500,
    InsuranceEnabled = true 
}

Config.VehicleBehavior = {
    FuelSystem = true,
    DamageSystem = true,
    LockSystem = true,
    StolenAlerts = true, -- alerts police if stolen NPC veh is hotwired
    NPCTheftEnabled = true
}
