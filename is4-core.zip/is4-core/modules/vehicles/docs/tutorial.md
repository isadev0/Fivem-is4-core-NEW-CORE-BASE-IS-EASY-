# vehicles Tutorial

How to use vehicles module.
