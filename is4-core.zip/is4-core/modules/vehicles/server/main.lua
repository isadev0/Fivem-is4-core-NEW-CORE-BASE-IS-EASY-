-- modules/vehicles/server/main.lua
-- Araç Sistemi: Server Tarafı
local Core = exports['is4-core']:GetCore()

-- ═══════════════════════════════════════════
-- TÜM ARAÇLARI FRAMEWORK'E KAYDET
-- ═══════════════════════════════════════════
Citizen.CreateThread(function()
    Wait(1000)

    local count = 0
    for modelName, vehData in pairs(IS4.Vehicles.All) do
        exports['is4-core']:CreateVehicle(modelName, vehData)
        count = count + 1
    end
    IS4.Logger.Info(("[Vehicles Module] %d araç başarıyla kaydedildi."):format(count))
end)

-- ═══════════════════════════════════════════
-- GARAJ SİSTEMİ
-- ═══════════════════════════════════════════
local PlayerGarages = {} -- RAM cache: {[source] = { {model, plate, fuel, damage, coords} }}

--- Araç garajına park et
RegisterNetEvent("is4-vehicles:parkVehicle", function(vehicleData)
    local src = source
    if not PlayerGarages[src] then PlayerGarages[src] = {} end

    local maxCapacity = Config.Garages.MaxCapacity or 5
    if #PlayerGarages[src] >= maxCapacity then
        TriggerClientEvent("is4-vehicles:notification", src, "❌ Garaj dolu! Maksimum: " .. maxCapacity)
        return
    end

    table.insert(PlayerGarages[src], {
        model = vehicleData.model,
        plate = vehicleData.plate or "IS4-" .. math.random(1000, 9999),
        fuel = vehicleData.fuel or 100,
        damage = vehicleData.damage or 0,
        storedAt = os.time(),
    })

    TriggerClientEvent("is4-vehicles:notification", src, "✅ Araç garajına park edildi.")
    IS4.Logger.Info(("[Vehicles] Araç park edildi: %s → %s"):format(vehicleData.model, src))
end)

--- Garajdan araç çıkar
RegisterNetEvent("is4-vehicles:spawnFromGarage", function(index)
    local src = source
    if not PlayerGarages[src] or not PlayerGarages[src][index] then
        TriggerClientEvent("is4-vehicles:notification", src, "❌ Araç bulunamadı.")
        return
    end

    local vehicle = PlayerGarages[src][index]
    TriggerClientEvent("is4-vehicles:spawnVehicle", src, vehicle)
    table.remove(PlayerGarages[src], index)

    IS4.Logger.Info(("[Vehicles] Garajdan çıkarıldı: %s → %s"):format(vehicle.model, src))
end)

--- Garaj listesini göster
RegisterNetEvent("is4-vehicles:requestGarageList", function()
    local src = source
    local garage = PlayerGarages[src] or {}
    TriggerClientEvent("is4-vehicles:showGarageList", src, garage)
end)

-- ═══════════════════════════════════════════
-- ARAÇ SATIN ALMA
-- ═══════════════════════════════════════════
RegisterNetEvent("is4-vehicles:buyVehicle", function(model)
    local src = source
    local vehData = IS4.Vehicles.All[model]
    if not vehData then
        TriggerClientEvent("is4-vehicles:notification", src, "❌ Tanımsız araç.")
        return
    end

    -- Job kilidi kontrol
    if vehData.jobLocked then
        TriggerClientEvent("is4-vehicles:notification", src, "❌ Bu araç sadece iş aracıdır.")
        return
    end

    local price = vehData.price or 0
    local hasMoney = exports['is4-core']:HasMoney(src, "bank", price)

    if hasMoney then
        exports['is4-core']:RemoveMoney(src, "bank", price)

        if not PlayerGarages[src] then PlayerGarages[src] = {} end
        table.insert(PlayerGarages[src], {
            model = model,
            plate = "IS4-" .. math.random(1000, 9999),
            fuel = 100,
            damage = 0,
            storedAt = os.time(),
        })

        TriggerClientEvent("is4-vehicles:notification", src, ("✅ %s satın alındı! ($%s)"):format(vehData.label, price))
        IS4.Logger.Info(("[Vehicles] Araç satın alındı: %s → %s ($%d)"):format(model, src, price))
    else
        TriggerClientEvent("is4-vehicles:notification", src, ("❌ Yetersiz bakiye. Fiyat: $%s"):format(price))
    end
end)

-- ═══════════════════════════════════════════
-- OYUNCU DISCONNECT — GARAJ TEMİZLEME
-- ═══════════════════════════════════════════
AddEventHandler("playerDropped", function()
    local src = source
    -- Gerçek sistemde burada DB'ye kaydedilir
    PlayerGarages[src] = nil
end)
