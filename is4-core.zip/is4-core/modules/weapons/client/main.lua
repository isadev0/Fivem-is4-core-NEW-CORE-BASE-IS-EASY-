-- modules/weapons/client/main.lua
-- Silah Sistemi: Client Tarafı
local Core = exports['is4-core']:GetCore()

-- ═══════════════════════════════════════════
-- SİLAH EQUIP / UNEQUIP
-- ═══════════════════════════════════════════
RegisterNetEvent("is4-weapons:equipWeapon", function(weaponName, ammo)
    local playerPed = PlayerPedId()
    local weaponHash = GetHashKey(weaponName)

    GiveWeaponToPed(playerPed, weaponHash, ammo or 0, false, true)
    SetCurrentPedWeapon(playerPed, weaponHash, true)

    local weaponData = IS4.Weapons.All[weaponName]
    exports['is4-core']:SendNotification(-1, ("🔫 %s kuşanıldı."):format(weaponData and weaponData.label or weaponName))
end)

RegisterNetEvent("is4-weapons:unequipWeapon", function(weaponName)
    local playerPed = PlayerPedId()
    local weaponHash = GetHashKey(weaponName)

    RemoveWeaponFromPed(playerPed, weaponHash)

    local weaponData = IS4.Weapons.All[weaponName]
    exports['is4-core']:SendNotification(-1, ("🔫 %s kaldırıldı."):format(weaponData and weaponData.label or weaponName))
end)

-- ═══════════════════════════════════════════
-- SİLAH BOZULMA (KULLANIM ENGELLEMESİ)
-- ═══════════════════════════════════════════
RegisterNetEvent("is4-weapons:weaponBroken", function(weaponName)
    local playerPed = PlayerPedId()
    local weaponHash = GetHashKey(weaponName)

    -- Silahı kaldır, bozuldugu için kullanılamaz
    RemoveWeaponFromPed(playerPed, weaponHash)

    local weaponData = IS4.Weapons.All[weaponName]
    exports['is4-core']:SendNotification(-1, ("💥 %s bozuldu! Mekanikten tamir ettir."):format(weaponData and weaponData.label or weaponName))
end)

-- ═══════════════════════════════════════════
-- ATIŞ TAKİBİ (DAYANIKLILIK İÇİN)
-- ═══════════════════════════════════════════
Citizen.CreateThread(function()
    local lastShot = false

    while true do
        Wait(100)
        local playerPed = PlayerPedId()

        if IsPedShooting(playerPed) then
            if not lastShot then
                lastShot = true
                local _, currentWeaponHash = GetCurrentPedWeapon(playerPed)

                -- Hash'ten weapon name bul
                for weaponName, weaponData in pairs(IS4.Weapons.All) do
                    if GetHashKey(weaponName) == currentWeaponHash then
                        TriggerServerEvent("is4-weapons:reportShot", weaponName)
                        break
                    end
                end
            end
        else
            lastShot = false
        end
    end
end)

-- ═══════════════════════════════════════════
-- BİLDİRİMLER
-- ═══════════════════════════════════════════
RegisterNetEvent("is4-weapons:notification", function(msg)
    exports['is4-core']:SendNotification(-1, msg)
end)
