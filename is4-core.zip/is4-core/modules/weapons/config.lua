Config = {}

Config.WeaponRules = {
    MaxCarried = 3,                 -- Max un-holstered weapons a player can hold
    DurabilityMechanics = true,     -- Weapons break over time
    DegradationRate = 0.01,         -- Per shot degradation
    RepairMechanics = true,
    LicenseRequired = true          -- Need a gun license for shops
}

-- Ammo Stack caps
Config.AmmoLimits = {
    ["pistol_ammo"] = 250,
    ["smg_ammo"] = 500,
    ["rifle_ammo"] = 500,
    ["shotgun_ammo"] = 100
}

Config.RestrictedWeapons = {
    PoliceOnly = { "WEAPON_CARBINERIFLE", "WEAPON_COMBATPISTOL" },
    Illegal = { "WEAPON_APPISTOL", "WEAPON_MICROSMG" }
}
