# weapons Tutorial

How to use weapons module.
