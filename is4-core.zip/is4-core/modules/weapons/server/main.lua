-- modules/weapons/server/main.lua
-- Silah Sistemi: Server Tarafı
local Core = exports['is4-core']:GetCore()

-- ═══════════════════════════════════════════
-- TÜM SİLAHLARI FRAMEWORK'E KAYDET
-- ═══════════════════════════════════════════
Citizen.CreateThread(function()
    Wait(1000)

    local count = 0
    for weaponName, weaponData in pairs(IS4.Weapons.All) do
        exports['is4-core']:CreateWeapon(weaponName, weaponData)
        count = count + 1
    end
    IS4.Logger.Info(("[Weapons Module] %d silah başarıyla kaydedildi."):format(count))
end)

-- ═══════════════════════════════════════════
-- SİLAH ENVANTER YÖNETİMİ
-- ═══════════════════════════════════════════
local PlayerWeapons = {} -- RAM Cache: {[source] = { {name, ammo, durability} }}

--- Silah ver
RegisterNetEvent("is4-weapons:giveWeapon", function(weaponName, ammo)
    local src = source
    local weaponData = IS4.Weapons.All[weaponName]
    if not weaponData then
        TriggerClientEvent("is4-weapons:notification", src, "❌ Tanımsız silah.")
        return
    end

    -- Polis kilidi kontrolü
    if weaponData.policeOnly then
        local player = exports['is4-core']:GetPlayer(src)
        if player then
            local pJob = type(player.job) == "table" and player.job.name or player.job
            if pJob ~= "police" then
                TriggerClientEvent("is4-weapons:notification", src, "❌ Bu silah sadece polis kullanabilir.")
                return
            end
        end
    end

    -- Max silah kontrolü
    if not PlayerWeapons[src] then PlayerWeapons[src] = {} end
    local maxCarried = Config.WeaponRules.MaxCarried or 3
    if #PlayerWeapons[src] >= maxCarried then
        TriggerClientEvent("is4-weapons:notification", src, ("❌ Maksimum %d silah taşıyabilirsin."):format(maxCarried))
        return
    end

    ammo = math.min(ammo or 0, weaponData.maxAmmo or 250)

    table.insert(PlayerWeapons[src], {
        name = weaponName,
        ammo = ammo,
        durability = weaponData.durability or 100,
    })

    TriggerClientEvent("is4-weapons:equipWeapon", src, weaponName, ammo)
    IS4.Logger.Info(("[Weapons] Silah verildi: %s (%d mermi) → %s"):format(weaponName, ammo, src))
end)

--- Silah kaldır
RegisterNetEvent("is4-weapons:removeWeapon", function(weaponName)
    local src = source
    if not PlayerWeapons[src] then return end

    for i, wep in ipairs(PlayerWeapons[src]) do
        if wep.name == weaponName then
            table.remove(PlayerWeapons[src], i)
            TriggerClientEvent("is4-weapons:unequipWeapon", src, weaponName)
            IS4.Logger.Info(("[Weapons] Silah kaldırıldı: %s → %s"):format(weaponName, src))
            return
        end
    end
end)

-- ═══════════════════════════════════════════
-- DAYANIKLILIK SİSTEMİ
-- ═══════════════════════════════════════════
RegisterNetEvent("is4-weapons:reportShot", function(weaponName)
    local src = source
    if not PlayerWeapons[src] then return end

    for _, wep in ipairs(PlayerWeapons[src]) do
        if wep.name == weaponName then
            local weaponData = IS4.Weapons.All[weaponName]
            local degradation = weaponData and weaponData.degradationRate or 0.5
            wep.durability = math.max(0, wep.durability - degradation)

            if wep.durability <= 0 then
                TriggerClientEvent("is4-weapons:weaponBroken", src, weaponName)
                TriggerClientEvent("is4-weapons:notification", src, ("⚠️ %s bozuldu! Tamir gerekli."):format(weaponData and weaponData.label or weaponName))
                IS4.Logger.Info(("[Weapons] Silah bozuldu: %s → %s"):format(weaponName, src))
            elseif wep.durability < 20 then
                TriggerClientEvent("is4-weapons:notification", src, ("⚠️ %s dayanıklılığı düşük: %%%.0f"):format(weaponData and weaponData.label or weaponName, wep.durability))
            end
            return
        end
    end
end)

-- ═══════════════════════════════════════════
-- SİLAH TAMİR
-- ═══════════════════════════════════════════
RegisterNetEvent("is4-weapons:repairWeapon", function(weaponName)
    local src = source
    if not PlayerWeapons[src] then return end

    -- Mekanik mi kontrol et
    local player = exports['is4-core']:GetPlayer(src)
    local playerJob = player and (type(player.job) == "table" and player.job.name or player.job) or ""

    for _, wep in ipairs(PlayerWeapons[src]) do
        if wep.name == weaponName then
            local weaponData = IS4.Weapons.All[weaponName]
            wep.durability = weaponData and weaponData.durability or 100
            TriggerClientEvent("is4-weapons:notification", src, ("🔧 %s tamir edildi."):format(weaponData and weaponData.label or weaponName))
            IS4.Logger.Info(("[Weapons] Silah tamir edildi: %s → %s"):format(weaponName, src))
            return
        end
    end
end)

-- ═══════════════════════════════════════════
-- SİLAH LİSANS KONTROLÜ
-- ═══════════════════════════════════════════
RegisterNetEvent("is4-weapons:checkLicense", function(targetId)
    local src = source
    -- Sadece polis kontrol edebilir
    local player = exports['is4-core']:GetPlayer(src)
    local playerJob = player and (type(player.job) == "table" and player.job.name or player.job) or ""

    if playerJob ~= "police" then
        TriggerClientEvent("is4-weapons:notification", src, "❌ Bu işlem sadece polis yapabilir.")
        return
    end

    local hasLicense = exports['is4-core']:HasLicense(targetId, "weapon")
    local identity = exports['is4-core']:GetIdentity(targetId)
    local name = identity and (identity.firstname .. " " .. identity.lastname) or ("Oyuncu #" .. targetId)

    if hasLicense then
        TriggerClientEvent("is4-weapons:notification", src, ("✅ %s — Silah ruhsatı: GEÇERLİ"):format(name))
    else
        TriggerClientEvent("is4-weapons:notification", src, ("❌ %s — Silah ruhsatı: YOK"):format(name))
    end
end)

-- ═══════════════════════════════════════════
-- OYUNCU DISCONNECT
-- ═══════════════════════════════════════════
AddEventHandler("playerDropped", function()
    local src = source
    PlayerWeapons[src] = nil
end)
