-- Anti-cheat placeholder
function DetectCheater(...)
    IS4.Logger.Warning("Potential cheat detected.")
end
