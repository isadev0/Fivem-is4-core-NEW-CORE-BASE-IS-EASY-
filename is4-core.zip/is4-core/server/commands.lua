-- server/commands.lua
RegisterCommand("givemoney", function(source, args)
    local target = tonumber(args[1])
    local amount = tonumber(args[2])
    
    if target and amount then
        if exports['is4-core']:AddMoney(target, amount) then
            IS4.Logger.Info(("Admin added $%s to Player %s"):format(amount, target))
            exports['is4-core']:SendNotification(target, ("Admin sana $%s gönderdi."):format(amount))
        end
    end
end, true) -- restricted to admins
