Citizen.CreateThread(function()
    while true do
        -- Save players to DB every 5 minutes (300,000 ms)
        Wait(60000 * 5)
        
        IS4.Logger.Info("Cron: Initiating periodic DB save cycle...")
        exports['is4-core']:SaveAllPlayers()
    end
end)
