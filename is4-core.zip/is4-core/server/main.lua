-- server/main.lua
Citizen.CreateThread(function()
    IS4.Logger.Info("Initializing is4-core (Server)...")
    Wait(200) -- Await scripts to parse
    BootServerModules()
    IS4.Logger.Info("IS4-Core Boot Sequence Complete!")
end)

-- Tüm online oyuncuların status sütununu temizle (sunucu restart sonrası)
Citizen.CreateThread(function()
    Wait(1000)
    MySQL.Async.execute("UPDATE players SET status = 0 WHERE status = 1", {}, function()
        IS4.Logger.Info("[Main] Tüm online statüler sıfırlandı (restart temizliği).")
    end)
end)
