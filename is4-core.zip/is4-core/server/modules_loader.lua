-- server/modules_loader.lua
function BootServerModules()
    IS4.Logger.Info("Booting Server Modules...")
    local count = 0
    for modName, _ in pairs(IS4.Modules) do
        IS4.Logger.Info(('  - Loaded module: %s'):format(modName))
        count = count + 1
    end
    IS4.Logger.Info(("Successfully loaded %s modules."):format(count))
end
